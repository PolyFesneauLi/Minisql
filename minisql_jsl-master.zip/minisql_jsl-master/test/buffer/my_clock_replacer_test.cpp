#include "buffer/clock_replacer.h"
#include "gtest/gtest.h"

//=========================== My Test  for CLOCKReplacer(common testing) ===========================//

TEST(ClockReplacerTest, myCLOCKReplacerTest1) {
    CLOCKReplacer clock_replacer(7);

    // Scenario: unpin six elements, i.e. add them to the replacer.
    clock_replacer.Unpin(1);
    clock_replacer.Unpin(2);
    clock_replacer.Unpin(3);
    clock_replacer.Unpin(4);
    clock_replacer.Unpin(5);
    clock_replacer.Unpin(6);
    clock_replacer.Unpin(1);
    EXPECT_EQ(6, clock_replacer.Size());

    // Scenario: get three victims from the clock.
    int value;
    clock_replacer.Victim(&value);
    EXPECT_EQ(6, value);
    clock_replacer.Victim(&value);
    EXPECT_EQ(1, value);
    clock_replacer.Victim(&value);
    EXPECT_EQ(2, value);

    // Scenario: pin elements in the replacer.
    // Note that 2 has already been victimized, so pinning 2 should have no effect.
    clock_replacer.Pin(2);
    clock_replacer.Pin(3);
    EXPECT_EQ(2, clock_replacer.Size());

    // Scenario: unpin 4. We expect that the reference bit of 4 will be set to 1.
    clock_replacer.Unpin(3);

    // Scenario: continue looking for victims. We expect these victims.
    clock_replacer.Victim(&value);
    EXPECT_EQ(4, value);
    clock_replacer.Victim(&value);
    EXPECT_EQ(5, value);
    clock_replacer.Victim(&value);
    EXPECT_EQ(3, value);
}

//=========================== My Test  for CLOCKReplacer(stress testing) ===========================//

TEST(ClockReplacerTest, myCLOCKReplacerTest2) {
    int value;
    CLOCKReplacer lru_replacer(1000000);  // 一百万

    // Scenario: unpin 1000000 + 1000000 elements, i.e. add them to the replacer.
    for (int i = 1; i <= 1000000; ++i) {
        lru_replacer.Unpin(i - 1);
        EXPECT_EQ(i, lru_replacer.Size());
    }

    for (int i = 1; i <= 1000000; ++i) {
        lru_replacer.Unpin(i - 1);
        EXPECT_EQ(1000000, lru_replacer.Size());
    }

    // Scenario: get 100000 victims from the lru.
    for (int i = 0; i < 100000; ++i) {
        lru_replacer.Victim(&value);
        if (!i)
            EXPECT_EQ(999999, value);
        else
            EXPECT_EQ(i - 1, value);
    }

    // Scenario: pin elements in the replacer.
    // Note that 5000 has already been victimized, so pinning 5000 should have no effect.
    lru_replacer.Pin(5000);
    lru_replacer.Pin(99999);
    EXPECT_EQ(899999, lru_replacer.Size());

    // Scenario: unpin 1. We expect that the reference bit of 1 will be set to 1.
    lru_replacer.Unpin(1);

    // Scenario: continue looking for victims. We expect these victims.
    for (int i = 0; i < 899999; ++i) {
        lru_replacer.Victim(&value);
        EXPECT_EQ(100000 + i, value);
    }

    lru_replacer.Victim(&value);  // 还剩下最后的1
    EXPECT_EQ(1, value);

    EXPECT_EQ(0, lru_replacer.Size());  // 空了
}
