#include "buffer/lru_replacer.h"
#include "gtest/gtest.h"

//=========================== My Test  for LRUReplacer(Stress testing) ===========================//
TEST(LRUReplacerTest, myLRUReplacerTest) {
    int value;
    LRUReplacer lru_replacer(1000000);  // 一百万

    // Scenario: unpin 1000000 + 1000000 elements, i.e. add them to the replacer.
    for (int i = 1; i <= 1000000; ++i) {
        lru_replacer.Unpin(i - 1);
        EXPECT_EQ(i, lru_replacer.Size());
    }

    for (int i = 1; i <= 1000000; ++i) {
        lru_replacer.Unpin(i - 1);
        EXPECT_EQ(1000000, lru_replacer.Size());
    }

    // Scenario: get 100000 victims from the lru.
    for (int i = 0; i < 100000; ++i) {
        lru_replacer.Victim(&value);
        EXPECT_EQ(i, value);
    }

    // Scenario: pin elements in the replacer.
    // Note that 5000 has already been victimized, so pinning 5000 should have no effect.
    lru_replacer.Pin(5000);
    lru_replacer.Pin(100000);
    EXPECT_EQ(899999, lru_replacer.Size());

    // Scenario: unpin 1. We expect that the reference bit of 1 will be set to 1.
    lru_replacer.Unpin(1);

    // Scenario: continue looking for victims. We expect these victims.
    for (int i = 1; i < 900000; ++i) {
        lru_replacer.Victim(&value);
        EXPECT_EQ(100000 + i, value);
    }

    lru_replacer.Victim(&value);  // 还剩下最后的1
    EXPECT_EQ(1, value);

    EXPECT_EQ(0, lru_replacer.Size());  // 空了
}