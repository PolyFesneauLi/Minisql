#include "storage/disk_manager.h"

#include <unordered_set>

#include "gtest/gtest.h"

//=========================== My Test for bitmapPage (stress test) ===========================//

TEST(BitmapPageTest, myBitMapPageTest) {
    const size_t size = 4096;  // size开到最大
    char buf[size];
    memset(buf, 0, size);
    BitmapPage<size>* bitmap = reinterpret_cast<BitmapPage<size>*>(buf);
    auto num_pages = bitmap->GetMaxSupportedSize();

    // 验证初始每个页是否为空
    for (uint32_t i = 0; i < num_pages; i++) {
        ASSERT_TRUE(bitmap->IsPageFree(i));
    }

    uint32_t ofs;
    std::unordered_set<uint32_t> page_set;
    // 插入直到插满
    for (uint32_t i = 0; i < num_pages; i++) {
        ASSERT_TRUE(bitmap->AllocatePage(ofs));
        ASSERT_TRUE(page_set.find(ofs) == page_set.end());
        page_set.insert(ofs);
    }
    for (uint32_t i = 0; i < num_pages; i++) {
        ASSERT_FALSE(bitmap->IsPageFree(i));      // 测试是否为空
        ASSERT_FALSE(bitmap->AllocatePage(ofs));  // 测试能否继续插入
    }
    // 连续多次单个删除+单个插入测试 (用于考察 next_free_page_ 是否能指向正确的地点)
    for (uint32_t i = 0; i < num_pages; i++) {
        ASSERT_FALSE(bitmap->AllocatePage(ofs));
        ASSERT_TRUE(bitmap->DeAllocatePage(i));
        ASSERT_TRUE(bitmap->AllocatePage(ofs));
        ASSERT_EQ(i, ofs);  // 测试单个插入位置是否为删除之后留下的坑
    }
    // 全部删除测试
    for (auto v : page_set) {
        ASSERT_TRUE(bitmap->DeAllocatePage(v));
        ASSERT_FALSE(bitmap->DeAllocatePage(v));
    }
    // 再次插入直到插满
    for (uint32_t i = 0; i < num_pages; i++) {
        ASSERT_TRUE(bitmap->AllocatePage(ofs));
    }
    ASSERT_FALSE(bitmap->AllocatePage(ofs));  // 最后测试能否继续插入
}