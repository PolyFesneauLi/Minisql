#include "storage/disk_manager.h"

#include <unordered_set>

#include "gtest/gtest.h"

//=========================== My Test for DiskManager (stress test) ===========================//
// extent_nums 为分区数量，可以自己设置来调整大小，因为太大的时候插入量太大了，所以这边设置了5，在先前测试过10和更大的数均正确
TEST(DiskManagerTest, myDiskManagerTest) {
    std::string db_name = "my_disk_test.db";
    DiskManager* disk_mgr = new DiskManager(db_name);
    int extent_nums = 5;  // 分区数量(可以自己设置大小)
    for (uint32_t i = 0; i < DiskManager::BITMAP_SIZE * extent_nums; i++) {
        page_id_t page_id = disk_mgr->AllocatePage();
        DiskFileMetaPage* meta_page = reinterpret_cast<DiskFileMetaPage*>(disk_mgr->GetMetaData());
        EXPECT_EQ(i, page_id);
        EXPECT_EQ(i / DiskManager::BITMAP_SIZE + 1, meta_page->GetExtentNums());
        EXPECT_EQ(i + 1, meta_page->GetAllocatedPages());
        EXPECT_EQ(i % DiskManager::BITMAP_SIZE + 1, meta_page->GetExtentUsedPage(i / DiskManager::BITMAP_SIZE));
    }
    // 删除 0、BITMAP_SIZE-1、BITMAP_SIZE、2*BITMAP_SIZE-1 .....等
    for (uint32_t i = 0; i < extent_nums; i++) {
        disk_mgr->DeAllocatePage(i * DiskManager::BITMAP_SIZE);
        disk_mgr->DeAllocatePage(DiskManager::BITMAP_SIZE * (i + 1) - 1);
    }
    DiskFileMetaPage* meta_page = reinterpret_cast<DiskFileMetaPage*>(disk_mgr->GetMetaData());
    EXPECT_EQ(extent_nums * DiskManager::BITMAP_SIZE - extent_nums * 2, meta_page->GetAllocatedPages());
    for (uint32_t i = 0; i < extent_nums; i++) {
        EXPECT_EQ(DiskManager::BITMAP_SIZE - 2, meta_page->GetExtentUsedPage(i));
    }
    remove(db_name.c_str());
}