#include "storage/table_heap.h"

#include <unordered_map>
#include <vector>

#include "common/instance.h"
#include "gtest/gtest.h"
#include "record/field.h"
#include "record/schema.h"
#include "utils/utils.h"

static string db_file_name = "table_heap_test.db";
using Fields = std::vector<Field>;

//=========================== My Test 1 for Iterator (stress test) ===========================//
// 为了测试迭代器
TEST(TableHeapTest, TableHeapMyTest1) {
    // init testing instance
    auto disk_mgr_ = new DiskManager(db_file_name);
    auto bpm_ = new BufferPoolManager(DEFAULT_BUFFER_POOL_SIZE, disk_mgr_);
    const int row_nums = 10000;
    // create schema
    std::vector<Column*> columns = {new Column("id", TypeId::kTypeInt, 0, false, false),
                                    new Column("name", TypeId::kTypeChar, 64, 1, true, false),
                                    new Column("account", TypeId::kTypeFloat, 2, true, false)};
    auto schema = std::make_shared<Schema>(columns);
    // create rows
    std::unordered_map<int64_t, Fields*> row_values;
    uint32_t size = 0;
    TableHeap* table_heap = TableHeap::Create(bpm_, schema.get(), nullptr, nullptr, nullptr);
    for (int i = 0; i < row_nums; i++) {
        int32_t len = RandomUtils::RandomInt(0, 64);
        char* characters = new char[len];
        RandomUtils::RandomString(characters, len);
        Fields* fields =
            new Fields{Field(TypeId::kTypeInt, i), Field(TypeId::kTypeChar, const_cast<char*>(characters), len, true),
                       Field(TypeId::kTypeFloat, RandomUtils::RandomFloat(-999.f, 999.f))};
        Row row(*fields);
        ASSERT_TRUE(table_heap->InsertTuple(row, nullptr));
        if (row_values.find(row.GetRowId().Get()) != row_values.end()) {
            std::cout << row.GetRowId().Get() << std::endl;
            ASSERT_TRUE(false);
        } else {
            row_values.emplace(row.GetRowId().Get(), fields);
            size++;
        }
        delete[] characters;
    }

    //=========================== My Test ===========================//
    for (TableIterator i = table_heap->Begin(nullptr); i != table_heap->End(); ++i) {
        cout << i->GetRowId().GetPageId() << " " << i->GetRowId().GetSlotNum() << endl;
    }

    remove(db_file_name.c_str());
}

//=========================== My Test 2 for UpdateTuple and ApplyDelete and so on ===========================//
// 为了测试update等函数
TEST(TableHeapTest, TableHeapMyTest2) {
    // init testing instance
    auto disk_mgr_ = new DiskManager(db_file_name);
    auto bpm_ = new BufferPoolManager(DEFAULT_BUFFER_POOL_SIZE, disk_mgr_);
    const int row_nums = 10000;
    // create schema
    std::vector<Column*> columns = {new Column("id", TypeId::kTypeInt, 0, false, false),
                                    new Column("name", TypeId::kTypeChar, 64, 1, true, false),
                                    new Column("account", TypeId::kTypeFloat, 2, true, false)};
    auto schema = std::make_shared<Schema>(columns);
    // create rows
    std::unordered_map<int64_t, Fields*> row_values;
    uint32_t size = 0;
    TableHeap* table_heap = TableHeap::Create(bpm_, schema.get(), nullptr, nullptr, nullptr);
    for (int i = 0; i < row_nums; i++) {
        int32_t len = RandomUtils::RandomInt(0, 64);
        char* characters = new char[len];
        RandomUtils::RandomString(characters, len);
        Fields* fields =
            new Fields{Field(TypeId::kTypeInt, i), Field(TypeId::kTypeChar, const_cast<char*>(characters), len, true),
                       Field(TypeId::kTypeFloat, RandomUtils::RandomFloat(-999.f, 999.f))};
        Row row(*fields);
        ASSERT_TRUE(table_heap->InsertTuple(row, nullptr));

        //=========================== My Test ===========================//
        // add test for update
        Fields* myfields = new Fields{Field(TypeId::kTypeInt, 114514),
                                      Field(TypeId::kTypeChar, const_cast<char*>("Emilia"), strlen("Emilia"), false),
                                      Field(TypeId::kTypeFloat, 114.514f)};
        Row row2(*myfields);
        // 验证update是否正确
        ASSERT_TRUE(table_heap->UpdateTuple(row2, row.myGetRowId(), nullptr));
        ASSERT_EQ(row.myGetRowId(), row2.myGetRowId());        // 验证rowid
        ASSERT_EQ(row.GetFieldCount(), row2.GetFieldCount());  // 验证field元素数量
        for (int i = 0; i < row.GetFieldCount(); ++i) {
            ASSERT_TRUE(row.GetField(i)->CheckComparable(*row2.GetField(i)));  // 验证每个元素
        }

        ASSERT_TRUE(table_heap->MarkDelete(row2.GetRowId(), nullptr));
        table_heap->ApplyDelete(row2.GetRowId(), nullptr);
        ASSERT_TRUE(table_heap->InsertTuple(row2, nullptr));

        if (row_values.find(row2.GetRowId().Get()) != row_values.end()) {
            std::cout << row2.GetRowId().Get() << std::endl;
            ASSERT_TRUE(false);
        } else {
            row_values.emplace(row2.GetRowId().Get(), myfields);
            size++;
        }
        delete[] characters;
    }

    ASSERT_EQ(row_nums, row_values.size());
    ASSERT_EQ(row_nums, size);
    for (auto row_kv : row_values) {
        size--;
        Row row(RowId(row_kv.first));
        table_heap->GetTuple(&row, nullptr);
        ASSERT_EQ(schema.get()->GetColumnCount(), row.GetFields().size());
        for (size_t j = 0; j < schema.get()->GetColumnCount(); j++) {
            ASSERT_EQ(CmpBool::kTrue, row.GetField(j)->CompareEquals(row_kv.second->at(j)));
        }
        // free spaces
        delete row_kv.second;
    }
    ASSERT_EQ(size, 0);
}

//=========================== My Test 3 for all the functions in part 2 ===========================//
// 来自官方的极其详细的测试，涵盖了所有的第二部分的内容，综合测试了增删查找及迭代器等内容

TEST(TableHeapTest, TableHeapMyTest3) {
    // init testing instance
    DBStorageEngine engine(db_file_name);
    SimpleMemHeap heap;
    const int row_nums = 1000;
    // create schema
    std::vector<Column*> columns = {
        new Column("id", TypeId::kTypeInt, 0, false, false),
        new Column("name", TypeId::kTypeChar, 64, 1, true, false),
        new Column("account", TypeId::kTypeFloat, 2, true, false)};
    auto schema = std::make_shared<Schema>(columns);
    // create rows
    std::unordered_map<int64_t, Fields*> row_values;
    TableHeap* table_heap = TableHeap::Create(engine.bpm_, schema.get(), nullptr, nullptr, nullptr);
    for (int i = 0; i < row_nums; i++) {
        int32_t len = RandomUtils::RandomInt(0, 64);
        char* characters = new char[len];
        RandomUtils::RandomString(characters, len);
        Fields* fields = new Fields{
            Field(TypeId::kTypeInt, i),
            Field(TypeId::kTypeChar, const_cast<char*>(characters), len, true),
            Field(TypeId::kTypeFloat, RandomUtils::RandomFloat(-999.f, 999.f))};
        Row row(*fields);
        table_heap->InsertTuple(row, nullptr);
        row_values[row.GetRowId().Get()] = fields;
        delete[] characters;
    }

    ASSERT_EQ(row_nums, row_values.size());
    for (auto row_kv : row_values) {
        Row row(RowId(row_kv.first));
        table_heap->GetTuple(&row, nullptr);
        ASSERT_EQ(schema.get()->GetColumnCount(), row.GetFields().size());
        for (size_t j = 0; j < schema.get()->GetColumnCount(); j++) {
            ASSERT_EQ(CmpBool::kTrue, row.GetField(j)->CompareEquals(row_kv.second->at(j)));
        }
        // free spaces
        delete row_kv.second;
    }

    Fields* new_field = new Fields{
        Field(TypeId::kTypeInt, 233),
        Field(TypeId::kTypeChar, const_cast<char*>("characters"), 11, true),
        Field(TypeId::kTypeFloat, RandomUtils::RandomFloat(-999.f, 999.f))};
    Row new_row(*new_field);
    RowId upd_rowid(3, 23);
    table_heap->UpdateTuple(new_row, upd_rowid, nullptr);
    RowId del_rowid(5, 20);
    table_heap->ApplyDelete(del_rowid, nullptr);
    bool delete_success = true;

    TableIterator it = table_heap->Begin(nullptr);
    for (; it != table_heap->End(); it++) {
        if (it->GetRowId().GetPageId() == 5 && it->GetRowId().GetSlotNum() == 20)
            delete_success = false;
        if (it->GetRowId().GetPageId() == 3 && it->GetRowId().GetSlotNum() == 23) {
            for (size_t j = 0; j < schema.get()->GetColumnCount(); j++) {
                ASSERT_EQ(CmpBool::kTrue, (*it).GetField(j)->CompareEquals(*new_row.GetField(j)));
            }
        }
        Row row(it->GetRowId());
        table_heap->GetTuple(&row, nullptr);

        for (size_t j = 0; j < schema.get()->GetColumnCount(); j++) {
            ASSERT_EQ(CmpBool::kTrue, (*it).GetField(j)->CompareEquals(*row.GetField(j)));
        }
    }
    ASSERT_EQ(delete_success, true);
}
