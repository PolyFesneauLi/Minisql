#include "index/b_plus_tree.h"

#include "common/instance.h"
#include "gtest/gtest.h"
#include "utils/tree_file_mgr.h"
#include "utils/utils.h"

static const std::string db_name = "bp_tree_insert_test.db";

/**
   * test B+树增删查 100000 个元素
   */
TEST(BPlusTreeTests, SampleTest2) {
  // Init engine
  DBStorageEngine engine3(db_name);
  std::vector<Column *> columns3 = {
      new Column("int", TypeId::kTypeInt, 0, false, false),
  };
  Schema *table_schema3 = new Schema(columns3);
  KeyManager KP3(table_schema3, 16);
  BPlusTree tree3(0, engine3.bpm_, KP3);
  TreeFileManagers mgr3("tree_");
  // Prepare data
  const int m = 50000;
  vector<GenericKey *> keys3;
  vector<RowId> values3;
  vector<GenericKey *> delete_seq3;
  map<GenericKey *, RowId> kv_map3;
  for (int i = 0; i < m; i++) {
    GenericKey *key = KP3.InitKey();
    std::vector<Field> fields{Field(TypeId::kTypeInt, i)};
    KP3.SerializeFromKey(key, Row(fields), table_schema3);
    keys3.push_back(key);
    values3.push_back(RowId(i));
    delete_seq3.push_back(key);
  }
  vector<GenericKey *> keys_copy3(keys3);
  // Shuffle data
  ShuffleArray(keys3);
  ShuffleArray(values3);
  ShuffleArray(delete_seq3);
  // Map key value
  for (int i = 0; i < m; i++) {
    kv_map3[keys3[i]] = values3[i];
  }
  // Insert data
  for (int i = 0; i < m; i++) {
    tree3.Insert(keys3[i], values3[i]);
  }
  ASSERT_TRUE(tree3.Check());
  // Print tree
  tree3.PrintTree(mgr3[0]);
  // Search keys
  vector<RowId> ans3;
  for (int i = 0; i < m; i++) {
    tree3.GetValue(keys_copy3[i], ans3);
    ASSERT_EQ(kv_map3[keys_copy3[i]], ans3[i]);
  }
  ASSERT_TRUE(tree3.Check());
  // Delete half keys
  for (int i = 0; i < m / 2; i++) {
    tree3.Remove(delete_seq3[i]);
  }
  tree3.PrintTree(mgr3[1]);
  tree3.PrintAll(tree3.GetrootId(), mgr3[1]);
  // Check valid
  ASSERT_TRUE(tree3.Check());
  ans3.clear();
  for (int i = 0; i < m / 2; i++) {
    tree3.GetValue(delete_seq3[i], ans3);
  }
  ASSERT_TRUE(tree3.Check());
}