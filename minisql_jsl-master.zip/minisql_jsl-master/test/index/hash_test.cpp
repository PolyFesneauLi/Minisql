#include "index/b_plus_tree.h"

#include "common/instance.h"
#include "gtest/gtest.h"
#include "utils/tree_file_mgr.h"
#include "utils/utils.h"

static const std::string db_name = "hash_test.db";
/**
   * hash
 */
TEST(HashTests, HashSample){
  // Init engine
  DBStorageEngine engine2(db_name);
  std::vector<Column *> columns2 = {
      new Column("int", TypeId::kTypeInt, 0, false, false),
  };
  Schema *table_schema2 = new Schema(columns2);
  KeyManager KP2(table_schema2, 16);
  HashTable hashTable(0, engine2.bpm_, KP2);  // 索引设置为0
  TreeFileManagers mgr2("hash_");
  // Prepare data
  const int n2 = 100;
  vector<GenericKey *> keys2;
  vector<page_id_t> Id;
  vector<GenericKey *> delete_seq2;
  map<GenericKey *, page_id_t> kv_map2;
  for (int i = 0; i < n2; i++) {
    GenericKey *key = KP2.InitKey();
    std::vector<Field> fields{Field(TypeId::kTypeInt, i)};
    KP2.SerializeFromKey(key, Row(fields), table_schema2);
    keys2.push_back(key);
    Id.push_back(i);
    delete_seq2.push_back(key);
  }
  vector<GenericKey *> keys_copy2(keys2);
  // Shuffle data
  ShuffleArray(keys2);
  ShuffleArray(Id);
  ShuffleArray(delete_seq2);
  // Map key value
  for (int i = 0; i < n2; i++) {
    kv_map2[keys2[i]] = Id[i];
  }
  // Insert data
  for (int i = 0; i < n2; i++) {
    ASSERT_TRUE(hashTable.Insert(keys2[i]));
  }
  ASSERT_TRUE(hashTable.Check());
  // Print tree
  // hashTable.PrintTree(mgr[0]);
  // Search keys
  vector<page_id_t> ans2;
  for (int i = 0; i < n2; i++) {
    ASSERT_TRUE(hashTable.GetValue(keys_copy2[i], ans2));
  }
   ASSERT_TRUE(hashTable.Check());
  // Delete half keys
  for (int i = 0; i < n2 / 2; i++) {
    ASSERT_TRUE(hashTable.Remove(delete_seq2[i]));
  }
  // tree.PrintTree(mgr[1]);
  // Check valid
  ans2.clear();
  for (int i = 0; i < n2 / 2; i++) {
    ASSERT_FALSE(hashTable.GetValue(delete_seq2[i], ans2));
  }
  for (int i = n2 / 2; i < n2; i++) {
    ASSERT_TRUE(hashTable.GetValue(delete_seq2[i], ans2));
  }
}