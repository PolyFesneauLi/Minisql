#include "index/b_plus_tree_index.h"

#include <string>

#include "common/instance.h"
#include "gtest/gtest.h"
#include "index/generic_key.h"

static const std::string db_name = "bp_tree_index_test.db";

TEST(BPlusTreeTests, BPlusTreeIndexSimpleTest2) {
  //    using INDEX_KEY_TYPE = GenericKey<32>;
  //    using INDEX_COMPARATOR_TYPE = GenericComparator<32>;
  //    using BP_TREE_INDEX = BPlusTreeIndex<INDEX_KEY_TYPE, RowId, INDEX_COMPARATOR_TYPE>;
  DBStorageEngine engine(db_name);
  std::vector<Column *> columns = {new Column("id", TypeId::kTypeInt, 0, false, false),
                                   new Column("number", TypeId::kTypeInt, 0, true, false),
                                   new Column("name", TypeId::kTypeChar, 64, 1, true, false),
                                   new Column("gender", TypeId::kTypeChar, 1, 1, true, false),
                                   new Column("account", TypeId::kTypeFloat, 2, true, false),
                                   new Column("price", TypeId::kTypeFloat, 2, true, false)};
  std::vector<uint32_t> index_key_map{0, 1};
  const TableSchema table_schema(columns);
  auto *index_schema = Schema::ShallowCopySchema(&table_schema, index_key_map);
  auto *index = new BPlusTreeIndex(0, index_schema, 150, engine.bpm_);
  int n = 100000;
  for (int i = 0; i < n; i++) {
    std::vector<Field> fields{Field(TypeId::kTypeInt, i),
                              Field(TypeId::kTypeChar, const_cast<char *>("minisql"), 7, true)};
    Row row(fields);
    RowId rid(1000, i);
    ASSERT_EQ(DB_SUCCESS, index->InsertEntry(row, rid, nullptr));
  }
  // Test Scan
  std::vector<RowId> ret;
  for (int i = 0; i < n; i++) {
    std::vector<Field> fields{Field(TypeId::kTypeInt, i),
                              Field(TypeId::kTypeChar, const_cast<char *>("minisql"), 7, true)};
    Row row(fields);
    RowId rid(1000, i);
    ASSERT_EQ(DB_SUCCESS, index->ScanKey(row, ret, nullptr));
    ASSERT_EQ(rid.Get(), ret[i].Get());
  }
  // Iterator Scan
  IndexIterator iter = index->GetBeginIterator();
  IndexIterator end = index->GetEndIterator();
  uint32_t i = 0;
  for (; iter != end; ++iter) { // 实在太慢了，稍微减少一点运算
    ASSERT_EQ(1000, (*iter).second.GetPageId());
    ASSERT_EQ(i, (*iter).second.GetSlotNum());
    i++;
  }
  delete index;
}