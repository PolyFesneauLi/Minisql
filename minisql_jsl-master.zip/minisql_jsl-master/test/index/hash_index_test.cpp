#include "index/b_plus_tree_index.h"

#include <string>

#include "common/instance.h"
#include "gtest/gtest.h"
#include "index/generic_key.h"

static const std::string db_name = "hash_test.db";

/**
* Hash
*/
TEST(HashTests, HashSimpleTest){
  DBStorageEngine engine2(db_name);
  std::vector<Column *> columns2 = {new Column("id", TypeId::kTypeInt, 0, false, false),
                                   new Column("name", TypeId::kTypeChar, 64, 1, true, false),
                                   new Column("account", TypeId::kTypeFloat, 2, true, false)};
  std::vector<uint32_t> index_key_map2{0, 1};
  const TableSchema table_schema2(columns2);
  auto *index_schema2 = Schema::ShallowCopySchema(&table_schema2, index_key_map2);
  HashIndex *index2 = new HashIndex(0, index_schema2, 256, engine2.bpm_);
  for (int i = 0; i < 10; i++) {
    std::vector<Field> fields{Field(TypeId::kTypeInt, i),
                              Field(TypeId::kTypeChar, const_cast<char *>("minisql"), 7, true)};
    Row row(fields);
    RowId rid2(1000, i);
    ASSERT_EQ(DB_SUCCESS, index2->InsertEntry(row, rid2, nullptr));
  }
  // Test Scan
  std::vector<RowId> ret2;
  for (int i = 0; i < 10; i++) {
    std::vector<Field> fields{Field(TypeId::kTypeInt, i),
                              Field(TypeId::kTypeChar, const_cast<char *>("minisql"), 7, true)};
    Row row(fields);
    ASSERT_EQ(DB_SUCCESS, index2->ScanKey(row, ret2, nullptr));
  }
  delete index2;
}