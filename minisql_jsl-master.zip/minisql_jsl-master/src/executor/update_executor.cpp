//
// Created by njz on 2023/1/30.
//

#include "executor/executors/update_executor.h"

UpdateExecutor::UpdateExecutor(ExecuteContext* exec_ctx, const UpdatePlanNode* plan, std::unique_ptr<AbstractExecutor>&& child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {}

/**
 * TODO: Student Implement
 */
void UpdateExecutor::Init() {
    TableInfo* info;
    exec_ctx_->GetCatalog()->GetTable(plan_->GetTableName(), info);
    table_heap_ = info->GetTableHeap();
    child_executor_->Init();
}
bool UpdateExecutor::Next([[maybe_unused]] Row* row, RowId* rid) {
    while (child_executor_->Next(row, rid)) {
        // update the new one
        Row updated_row = GenerateUpdatedTuple(*row);
        if (table_heap_->UpdateTuple(updated_row, *rid, exec_ctx_->GetTransaction())) {
            return true;  // 返回true表示成功更新了一行数据
        }
    }
    return false;  // 返回false表示更新操作已完成
}

Row UpdateExecutor::GenerateUpdatedTuple(const Row& src_row) {
    vector<Field> fields;
    bool flag = false;                                  // 第几次循环
    for (auto [key, value] : plan_->GetUpdateAttr()) {  // 这里可以将乱码还原成minisql
        Field field(value->GetReturnType());            // 新的元组

        for (int i = 0; i < src_row.GetFieldCount(); i++) {
            if (field.GetTypeId() == src_row.GetField(i)->GetTypeId()) {
                if (!flag) {
                    fields.push_back(value->Evaluate(&src_row));
                } else
                    fields[i] = field;
            } else {
                if (!flag) {
                    fields.push_back(*src_row.GetField(i));
                }
            }
        }
        flag = true;
    }
    Row new_row(fields);
    new_row.SetRowId(src_row.GetRowId());
    return new_row;
}