#include "executor/execute_engine.h"
#include "executor/execute_context.h"

#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <chrono>

#include "common/result_writer.h"
#include "executor/executors/delete_executor.h"
#include "executor/executors/index_scan_executor.h"
#include "executor/executors/insert_executor.h"
#include "executor/executors/seq_scan_executor.h"
#include "executor/executors/update_executor.h"
#include "executor/executors/values_executor.h"
#include "glog/logging.h"
#include "parser/minisql_lex.h"
#include "parser/syntax_tree_printer.h"
#include "planner/planner.h"
#include "utils/utils.h"

extern "C" {
int yyparse(void);
}

ExecuteEngine::ExecuteEngine() {
    char path[] = "./databases";
    DIR* dir;
    if ((dir = opendir(path)) == nullptr) {
        mkdir("./databases", 0777);
        dir = opendir(path);
    }
    /** After you finish the code for the CatalogManager section,
     *  you can uncomment the commented code.
    struct dirent *stdir;
    while((stdir = readdir(dir)) != nullptr) {
      if( strcmp( stdir->d_name , "." ) == 0 ||
          strcmp( stdir->d_name , "..") == 0 ||
          stdir->d_name[0] == '.')
        continue;
      dbs_[stdir->d_name] = new DBStorageEngine(stdir->d_name, false);
    }
     **/
    closedir(dir);
}

std::unique_ptr<AbstractExecutor> ExecuteEngine::CreateExecutor(ExecuteContext* exec_ctx,
                                                                const AbstractPlanNodeRef& plan) {
    switch (plan->GetType()) {
        // Create a new sequential scan executor
        case PlanType::SeqScan: {
            return std::make_unique<SeqScanExecutor>(exec_ctx, dynamic_cast<const SeqScanPlanNode*>(plan.get()));
        }
        // Create a new index scan executor
        case PlanType::IndexScan: {
            return std::make_unique<IndexScanExecutor>(exec_ctx, dynamic_cast<const IndexScanPlanNode*>(plan.get()));
        }
        // Create a new update executor
        case PlanType::Update: {
            auto update_plan = dynamic_cast<const UpdatePlanNode*>(plan.get());
            auto child_executor = CreateExecutor(exec_ctx, update_plan->GetChildPlan());
            return std::make_unique<UpdateExecutor>(exec_ctx, update_plan, std::move(child_executor));
        }
            // Create a new delete executor
        case PlanType::Delete: {
            auto delete_plan = dynamic_cast<const DeletePlanNode*>(plan.get());
            auto child_executor = CreateExecutor(exec_ctx, delete_plan->GetChildPlan());
            return std::make_unique<DeleteExecutor>(exec_ctx, delete_plan, std::move(child_executor));
        }
        case PlanType::Insert: {
            auto insert_plan = dynamic_cast<const InsertPlanNode*>(plan.get());
            auto child_executor = CreateExecutor(exec_ctx, insert_plan->GetChildPlan());
            return std::make_unique<InsertExecutor>(exec_ctx, insert_plan, std::move(child_executor));
        }
        case PlanType::Values: {
            return std::make_unique<ValuesExecutor>(exec_ctx, dynamic_cast<const ValuesPlanNode*>(plan.get()));
        }
        default:
            throw std::logic_error("Unsupported plan type.");
    }
}

dberr_t ExecuteEngine::ExecutePlan(const AbstractPlanNodeRef& plan, std::vector<Row>* result_set, Transaction* txn, ExecuteContext* exec_ctx) {
    // Construct the executor for the abstract plan node
    auto executor = CreateExecutor(exec_ctx, plan);

    try {
        executor->Init();
        RowId rid{};
        Row row{};
        while (executor->Next(&row, &rid)) {
            if (result_set != nullptr) {
                result_set->push_back(row);
            }
        }
    } catch (const exception& ex) {
        std::cout << "Error Encountered in Executor Execution: " << ex.what() << std::endl;
        if (result_set != nullptr) {
            result_set->clear();
        }
        cout << "There are some errors happened." << endl;
        return DB_FAILED;
    }
    // cout << "finish" << endl;
    return DB_SUCCESS;
}

dberr_t ExecuteEngine::Execute(pSyntaxNode ast) {
    if (ast == nullptr) {
        return DB_FAILED;
    }
    auto start_time = std::chrono::system_clock::now();
    unique_ptr<ExecuteContext> context(nullptr);
    if (!current_db_.empty())
        context = dbs_[current_db_]->MakeExecuteContext(nullptr);
    switch (ast->type_) {
        case kNodeCreateDB:
            return ExecuteCreateDatabase(ast, context.get());
        case kNodeDropDB:
            return ExecuteDropDatabase(ast, context.get());
        case kNodeShowDB:
            return ExecuteShowDatabases(ast, context.get());
        case kNodeUseDB:
            return ExecuteUseDatabase(ast, context.get());
        case kNodeShowTables:
            return ExecuteShowTables(ast, context.get());
        case kNodeCreateTable:
            return ExecuteCreateTable(ast, context.get());
        case kNodeDropTable:
            return ExecuteDropTable(ast, context.get());
        case kNodeShowIndexes:
            return ExecuteShowIndexes(ast, context.get());
        case kNodeCreateIndex:
            return ExecuteCreateIndex(ast, context.get());
        case kNodeDropIndex:
            return ExecuteDropIndex(ast, context.get());
        case kNodeTrxBegin:
            return ExecuteTrxBegin(ast, context.get());
        case kNodeTrxCommit:
            return ExecuteTrxCommit(ast, context.get());
        case kNodeTrxRollback:
            return ExecuteTrxRollback(ast, context.get());
        case kNodeExecFile:
            return ExecuteExecfile(ast, context.get());
        case kNodeQuit:
            return ExecuteQuit(ast, context.get());
        default:
            break;
    }
    // Plan the query.
    Planner planner(context.get());
    std::vector<Row> result_set{};
    try {
        planner.PlanQuery(ast);
        // Execute the query.
        ExecutePlan(planner.plan_, &result_set, nullptr, context.get());
    } catch (const exception& ex) {
        std::cout << "Error Encountered in Planner: " << ex.what() << std::endl;
        return DB_FAILED;
    }
    auto stop_time = std::chrono::system_clock::now();
    double duration_time =
        double((std::chrono::duration_cast<std::chrono::milliseconds>(stop_time - start_time)).count());
    // Return the result set as string.
    std::stringstream ss;
    ResultWriter writer(ss);

    if (planner.plan_->GetType() == PlanType::SeqScan || planner.plan_->GetType() == PlanType::IndexScan) {
        auto schema = planner.plan_->OutputSchema();
        auto num_of_columns = schema->GetColumnCount();
        if (!result_set.empty()) {
            // find the max width for each column
            vector<int> data_width(num_of_columns, 0);
            for (const auto& row : result_set) {
                for (uint32_t i = 0; i < num_of_columns; i++) {
                    data_width[i] = max(data_width[i], int(row.GetField(i)->toString().size()));
                }
            }
            int k = 0;
            for (const auto& column : schema->GetColumns()) {
                data_width[k] = max(data_width[k], int(column->GetName().length()));
                k++;
            }
            // Generate header for the result set.
            writer.Divider(data_width);
            k = 0;
            writer.BeginRow();
            for (const auto& column : schema->GetColumns()) {
                writer.WriteHeaderCell(column->GetName(), data_width[k++]);
            }
            writer.EndRow();
            writer.Divider(data_width);

            // Transforming result set into strings.
            for (const auto& row : result_set) {
                writer.BeginRow();
                for (uint32_t i = 0; i < schema->GetColumnCount(); i++) {
                    writer.WriteCell(row.GetField(i)->toString(), data_width[i]);
                }
                writer.EndRow();
            }
            writer.Divider(data_width);
        }
        writer.EndInformation(result_set.size(), duration_time, true);
    } else {
        writer.EndInformation(result_set.size(), duration_time, false);
    }
    if (!isReadFile)
        std::cout << writer.stream_.rdbuf();
    return DB_SUCCESS;
}

void ExecuteEngine::ExecuteInformation(dberr_t result) {
    switch (result) {
        case DB_ALREADY_EXIST:
            cout << "Database already exists." << endl;
            break;
        case DB_NOT_EXIST:
            cout << "Database not exists." << endl;
            break;
        case DB_TABLE_ALREADY_EXIST:
            cout << "Table already exists." << endl;
            break;
        case DB_TABLE_NOT_EXIST:
            cout << "Table not exists." << endl;
            break;
        case DB_INDEX_ALREADY_EXIST:
            cout << "Index already exists." << endl;
            break;
        case DB_INDEX_NOT_FOUND:
            cout << "Index not exists." << endl;
            break;
        case DB_COLUMN_NAME_NOT_EXIST:
            cout << "Column not exists." << endl;
            break;
        case DB_KEY_NOT_FOUND:
            cout << "Key not exists." << endl;
            break;
        case DB_QUIT:
            cout << "Bye." << endl;
            break;
        default:
            break;
    }
}
/**
 * TODO: Student Implement
 */
dberr_t ExecuteEngine::ExecuteCreateDatabase(pSyntaxNode ast, ExecuteContext* context) {
    // #ifdef ENABLE_EXECUTE_DEBUG
    //   LOG(INFO) << "ExecuteCreateDatabase" << std::endl;
    // #endif
    //  return DB_FAILED;

    // // not sure whether is val
    std::string DatabaseName = ast->child_->val_;  // point: child instead of itself
    DBStorageEngine* engine_ = new DBStorageEngine(DatabaseName);
    if (dbs_.insert({ast->child_->val_, engine_}).second) {  // 不确定对不对
        std::cout << "Create database \'" << DatabaseName << "\';" << endl;
        return DB_SUCCESS;
    } else {
        std::cout << "Can't create database \'" << DatabaseName << "\'; database exists" << endl;
        return DB_FAILED;
    }
}
/**
 * TODO: Student Implement
 */
dberr_t ExecuteEngine::ExecuteDropDatabase(pSyntaxNode ast, ExecuteContext* context) {
    // #ifdef ENABLE_EXECUTE_DEBUG
    //   LOG(INFO) << "ExecuteDropDatabase" << std::endl;
    // #endif
    //   return DB_FAILED;
    std::string DatabaseName = ast->child_->val_;
    if (dbs_.find(DatabaseName) != dbs_.end()) {
        delete dbs_.find(DatabaseName)->second;
        remove(dbs_.find(DatabaseName)->first.c_str());
        cout << "Drop database '" << DatabaseName << "';" << endl;
        dbs_.erase(DatabaseName);
        return DB_SUCCESS;
    } else {
        std::cout << "Can't drop database '" << DatabaseName << "'; database doesn't exist\n";
        return DB_FAILED;
    }
}

/**
 * TODO: Student Implement
 */
dberr_t ExecuteEngine::ExecuteShowDatabases(pSyntaxNode ast, ExecuteContext* context) {
    // #ifdef ENABLE_EXECUTE_DEBUG
    //   LOG(INFO) << "ExecuteShowDatabases" << std::endl;
    // #endif
    //  return DB_FAILED;
    // std::string Databasename;
    std::cout << "--------------------------------------------\n";
    std::cout << "            All Database" << endl;
    std::cout << "--------------------------------------------\n";
    for (auto it : dbs_) {
        std::cout << "| " << it.second->db_file_name_;
    }
    std::cout << "|\n     " << dbs_.size() << " rows in total";
    return DB_SUCCESS;
}

/**
 * TODO: Student Implement
 */
dberr_t ExecuteEngine::ExecuteUseDatabase(pSyntaxNode ast, ExecuteContext* context) {
    // #ifdef ENABLE_EXECUTE_DEBUG
    //   LOG(INFO) << "ExecuteUseDatabase" << std::endl;
    // #endif
    //   return DB_FAILED;
    std::string DatabaseName = ast->child_->val_;
    if (dbs_.find(DatabaseName) != dbs_.end()) {
        current_db_ = DatabaseName;
        std::cout << "Switch to Database -->" << DatabaseName << endl;
        return DB_SUCCESS;
    } else {
        cout << "Unknown DataBase " << DatabaseName << endl;
        return DB_FAILED;
    }
}

/**
 * TODO: Student Implement
 */
dberr_t ExecuteEngine::ExecuteShowTables(pSyntaxNode ast, ExecuteContext* context) {
    // #ifdef ENABLE_EXECUTE_DEBUG
    //   LOG(INFO) << "ExecuteShowTables" << std::endl;
    // #endif
    //   return DB_FAILED;
    std::vector<TableInfo*> table_infos;
    //  context->GetCatalog()->GetTable(plan_->GetTableName(), table_info);
    dbs_[current_db_]->catalog_mgr_->GetTables(table_infos);
    std::cout << "----------------------------------------------\n";
    std::cout << "           All Tables in Database" << current_db_ << endl;
    std::cout << "----------------------------------------------\n";
    int i = 0;
    for (auto iterator : table_infos) {
        cout << " | " << iterator->GetTableName();
        if (++i % 5 == 0)
            cout << " |" << endl;
    }
    cout << " |\n----------------------------------------------\n";
    std::cout << " |        " << dbs_.size() << " rows in total";
    cout << " |\n----------------------------------------------\n";
}

/**
 * TODO: Student Implement
 */
dberr_t ExecuteEngine::ExecuteCreateTable(pSyntaxNode ast, ExecuteContext* context) {
    // #ifdef ENABLE_EXECUTE_DEBUG
    //     LOG(INFO) << "ExecuteCreateTable" << std::endl;
    // #endif
    //     return DB_FAILED;
    std::string TableName = ast->child_->val_;
    if (dbs_.find(current_db_) == dbs_.end()) {
        std::cout << "Database " << current_db_ << " not exist" << endl;
        return DB_FAILED;
    }
    vector<TableInfo*> tableInfo;
    dbs_[current_db_]->catalog_mgr_->GetTables(tableInfo);
    string table_name = ast->child_->val_;
    for (auto table : tableInfo) {
        if (table->GetTableName() == table_name) {
            return DB_TABLE_ALREADY_EXIST;
        }
    }
    pSyntaxNode p = ast->child_->next_;  // 根据语法树找到定义列表的根节点
    // we need certain type
    if (p->type_ != kNodeColumnDefinitionList)
        return DB_FAILED;
    p = p->child_;  // 第一列定义
    /* 将表的结构写入std::vector<Column *>数组中 */
    std::vector<Column*> columns;
    vector<Column*> uniqueC;  // 收集 unique
    uint32_t index = 0;       // iterator
    while (p->type_ == kNodeColumnDefinition) {
        Column* column;
        pSyntaxNode pc = p->child_, store = p;
        bool unique = false;
        if (p->val_ != nullptr && (std::string(p->val_) == std::string("unique")))
            unique = true;
        if (string(pc->next_->val_) == string("char")) {
            if (atoi(pc->next_->child_->val_) <= 0) {
                std::cout << "string length less than 0" << endl;
                return DB_FAILED;
            } else {
                column = new Column(pc->val_, kTypeChar, atoi(pc->next_->child_->val_), index, true, unique);
            }
        } else if (string(pc->next_->val_) == string("int")) {
            column = new Column(pc->val_, kTypeInt, index, true, unique);
        } else if (string(pc->next_->val_) == string("float")) {
            column = new Column(pc->val_, kTypeFloat, index, true, unique);
        }
        // need unique i don't know its function so delete
        columns.push_back(column);
        if (column->IsUnique()) {
            uniqueC.push_back(column);
        }
        p = p->next_;
        index++;
    }
    TableSchema* schema = new TableSchema(columns);
    TableInfo* newTable;
    if (DB_FAILED == dbs_[current_db_]->catalog_mgr_->CreateTable(TableName, schema, nullptr, newTable)) {
        return DB_FAILED;
    }
    vector<Column*> primary;
    // primary key
    if (p->type_ == kNodeColumnList && string(p->val_) == string("primary keys")) {
        pSyntaxNode pc = p->child_;
        // make it unique
        while (pc != nullptr) {  // 找到所有 primary key
            for (auto it : columns) {
                if (it->GetName() == pc->val_) {
                    if (it->GetType() == kTypeChar) {
                        Column* other = new Column(pc->val_, kTypeChar, it->GetLength(), it->GetTableInd(), false, true);
                        delete it;  // delete all query with same name
                        it = new Column(other);
                    } else {
                        Column* other = new Column(pc->val_, it->GetType(), it->GetTableInd(), false, true);
                        delete it;
                        it = new Column(other);
                    }
                    primary.push_back(it);
                    break;
                }
            }
            pc = pc->next_;
        }
    }
    string index_name;
    IndexInfo* index_info;
    std::vector<std::string> index_keys;
    for (auto uni : uniqueC) {  // indexId需要变化
        index_name = "index" + uni->GetName();
        index_keys.push_back(uni->GetName());  // 属性名是索引的 key
        dbs_[current_db_]->catalog_mgr_->CreateIndex(table_name, index_name, index_keys, nullptr, index_info, "bptree");
        index_keys.clear();  // 先清空
    }
    vector<Field> fields;
    string name;
    for (auto pri : primary) {
        Field field(pri->GetType());  // TODO:正确初始化
        fields.push_back(field);
        name += pri->GetName();
        index_keys.push_back(pri->GetName());
    }
    if (fields.size()) {
        index_name = "index" + name;
        dbs_[current_db_]->catalog_mgr_->CreateIndex(table_name, index_name, index_keys, nullptr, index_info, "bptree");
    }
    int size = uniqueC.size() + (primary.size() == 0 ? 0 : 1);
    if (uniqueC.size()) {
        cout << "create " << size << " index for unique (or primary) columns" << endl;
    }
    cout << "successfully create table " << ast->child_->val_ << endl;
    return DB_SUCCESS;
}

/**
 * TODO: Student Implement
 */
dberr_t ExecuteEngine::ExecuteDropTable(pSyntaxNode ast, ExecuteContext* context) {
    // #ifdef ENABLE_EXECUTE_DEBUG
    //   LOG(INFO) << "ExecuteDropTable" << std::endl;
    // #endifculon
    //   return DB_FAILED;
    std::string TableName = ast->child_->val_;
    if (dbs_.find(current_db_) == dbs_.end()) {
        std::cout << "Database " << current_db_ << "not exist" << endl;
        return DB_FAILED;
    }
    std::vector<TableInfo*> tables;
    dbs_[current_db_]->catalog_mgr_->GetTables(tables);
    for (auto iter = tables.begin(); iter != tables.end(); iter++) {
        if ((*iter)->GetTableName() == TableName) {
            return dbs_[current_db_]->catalog_mgr_->DropTable(TableName);
        }
    }
    std::cout << "Table " << TableName << " not in "
              << "Database " << current_db_ << "not exist" << endl;
    return DB_FAILED;
}

/**
 * TODO: Student Implement
 */
dberr_t ExecuteEngine::ExecuteShowIndexes(pSyntaxNode ast, ExecuteContext* context) {
    // #ifdef ENABLE_EXECUTE_DEBUG
    //   LOG(INFO) << "ExecuteShowIndexes" << std::endl;
    // #endif
    //   return DB_FAILED;
    if (dbs_.find(current_db_) == dbs_.end()) {
        std::cout << "Database " << current_db_ << "not exist" << endl;
        return DB_FAILED;
    }
    std::vector<TableInfo*> tables;
    dbs_[current_db_]->catalog_mgr_->GetTables(tables);
    for (auto it : tables) {
        std::cout << "---------\n";
        std::cout << "In Table " << it->GetTableName() << " we have index:" << endl;
        std::vector<IndexInfo*> indexes;
        dbs_[current_db_]->catalog_mgr_->GetTableIndexes(it->GetTableName(), indexes);
        for (auto index_it : indexes) {
            std::cout << index_it->GetIndexName() << endl;
        }
        std::cout << indexes.size() << " indexes in table" << endl;
        std::cout << "---------\n";
    }
    return DB_SUCCESS;
}

/**
 * TODO: Student Implement
 */
dberr_t ExecuteEngine::ExecuteCreateIndex(pSyntaxNode ast, ExecuteContext* context) {
    // #ifdef ENABLE_EXECUTE_DEBUG
    //   LOG(INFO) << "ExecuteCreateIndex" << std::endl;
    // #endif
    //   return DB_FAILED;
    std::string IndexName = ast->child_->val_;
    if (dbs_.find(current_db_) == dbs_.end()) {
        std::cout << "Database " << current_db_ << "not exist" << endl;
        return DB_FAILED;
    }
    IndexInfo* index_info = nullptr;
    Index* index_;
    pSyntaxNode p = ast->child_->next_;
    std::string TableName = p->val_;
    p = p->next_;
    if (p->type_ != kNodeColumnList)
        return DB_FAILED;
    string indexWay = p->next_->child_->val_;
    p = p->child_;
    std::vector<std::string> index_keys;
    TableInfo* table_info;
    vector<IndexInfo*> indexes;
    if (dbs_[current_db_]->catalog_mgr_->GetTable(TableName, table_info) != DB_TABLE_NOT_EXIST) {
        dbs_[current_db_]->catalog_mgr_->GetTableIndexes(TableName, indexes);
        for (auto index_it : indexes) {
            if (IndexName == index_it->GetIndexName()) {
                cout << "the index " << IndexName << "is already exist" << endl;
                return DB_FAILED;
            }
        }
        TableSchema* schema = table_info->GetSchema();
        vector<Column*> columns = schema->GetColumns();
        while (p != nullptr) {
            for (auto iter : columns) {
                if (string(iter->GetName()) == string(p->val_)) {
                    if (iter->IsUnique())
                        break;
                    else {
                        cout << "Error:Indexes can only be built on unique keys." << endl;
                        return DB_FAILED;
                    }
                }
            }
            index_keys.push_back(p->val_);
            p = p->next_;
        }
    }
    // 建立索引
    if (DB_SUCCESS == dbs_[current_db_]->catalog_mgr_->CreateIndex(TableName, IndexName, index_keys, nullptr, index_info,
                                                                   indexWay)) {  // last argument not sure
        // 将所有内容插入到建立的索引之中
        for (auto it = table_info->GetTableHeap()->Begin(nullptr); it != table_info->GetTableHeap()->End(); ++it) {
            vector<Field*> fields = it->GetFields();
            vector<Field> field_temps;
            vector<Column*> columns = table_info->GetSchema()->GetColumns();
            vector<Column*> columns_index = index_info->GetIndexKeySchema()->GetColumns();
            for (auto itt : columns_index) {
                int i = 0;
                for (auto that : columns) {
                    if (itt->GetName() == that->GetName())
                        field_temps.push_back(*(fields[i]));
                    i++;
                }
            }
            Row row_temp(field_temps);
            // not sure
            index_ = index_info->GetIndex();
            if (indexWay == "hash") {
                (HashIndex*)index_->InsertEntry(row_temp, (*it).GetRowId(), nullptr);
            } else
                (BPlusTreeIndex*)index_->InsertEntry(row_temp, (*it).GetRowId(), nullptr);
        }
        cout << "successfully create the index " << IndexName << endl;
        return DB_SUCCESS;
    }
    return DB_FAILED;
}

/**
 * TODO: Student Implement
 */
dberr_t ExecuteEngine::ExecuteDropIndex(pSyntaxNode ast, ExecuteContext* context) {
    // #ifdef ENABLE_EXECUTE_DEBUG
    //   LOG(INFO) << "ExecuteDropIndex" << std::endl;
    // #endif
    //   return DB_FAILED;
    std::string IndexName = ast->child_->val_;
    if (dbs_.find(current_db_) == dbs_.end()) {
        std::cout << "Database " << current_db_ << "not exist" << endl;
        return DB_FAILED;
    }
    std::vector<TableInfo*> tables;
    dbs_[current_db_]->catalog_mgr_->GetTables(tables);
    for (auto it : tables) {
        std::vector<IndexInfo*> indexes;
        dbs_[current_db_]->catalog_mgr_->GetTableIndexes(it->GetTableName(), indexes);
        for (auto index_it : indexes) {
            if (index_it->GetIndexName() == IndexName) {
                if (DB_SUCCESS == dbs_[current_db_]->catalog_mgr_->DropIndex(it->GetTableName(), IndexName)) {
                    std::cout << "successfully remove index " << IndexName << " in Table " << it->GetTableName() << endl;
                    return DB_SUCCESS;
                }
            }
        }
        return DB_FAILED;
    }
}

// transection need not completing
dberr_t ExecuteEngine::ExecuteTrxBegin(pSyntaxNode ast, ExecuteContext* context) {
    // #ifdef ENABLE_EXECUTE_DEBUG
    //   LOG(INFO) << "ExecuteTrxBegin" << std::endl;
    // #endif
    //   return DB_FAILED;
}

dberr_t ExecuteEngine::ExecuteTrxCommit(pSyntaxNode ast, ExecuteContext* context) {
#ifdef ENABLE_EXECUTE_DEBUG
    LOG(INFO) << "ExecuteTrxCommit" << std::endl;
#endif
    return DB_FAILED;
}

dberr_t ExecuteEngine::ExecuteTrxRollback(pSyntaxNode ast, ExecuteContext* context) {
#ifdef ENABLE_EXECUTE_DEBUG
    LOG(INFO) << "ExecuteTrxRollback" << std::endl;
#endif
    return DB_FAILED;
}

/**
 * TODO: Student Implement
 */
dberr_t ExecuteEngine::ExecuteExecfile(pSyntaxNode ast, ExecuteContext* context) {
    isReadFile = true;
    string filename(ast->child_->val_);  // 读取文件
    auto start_time = std::chrono::system_clock::now();
    fstream input(filename);
    if (!input.is_open()) {
        std::cout << "fail to open '" << filename << "'" << endl;
        return DB_FAILED;
    }
    const int buf_size = 1024;
    char cmd[buf_size];
    // executor engine
    // for print syntax tree
    uint32_t syntax_tree_id = 0;
    while (1) {
        // read from file
        char tmp_char;
        int counter = 0;
        tmp_char = input.get();
        while (tmp_char != ';') {
            if (input.eof()) {
                isReadFile = false;
                auto stop_time = std::chrono::system_clock::now();
                double duration_time =
                    double((std::chrono::duration_cast<std::chrono::milliseconds>(stop_time - start_time)).count());
                // Return the result set as string.
                std::stringstream ss;
                ResultWriter writer(ss);
                writer.EndInformation(10000, duration_time, false);
                std::cout << writer.stream_.rdbuf();
                return DB_SUCCESS;
            }
            cmd[counter++] = tmp_char;
            if (counter >= buf_size) {
                std::cout << "buffer overflow" << endl;
                isReadFile = false;
                return DB_FAILED;
            }
            tmp_char = input.get();
        }
        cmd[counter] = ';';
        YY_BUFFER_STATE bp = yy_scan_string(cmd);
        if (bp == nullptr) {
            LOG(ERROR) << "Failed to create yy buffer state." << std::endl;
            exit(1);
        }
        yy_switch_to_buffer(bp);
        // init parser module
        MinisqlParserInit();
        // parse
        yyparse();
        auto result = this->Execute(MinisqlGetParserRootNode());

        // clean memory after parse
        MinisqlParserFinish();
        yy_delete_buffer(bp);
        yylex_destroy();
        // quit condition
        this->ExecuteInformation(result);
        if (result == DB_QUIT) {
            break;
        }
    }
    isReadFile = false;
    return DB_FAILED;
}

/**
 * TODO: Student Implement
 */
dberr_t ExecuteEngine::ExecuteQuit(pSyntaxNode ast, ExecuteContext* context) {
    // #ifdef ENABLE_EXECUTE_DEBUG
    //   LOG(INFO) << "ExecuteQuit" << std::endl;
    // #endif
    //   return DB_FAILED;

    // i think here is unequal
    ASSERT(ast->type_ == kNodeQuit, "Quit Successfully");
    return DB_QUIT;
}
