//
// Created by njz on 2023/1/17.
//
#include "executor/executors/seq_scan_executor.h"

/**
 * TODO: Student Implement
 */
SeqScanExecutor::SeqScanExecutor(ExecuteContext* exec_ctx, const SeqScanPlanNode* plan)
    : AbstractExecutor(exec_ctx),
      plan_(plan) {}

/**
 * 初始化迭代器
 */
void SeqScanExecutor::Init() {
    TableInfo* table_info;
    // 获取表名和谓词条件
    const std::string& table_name = plan_->GetTableName();
    // 使用数据库对象获取表对象
    exec_ctx_->GetCatalog()->GetTable(table_name, table_info);
    // 获取表的迭代器
    tableIterator = new TableIterator(table_info->GetTableHeap(), table_info->GetTableHeap()->Begin(nullptr)->GetRowId(), exec_ctx_->GetTransaction());
}

bool SeqScanExecutor::Next(Row* row, RowId* rid) {
    TableInfo* table_info;
    const std::string& table_name = plan_->GetTableName();
    exec_ctx_->GetCatalog()->GetTable(table_name, table_info);
    auto table_heap_ = table_info->GetTableHeap();
    TableIterator& iterator = *tableIterator;

    while (iterator != table_heap_->End()) {
        auto current_row = iterator.operator*();
        ++iterator;
        if (plan_->filter_predicate_ == nullptr || plan_->filter_predicate_->Evaluate(&current_row).CompareEquals((Field(kTypeInt, 1)))) {
            *row = current_row;  // 如果谓词为空或者满足谓词，则返回筛选过的匹配行
            vector<Field> ret;
            for (unsigned int i = 0; i < plan_->OutputSchema()->GetColumnCount(); i++) {
                ret.emplace_back(Field(*current_row.GetField(plan_->OutputSchema()->GetColumn(i)->GetTableInd())));
            }
            *row = Row(ret);
            if (rid != nullptr) {
                *rid = current_row.GetRowId();  // 传输rowId
                row->SetRowId(*rid);
            }
            return true;
        }
    }
    return false;
}
