#include "executor/executors/index_scan_executor.h"
#include <algorithm>
#include <set>
#include "planner/expressions/constant_value_expression.h"
/**
 * TODO: Student Implement
 */
IndexScanExecutor::IndexScanExecutor(ExecuteContext *exec_ctx, const IndexScanPlanNode *plan)
    : AbstractExecutor(exec_ctx), plan_(plan) {}

void IndexScanExecutor::Init() {
  vector<vector<RowId>> Set;
  if(plan_->filter_predicate_->GetType() == ExpressionType::LogicExpression) {
    // 有 and 的情况
    for(auto plan : plan_->filter_predicate_.get()->GetChildren()) {
      if (plan->GetType() == ExpressionType::ComparisonExpression) {
        ComparisonExpression *compare = reinterpret_cast<ComparisonExpression *>(plan.get());
        auto column = reinterpret_cast<ComparisonExpression *>(compare)->GetChildAt(0);
        auto column2 = reinterpret_cast<ComparisonExpression *>(compare)->GetChildAt(1);
        uint32_t columnId = reinterpret_cast<ColumnValueExpression *>(column.get())->GetColIdx();  // 索引列信息
        for (auto indexes : plan_->indexes_) {
          vector<RowId> rowId;
          if (indexes->key_schema_->GetColumn(0)->GetTableInd() == columnId) {
            auto &fields = reinterpret_cast<ConstantValueExpression *>(column2.get())->val_;
            Row *key = new Row(*new vector<Field>(1, fields));
            indexes->index_->ScanKey(*key, rowId, exec_ctx_->GetTransaction(),
                                     compare->GetComparisonType());  // 查找一列
            Set.push_back(rowId);
            rowId.clear();
          }
        }
      }
    }
  }
  else if (plan_->filter_predicate_->GetType() == ExpressionType::ComparisonExpression) {
    ComparisonExpression *compare = reinterpret_cast<ComparisonExpression *>(plan_->filter_predicate_.get());
    auto column = reinterpret_cast<ComparisonExpression *>(compare)->GetChildAt(1);
    uint32_t columnId = reinterpret_cast<ColumnValueExpression *>(column.get())->GetColIdx();  // 索引列信息
    for (auto indexes : plan_->indexes_) {
      //      if(indexes->GetIndexKeySchema()->GetColumn(0)->GetTableInd() == columnId) {
      auto &fields = reinterpret_cast<ConstantValueExpression *>(column.get())->val_;
      Row *key = new Row(*new vector<Field>(1, fields));
      vector<RowId> rowId;
      indexes->index_->ScanKey(*key, rowId, exec_ctx_->GetTransaction(), compare->GetComparisonType());  // 查找一列
      Set.push_back(rowId);
      rowId.clear();
    }
  }
  SetTogether(Set);
}

bool IndexScanExecutor::Next(Row *row, RowId *rid) {
  if(row_Id.size() <= index)  return false;
  *rid = row_Id[index];
  TableInfo *table_info;
  exec_ctx_->GetCatalog()->GetTable(plan_->GetTableName(), table_info);
  TableHeap* tableHeap = table_info->GetTableHeap();
  Row newRow;
  newRow.SetRowId(*rid);
  tableHeap->GetTuple(&newRow, exec_ctx_->GetTransaction());
  if(!plan_->need_filter_ || plan_->filter_predicate_->Evaluate(&newRow).CompareEquals((Field(kTypeInt, 1)))){
    *row = newRow;
    index++;
    return true;
  }
  return false;
}