//
// Created by njz on 2023/1/27.
//

#include "executor/executors/insert_executor.h"

InsertExecutor::InsertExecutor(ExecuteContext *exec_ctx, const InsertPlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {}

void InsertExecutor::Init() {
  string table_name = plan_->GetTableName();
  // 语法树还没处理
  exec_ctx_->GetCatalog()->GetTable(plan_->GetTableName(), tableInfo);
  this->child_executor_->Init();
}

bool InsertExecutor::Next([[maybe_unused]] Row *row, RowId *rid) {
  // Pull the next row from the child executor
  //  Row child_row;
  //  RowId child_rid;
  // false 表示子执行器已经没有更多的行数据可供插入
  // value 的 next 不分配 pageId
  if (!child_executor_->Next(row, rid)) return false;
  // Insert the row into the table
  TableHeap *table_heap = tableInfo->GetTableHeap();
  if(!table_heap->InsertTuple(*row, exec_ctx_->GetTransaction())){
    return false;
  }
  // Update the indexes
  *rid = row->GetRowId();
  std::vector<IndexInfo *>  indexes;
  dberr_t find = DB_SUCCESS;
  // 获取执行操作中的索引
  exec_ctx_->GetCatalog()->GetTableIndexes(plan_->GetTableName(), indexes);
  for (IndexInfo *index_info : indexes) { // 更新索引
    vector<Field> ret;
    for (unsigned int i = 0; i < index_info->key_schema_->GetColumns().size(); i++) {
      ret.emplace_back(Field(*row->GetField(index_info->key_schema_->GetColumn(i)->GetTableInd())));
    }
    Row newR = Row(ret); // 将待插入值的列数初始化为索引的列数
    newR.SetRowId(*rid);
    //    RowId newRid;
    // newRid.Set(index_info->index_->GetRootPageId(), rid->GetSlotNum()); // rootId 为指定值
    find = index_info->GetIndex()->InsertEntry(newR, *rid, exec_ctx_->GetTransaction());
    if(find != DB_SUCCESS){
      table_heap->MarkDelete(*rid, exec_ctx_->GetTransaction());
      table_heap->ApplyDelete(*rid, exec_ctx_->GetTransaction());
      return false; // 保证 unique
    }
  }
  return true;
}