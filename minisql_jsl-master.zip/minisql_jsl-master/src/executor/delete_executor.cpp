//
// Created by njz on 2023/1/29.
//

#include "executor/executors/delete_executor.h"

/**
 * TODO: Student Implement
 */
// return empty tuple
DeleteExecutor::DeleteExecutor(ExecuteContext* exec_ctx, const DeletePlanNode* plan, std::unique_ptr<AbstractExecutor>&& child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {}

void DeleteExecutor::Init() {
    TableInfo* info;
    exec_ctx_->GetCatalog()->GetTable(plan_->GetTableName(), info);
    table_heap_ = info->GetTableHeap();
    child_executor_->Init();
}

bool DeleteExecutor::Next([[maybe_unused]] Row* row, RowId* rid) {
    vector<IndexInfo *> indexInfo;
    exec_ctx_->GetCatalog()->GetTableIndexes(plan_->GetTableName(), indexInfo);
    if (child_executor_->Next(row, rid)) {
      for (IndexInfo *index_info : indexInfo) { // 更新索引
        vector<Field> ret;
        for (unsigned int i = 0; i < index_info->key_schema_->GetColumns().size(); i++) {
          ret.emplace_back(Field(*row->GetField(index_info->key_schema_->GetColumn(i)->GetTableInd())));
        }
        Row newR = Row(ret);
        newR.SetRowId(*rid);
        ret.clear();
        index_info->GetIndex()->RemoveEntry(newR, row->GetRowId(), exec_ctx_->GetTransaction());
      }
        table_heap_->MarkDelete(*rid, exec_ctx_->GetTransaction());
        table_heap_->ApplyDelete(*rid, exec_ctx_->GetTransaction());
        return true;
    }
    return false;
}