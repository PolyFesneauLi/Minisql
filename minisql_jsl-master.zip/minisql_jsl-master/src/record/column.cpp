#include "record/column.h"

#include "glog/logging.h"

Column::Column(std::string column_name, TypeId type, uint32_t index, bool nullable, bool unique)
    : name_(std::move(column_name)), type_(type), table_ind_(index), nullable_(nullable), unique_(unique) {
    ASSERT(type != TypeId::kTypeChar, "Wrong constructor for CHAR type.");
    switch (type) {
        case TypeId::kTypeInt:
            len_ = sizeof(int32_t);
            break;
        case TypeId::kTypeFloat:
            len_ = sizeof(float_t);
            break;
        default:
            ASSERT(false, "Unsupported column type.");
    }
}

Column::Column(std::string column_name, TypeId type, uint32_t length, uint32_t index, bool nullable, bool unique)
    : name_(std::move(column_name)),
      type_(type),
      len_(length),
      table_ind_(index),
      nullable_(nullable),
      unique_(unique) {
    ASSERT(type == TypeId::kTypeChar, "Wrong constructor for non-VARCHAR type.");
}

Column::Column(const Column* other)
    : name_(other->name_),
      type_(other->type_),
      len_(other->len_),
      table_ind_(other->table_ind_),
      nullable_(other->nullable_),
      unique_(other->unique_) {}

// 序列化顺序保持和构造函数相同
uint32_t Column::SerializeTo(char* buf) const {
    char* copy = buf;  // 指向buf一开始的位置

    // 写入 magic_num
    MACH_WRITE_TO(uint32_t, buf, COLUMN_MAGIC_NUM);
    buf += sizeof(uint32_t);

    // 写入 name_
    MACH_WRITE_TO(uint32_t, buf, GetName().size());
    buf += sizeof(uint32_t);
    MACH_WRITE_STRING(buf, GetName());
    buf += GetName().size();

    // 写入 type_
    MACH_WRITE_TO(TypeId, buf, GetType());
    buf += sizeof(TypeId);

    // 写入 len_
    MACH_WRITE_TO(uint32_t, buf, GetLength());
    buf += sizeof(uint32_t);

    // 写入 table_ind_
    MACH_WRITE_TO(uint32_t, buf, GetTableInd());
    buf += sizeof(uint32_t);

    // 写入 nullable_
    MACH_WRITE_TO(bool, buf, nullable_);
    buf += sizeof(bool);

    // 写入 unique_
    MACH_WRITE_TO(bool, buf, unique_);
    buf += sizeof(bool);

    return buf - copy;
}

uint32_t Column::GetSerializedSize() const {
    return sizeof(uint32_t) * 4 + sizeof(GetName().size()) + sizeof(TypeId) + sizeof(bool) * 2;
}

uint32_t Column::DeserializeFrom(char* buf, Column*& column) {
    char* copy = buf;  // 指向buf一开始的位置
    // magic_num
    uint32_t magic_num = MACH_READ_FROM(uint32_t, buf);
    buf += sizeof(uint32_t);
    ASSERT(magic_num == COLUMN_MAGIC_NUM, "ERROR: COLUMN MAGIC NUMBER");

    // name_
    uint32_t nameLength = MACH_READ_FROM(uint32_t, buf);
    buf += sizeof(uint32_t);
    std::string name;
    char c;
    for (uint32_t i = 0; i < nameLength; i++) {
        char c = MACH_READ_FROM(char, buf);
        buf += 1;
        name += c;
    }

    // type_
    TypeId type = MACH_READ_FROM(TypeId, buf);
    buf += sizeof(TypeId);

    // len_
    uint32_t len = MACH_READ_FROM(uint32_t, buf);
    buf += sizeof(uint32_t);

    // table_ind_
    uint32_t table_ind = MACH_READ_FROM(uint32_t, buf);
    buf += sizeof(uint32_t);

    // nullable_
    bool nullable = MACH_READ_FROM(bool, buf);
    buf += sizeof(bool);

    // unique_
    bool unique = MACH_READ_FROM(bool, buf);
    buf += sizeof(bool);

    if (type == kTypeChar) {  // for char type len_ is the maximum byte length of the string data,
        column = new Column(name, type, len, table_ind, nullable, unique);
    } else {  // otherwise is the fixed size
        column = new Column(name, type, table_ind, nullable, unique);
    }

    return buf - copy;
}
