#include "record/schema.h"
/*
    未被测试过，可能爆雷
*/
uint32_t Schema::SerializeTo(char* buf) const {
    char* copy = buf;
    // magic number
    MACH_WRITE_TO(uint32_t, buf, SCHEMA_MAGIC_NUM);
    buf += sizeof(uint32_t);

    // column number
    uint32_t columnsNum = columns_.size();
    MACH_WRITE_TO(uint32_t, buf, columnsNum);
    buf += sizeof(uint32_t);

    // is_manage
    MACH_WRITE_TO(bool, buf, is_manage_);
    buf += sizeof(bool);

    // column pointers
    for (uint32_t i = 0; i < columnsNum; i++) {
        buf += columns_[i]->SerializeTo(buf);
    }
    return buf - copy;
}

uint32_t Schema::GetSerializedSize() const {
    uint32_t ret = sizeof(uint32_t) * 2 + sizeof(bool);
    for (auto& it : columns_) {
        ret += it->GetSerializedSize();
    }
    return ret;
}

uint32_t Schema::DeserializeFrom(char* buf, Schema*& schema) {
    char* copy = buf;
    // magic number
    uint32_t magic_number = MACH_READ_FROM(uint32_t, buf);
    buf += sizeof(uint32_t);
    ASSERT(magic_number == SCHEMA_MAGIC_NUM, "ERROR: SCHEMA MAGIC NUMBER");

    // colunms num
    uint32_t columnsNum = MACH_READ_FROM(uint32_t, buf);
    buf += sizeof(uint32_t);

    // is_manage
    bool is_manage = MACH_READ_FROM(bool, buf);
    buf += sizeof(bool);

    // columns
    std::vector<Column*> columns;
    for (uint32_t i = 0; i < columnsNum; i++) {
        Column* col;
        buf += col->DeserializeFrom(buf, col);
        columns.push_back(col);
    }
    schema = new Schema(columns, is_manage);
    return buf - copy;
}