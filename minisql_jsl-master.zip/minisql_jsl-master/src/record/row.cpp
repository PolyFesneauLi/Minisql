#include "record/row.h"

uint32_t Row::SerializeTo(char* buf, Schema* schema) const {
    ASSERT(schema != nullptr, "Invalid schema before serialize.");
    ASSERT(schema->GetColumnCount() == fields_.size(), "Fields size do not match schema's column size.");
    char* copy = buf;
    // 存入字段数
    uint32_t FieldNums = GetFieldCount();
    MACH_WRITE_TO(uint32_t, buf, FieldNums);
    buf += sizeof(uint32_t);
    // 用 null bitmap 记录是否为 null
    for (uint32_t i = 0; i < GetFieldCount(); ++i) {
        MACH_WRITE_TO(bool, buf, GetField(i)->IsNull());
        buf += sizeof(bool);
    }
    for (uint32_t i = 0; i < GetFieldCount(); ++i) {
        if (!GetField(i)->IsNull())
            buf += GetField(i)->SerializeTo(buf);
    }
    return buf - copy;
}

uint32_t Row::DeserializeFrom(char* buf, Schema* schema) {
    ASSERT(schema != nullptr, "Invalid schema before serialize.");
    ASSERT(fields_.empty(), "Non empty field in row.");

    fields_.clear();  // 因为反序列化出来的Field的内存由该Row对象维护，所以先清空Row原先的内存
    char* copy = buf;
    // 读出列数
    uint32_t FieldNums = MACH_READ_FROM(uint32_t, buf);
    buf += sizeof(uint32_t);

    // 读出位图
    bool bitmap[FieldNums];
    for (uint32_t i = 0; i < FieldNums; i++) {
        bitmap[i] = MACH_READ_FROM(bool, buf);
        buf += sizeof(bool);
    }
    // 读fields
    for (int i = 0; i < FieldNums; ++i) {
        Field* f = new Field(schema->GetColumn(i)->GetType());
        fields_.push_back(f);
        if (!bitmap[i]) {
            buf += Field::DeserializeFrom(buf, schema->GetColumn(i)->GetType(), &fields_[i], false);
        }
    }
    return buf - copy;
}

uint32_t Row::GetSerializedSize(Schema* schema) const {
    ASSERT(schema != nullptr, "Invalid schema before serialize.");
    ASSERT(schema->GetColumnCount() == fields_.size(), "Fields size do not match schema's column size.");

    uint32_t FieldNums = GetFieldCount();  // 找到一共几列
    uint32_t ret = sizeof(uint32_t);       // 开头储存总数的一个unsigned int
    for (int i = 0; i < FieldNums; i++) {
        ret += sizeof(bool);
        if (!GetField(i)->IsNull())
            ret += GetField(i)->GetSerializedSize();
    }
    return ret;
}

void Row::GetKeyFromRow(const Schema* schema, const Schema* key_schema, Row& key_row) {
    auto columns = key_schema->GetColumns();
    std::vector<Field> fields;
    uint32_t idx;
    for (auto column : columns) {
        schema->GetColumnIndex(column->GetName(), idx);
        fields.emplace_back(*this->GetField(idx));
    }
    key_row = Row(fields);
}
