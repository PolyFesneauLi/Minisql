#include "catalog/catalog.h"

void CatalogMeta::SerializeTo(char* buf) const {
    ASSERT(GetSerializedSize() <= PAGE_SIZE, "Failed to serialize catalog metadata.");
    // advances the buffer pointer by 4 bytes
    MACH_WRITE_UINT32(buf, CATALOG_METADATA_MAGIC_NUM);  // CATALOG_METADATA_MAGIC_NUM need to be initialize
    buf += 4;
    MACH_WRITE_UINT32(buf, table_meta_pages_.size());
    buf += 4;
    MACH_WRITE_UINT32(buf, index_meta_pages_.size());
    buf += 4;
    for (auto iter : table_meta_pages_) {
        MACH_WRITE_TO(table_id_t, buf, iter.first);
        buf += 4;
        MACH_WRITE_TO(page_id_t, buf, iter.second);
        buf += 4;
    }
    for (auto iter : index_meta_pages_) {
        MACH_WRITE_TO(index_id_t, buf, iter.first);
        buf += 4;
        MACH_WRITE_TO(page_id_t, buf, iter.second);
        buf += 4;
    }
}

CatalogMeta* CatalogMeta::DeserializeFrom(char* buf) {
    // check valid
    uint32_t magic_num = MACH_READ_UINT32(buf);
    buf += 4;
    ASSERT(magic_num == CATALOG_METADATA_MAGIC_NUM, "Failed to deserialize catalog metadata from disk.");
    // get table and index nums
    uint32_t table_nums = MACH_READ_UINT32(buf);
    buf += 4;
    uint32_t index_nums = MACH_READ_UINT32(buf);
    buf += 4;
    // create metadata and read value
    CatalogMeta* meta = new CatalogMeta();
    for (uint32_t i = 0; i < table_nums; i++) {
        auto table_id = MACH_READ_FROM(table_id_t, buf);
        buf += 4;
        auto table_heap_page_id = MACH_READ_FROM(page_id_t, buf);
        buf += 4;
        meta->table_meta_pages_.emplace(table_id, table_heap_page_id);
    }
    for (uint32_t i = 0; i < index_nums; i++) {
        auto index_id = MACH_READ_FROM(index_id_t, buf);
        buf += 4;
        auto index_page_id = MACH_READ_FROM(page_id_t, buf);
        buf += 4;
        meta->index_meta_pages_.emplace(index_id, index_page_id);
    }
    return meta;
}

/**
 * TODO: Student Implement
 */
uint32_t CatalogMeta::GetSerializedSize() const {
    //total number of page* page size  + 2 addditional 
    return (table_meta_pages_.size() + index_meta_pages_.size()) * (sizeof(uint32_t) + sizeof(int)) + 2 * sizeof(uint32_t);
}

CatalogMeta::CatalogMeta() {}

/**
 * TODO: Student Implement
 */
CatalogManager::CatalogManager(BufferPoolManager* buffer_pool_manager, LockManager* lock_manager, LogManager* log_manager, bool init)
    : buffer_pool_manager_(buffer_pool_manager), lock_manager_(lock_manager), log_manager_(log_manager) {
        // we do not need the parameter heap anymore
    if (init) {
        catalog_meta_ = CatalogMeta::NewInstance();  
        next_table_id_ = next_index_id_ = 0;
    } else {
        // fetch the page 
        Page* catalogMetaPage = buffer_pool_manager->FetchPage(CATALOG_META_PAGE_ID);
        // to initalize a new instance from database, we need deserialize 
        // when flush the page into disk we need serizalize 
        catalog_meta_ = CatalogMeta::DeserializeFrom(catalogMetaPage->GetData());
        // store the info 
        next_table_id_ = catalog_meta_->GetNextTableId();
        next_index_id_ = catalog_meta_->GetNextIndexId();
        // use begin and end to iter the pages
        auto iter_t = catalog_meta_->table_meta_pages_.begin();
        while (iter_t != catalog_meta_->table_meta_pages_.end()) {
            if (INVALID_PAGE_ID != iter_t->second ) {  // second element is the page id 
                LoadTable(iter_t->first, iter_t->second);  // load the info in pairs 
            }
            ++iter_t;
        }
        auto iter_i = catalog_meta_->index_meta_pages_.begin();
        while (iter_i != catalog_meta_->index_meta_pages_.end()) {
            if (INVALID_PAGE_ID != iter_i->second ) {  // second element is the page id 
                LoadIndex(iter_i->first, iter_i->second);  // load the info in pairs 
            }
            ++iter_i;
        }
        //release the page  and set the page tidy 
        buffer_pool_manager->UnpinPage(CATALOG_META_PAGE_ID, false);
    }
}

CatalogManager::~CatalogManager() {
    // store the page data 
    FlushCatalogMetaPage();
    delete catalog_meta_;
    for (auto iter : tables_) delete iter.second;
    for (auto iter : indexes_) delete iter.second;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::CreateTable(const string& table_name, TableSchema* schema, Transaction* txn, TableInfo*& table_info) {
    // get new table ID
    table_id_t newTableId = next_table_id_;

    if (table_names_.find(table_name) != table_names_.end()) {
        return DB_TABLE_ALREADY_EXIST;
    }

    page_id_t newTablePageId;
    auto newPage = buffer_pool_manager_->NewPage(newTablePageId);
    if (newPage == nullptr) {
        throw runtime_error("all page pinned while CatalogManager::CreateTable");
    }

    // update CatalogMeta
    catalog_meta_->table_meta_pages_[newTableId] = newTablePageId;
    catalog_meta_->table_meta_pages_[newTableId + 1] = INVALID_PAGE_ID;

    // create new TableInfo
    table_info = TableInfo::Create();
    auto* tableHeap = TableHeap::Create(buffer_pool_manager_, schema, txn,
                                        log_manager_, lock_manager_);
    auto* tableMetaData = TableMetadata::Create(newTableId, table_name,
                                                tableHeap->GetFirstPageId(), schema);
    // the new created data need transform to let Init receive 
    tableMetaData->SerializeTo(newPage->GetData());
    // initializeation of table 
    table_info->Init(tableMetaData, tableHeap);
    // release 
    buffer_pool_manager_->UnpinPage(newTablePageId,true);

    //update CatalogManager
    next_table_id_++;
    // push into the stack 
    table_names_.emplace(table_name, newTableId);
    tables_.emplace(newTableId, table_info);

    return DB_SUCCESS;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::GetTable(const string& table_name, TableInfo*& table_info) {
    if (table_names_.find(table_name) == table_names_.end()) {
        return DB_TABLE_NOT_EXIST;
    }
    else{
        return GetTable(table_names_[table_name], table_info);
    }
}

dberr_t CatalogManager::GetTable(const table_id_t table_id, TableInfo*& table_info) {
    if (tables_.find(table_id) == tables_.end()) {
        return DB_FAILED;
    }
    // get the data of the table 
    table_info = tables_[table_id]; 
    return DB_SUCCESS;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::GetTables(vector<TableInfo*>& tables) const {
    auto iter = tables_.begin();
    while (iter != tables_.end()) {  //attention : the bound 
        tables.push_back(iter->second);
        iter++;
    }
    return DB_SUCCESS;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::CreateIndex(const std::string& table_name, const string& index_name, const std::vector<std::string>& index_keys, Transaction* txn, IndexInfo*& index_info, const string& index_type) {
    TableInfo* new_table;
    if (GetTable(table_name, new_table) != DB_SUCCESS)
        return DB_TABLE_NOT_EXIST;
    // detect the index of the table 
    if (index_names_[table_name].find(index_name) != index_names_[table_name].end()) {
        return DB_INDEX_ALREADY_EXIST;
    }
    // whether the column exist 
    Schema* schema = new_table->GetSchema();  // schema used to store the message of sql operation 
    vector<uint32_t>* key_map = new vector<uint32_t>;
    for (const auto& s : index_keys) {
        uint32_t col_index;
        if (schema->GetColumnIndex(s, col_index) != DB_SUCCESS){
            return DB_COLUMN_NAME_NOT_EXIST;
        }
        (*key_map).push_back(col_index);
        //  const Column* col = schema->GetColumn(col_index) ;
    }
    // create 
    index_info = IndexInfo::Create();
    // 更新索引页，获取下一个索引 Id
    index_id_t index_id = next_index_id_;
    // 初始化 Metadata
    IndexMetadata* index_meta_data = IndexMetadata::Create(index_id, index_name, new_table->GetTableId(),
                                                           (*key_map));
    /*LOG(INFO) << "index " << index_meta_data->GetIndexId() << ' ' << index_meta_data->GetIndexName()
    << " " << index_meta_data->GetTableId() << "\nMAP\n" ;
    auto &GG = index_meta_data->GetKeyMapping() ;
    for(auto v : GG) LOG(INFO) << v <<' ';

    LOG(INFO) << "Table " << table_info->GetRootPageId() <<' ' << table_info->GetTableId() << ' '
    << table_info->GetTableName() << '\n';
    const auto &PP = table_info->GetSchema()->GetColumns() ;
    LOG(INFO) << "SIZ " << PP.size() << '\n';
    for(auto v : PP) LOG(INFO) << v->GetName() << ' ' ;*/
    index_info->Init(index_meta_data, new_table, buffer_pool_manager_);  // 这一步构建 b+树索引
    auto& page_id = catalog_meta_->index_meta_pages_[index_id];
    catalog_meta_->index_meta_pages_[index_id + 1] = INVALID_PAGE_ID;
    Page* page = buffer_pool_manager_->NewPage(page_id);
    if (page == nullptr)
        throw runtime_error("DB_FAILED");
    char* page_data = page->GetData();
    // 数据序列化
    index_meta_data->SerializeTo(page_data);
    catalog_meta_->index_meta_pages_[index_id] = page_id;
    buffer_pool_manager_->UnpinPage(page_id, false);
    //    Page* zero = buffer_pool_manager_->FetchPage(0);
    //    ASSERT(zero != nullptr , "zero is fetched") ;
    //    catalog_meta_->SerializeTo(zero->GetData()) ;
    indexes_[index_id] = index_info;
    index_names_[table_name][index_name] = index_id;
    next_index_id_ = catalog_meta_->GetNextIndexId();
    return DB_SUCCESS;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::GetIndex(const std::string& table_name, const std::string& index_name, IndexInfo*& index_info) const {
    auto table_iter = index_names_.find(table_name);
    if (table_iter == index_names_.end()) {
        return DB_INDEX_NOT_FOUND;
    }

    const auto& index_map = table_iter->second;
    auto index_iter = index_map.find(index_name);
    if (index_iter == index_map.end()) {
        return DB_INDEX_NOT_FOUND;
    }

    index_info = indexes_.at(index_iter->second);
    return DB_SUCCESS;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::GetTableIndexes(const std::string& table_name, std::vector<IndexInfo*>& indexes) const {
    auto table_iter = index_names_.find(table_name);
    if (table_iter == index_names_.end()) {
        return DB_SUCCESS;  // No indexes for the given table
    }

    const auto& index_map = table_iter->second;
    for (const auto& index_pair : index_map) {
        indexes.push_back(indexes_.at(index_pair.second));
    }

    return DB_SUCCESS;
}


/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::DropTable(table_id_t tableId) {
    // Delete the corresponding table and data pages
    tables_[tableId]->GetTableHeap()->DeleteTable();
    buffer_pool_manager_->DeletePage(catalog_meta_->table_meta_pages_[tableId]);

    // Update CatalogMeta
    catalog_meta_->table_meta_pages_.erase(tableId);

    // Free space in the heap
    //heap_->Free(tables_[tableId]);

    // Remove table records from CatalogManager
    table_names_.erase(tables_[tableId]->GetTableName());
    tables_.erase(tableId);
    return DB_SUCCESS;
}


dberr_t CatalogManager::DropTable(const std::string& table_name) {
    // First, check if the table to be dropped exists
    if (table_names_.find(table_name) == table_names_.end()) {
        return DB_TABLE_NOT_EXIST;
    }

    // Get the table ID
    table_id_t tableId = table_names_[table_name];

    return DropTable(tableId);
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::DropIndex(const std::string& table_name, const std::string& index_name) {
    // First, check if the index to be dropped exists
    if (index_names_[table_name].find(index_name) == index_names_[table_name].end()) {
        return DB_INDEX_NOT_FOUND;
    }

    // Get the ID of the index to be dropped
    index_id_t indexId = index_names_[table_name][index_name];

    // Destroy the index and data pages
    indexes_[indexId]->GetIndex()->Destroy();
    buffer_pool_manager_->DeletePage(catalog_meta_->index_meta_pages_[indexId]);

    // Update CatalogMeta
    catalog_meta_->index_meta_pages_.erase(indexId);

    // Free space in the heap
    /////heap_->Free(indexes_[indexId]);

    // Remove index records from CatalogManager
    indexes_.erase(indexId);
    index_names_[table_name].erase(index_name);

    return DB_SUCCESS;
}


/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::FlushCatalogMetaPage() const {
    Page* page = buffer_pool_manager_->FetchPage(CATALOG_META_PAGE_ID);
    // change the data in to byte type 
    // so it can be maintained and send to api of destination: local catalaogmeta
    // maintain the root page 
    this->catalog_meta_->SerializeTo(page->GetData());
    // set the dirty info, so the buffer will rewrite the page
    buffer_pool_manager_->UnpinPage(CATALOG_META_PAGE_ID, true);


    std::vector<TableInfo*> table_infos;
    this->GetTables(table_infos);
    // the table is iterable
    // flush the child pages 
    for (auto table : table_infos) {
        Page* page = this->buffer_pool_manager_->FetchPage(table->GetRootPageId());
        table->table_meta_->SerializeTo(page->GetData());
        this->buffer_pool_manager_->UnpinPage(table->GetRootPageId(), true);
    }

    // last flush compeletely 
    if (buffer_pool_manager_->FlushPage(CATALOG_META_PAGE_ID)) {
        return DB_SUCCESS;
    }
    return DB_FAILED;
}

/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::LoadTable(const table_id_t table_id, const page_id_t page_id) {
    // First, fetch the corresponding page
    Page* page = buffer_pool_manager_->FetchPage(page_id);
    if (page == nullptr) {
        throw std::runtime_error("All pages are pinned while executing CatalogManager::LoadTable");
    }

    // Create the corresponding TableInfo
    TableInfo* table_info = TableInfo::Create();

    // Deserialize TableMetadata
    TableMetadata* table_metadata = nullptr;
    if (!TableMetadata::DeserializeFrom(page->GetData(), table_metadata)) {
        buffer_pool_manager_->UnpinPage(page_id, false);
        return DB_FAILED;
    }

    // Create TableHeap
    TableHeap* table_heap = TableHeap::Create(buffer_pool_manager_, table_metadata->GetFirstPageId(),
                                             table_metadata->GetSchema(), log_manager_, lock_manager_);

    // Initialize table_info
    table_info->Init(table_metadata, table_heap);

    // Update the information in CatalogManager
    tables_.emplace(table_id, table_info);
    table_names_.emplace(table_metadata->GetTableName(), table_id);

    // Unpin the corresponding page
    buffer_pool_manager_->UnpinPage(page_id, false);

    return DB_SUCCESS;
}



/**
 * TODO: Student Implement
 */
dberr_t CatalogManager::LoadIndex(const index_id_t index_id, const page_id_t page_id) {
    // First, fetch the data page
    Page* page = buffer_pool_manager_->FetchPage(page_id);
    if (page == nullptr) {
        throw std::runtime_error("All pages are pinned while executing CatalogManager::LoadIndex");
    }

    // Create the corresponding IndexInfo
    IndexInfo* index_info = IndexInfo::Create();

    // Deserialize IndexMetadata
    IndexMetadata* index_metadata = nullptr;
    if (!IndexMetadata::DeserializeFrom(page->GetData(), index_metadata)) {
        buffer_pool_manager_->UnpinPage(page_id, false);
        return DB_FAILED;
    }

    // Initialize IndexInfo
    index_info->Init(index_metadata, tables_[index_metadata->GetTableId()], buffer_pool_manager_);
    // Set the root page
    
    index_info->setRootPageId();
    //    std::cout << "CatalogManager::LoadIndex: indexInfo->meta_data_->getRootPageId(): " << index_info->meta_data_->getRootPageId() << std::endl;

    // Update the information in CatalogManager
    indexes_.emplace(index_id, index_info);
    index_names_[tables_[index_metadata->GetTableId()]->GetTableName()].emplace(index_metadata->GetIndexName(), index_id);

    // Unpin the page
    buffer_pool_manager_->UnpinPage(page_id, false);

    return DB_SUCCESS;
}
