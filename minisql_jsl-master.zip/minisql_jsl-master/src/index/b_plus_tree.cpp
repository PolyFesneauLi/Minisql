#include "index/b_plus_tree.h"

#include <string>

#include "glog/logging.h"
#include "index/generic_key.h"
#include "page/index_roots_page.h"

/**
 * 初始化 b+ 树
 */
BPlusTree::BPlusTree(index_id_t index_id, BufferPoolManager *buffer_pool_manager, const KeyManager &KM,
                     int leaf_max_size, int internal_max_size)
    : index_id_(index_id),
      buffer_pool_manager_(buffer_pool_manager),
      processor_(KM),
      leaf_max_size_(leaf_max_size),
      internal_max_size_(internal_max_size) {
  auto *page = buffer_pool_manager_->FetchPage(TREE_INDEX_META);  // 取出储存 index 的页
  /**
   * 3 和 4 之间的联系，一个表使用一个b+树来存储，
   * 并记录它们的 id 和对应的 index，可以通过 index 来获取 id
   */
  IndexRootsPage * indexRootsPage = reinterpret_cast<IndexRootsPage *>(page);
  indexRootsPage->GetRootId(index_id, &root_page_id_);  // 获取根节点的 id
//  this->root_page_id_ = INVALID_PAGE_ID; // 尚未存储根节点
  if(leaf_max_size == 0) {  // 如果没有传入最大值，则利用 key_size 进行计算
    leaf_max_size_ = (PAGE_SIZE - LEAF_PAGE_HEADER_SIZE) / (KM.GetKeySize() + sizeof(RowId)) - 1;
    internal_max_size_ = leaf_max_size_ + 1;  // 比叶子大一
  }
  buffer_pool_manager_->UnpinPage(TREE_INDEX_META, false);
  buffer_pool_manager_->UnpinPage(root_page_id_, false);
}

void BPlusTree::Destroy() {  // 都是删除整棵树
//  this->buffer_pool_manager_->UnpinPage(current_page_id, true);  // 把当前页取消固定
  IndexRootsPage* indexRootsPage = reinterpret_cast<IndexRootsPage*>(buffer_pool_manager_->FetchPage(TREE_INDEX_META));
  indexRootsPage->GetRootId(index_id_, &root_page_id_);
  if(root_page_id_ == INVALID_PAGE_ID) {  // 没有建树
    buffer_pool_manager_->UnpinPage(TREE_INDEX_META, false);
    return ;
  }
  else{
    indexRootsPage->Delete(index_id_); // 在表中删除根节点记录
    buffer_pool_manager_->UnpinPage(TREE_INDEX_META, true);
    auto * page = reinterpret_cast<BPlusTreePage *>(buffer_pool_manager_->FetchPage(root_page_id_)->GetData());
    if(page->IsLeafPage()){
      DestroyAllLeaf(page->GetPageId());
    }
    else{   // 删除该页，删除所有子节点
      DestroyInternalPage(page->GetPageId());
    }
  }
}

// 增添了一个删除所有叶子节点的函数
void BPlusTree::DestroyAllLeaf(page_id_t pageId){
  LeafPage * leafPage;
  while(pageId != INVALID_PAGE_ID){  // 将整块的叶子顺序删除
    leafPage = reinterpret_cast<LeafPage *>(buffer_pool_manager_->FetchPage(pageId));
    buffer_pool_manager_->DeletePage(leafPage->GetPageId());
    pageId = leafPage->GetNextPageId();
  }
}

// 增添一个函数删除内部节点
void BPlusTree::DestroyInternalPage(page_id_t pageId) {
  InternalPage * internalPage = reinterpret_cast<InternalPage *>(buffer_pool_manager_->FetchPage(pageId));
  page_id_t parentId = internalPage->GetParentPageId();
  if(parentId != INVALID_PAGE_ID){
    InternalPage * parent = reinterpret_cast<InternalPage *>(buffer_pool_manager_->FetchPage(parentId));
    buffer_pool_manager_->UnpinPage(parentId, false);
    int index = parent->ValueIndex(internalPage->GetPageId());
    BPlusTreePage* childPage = reinterpret_cast<BPlusTreePage*>(buffer_pool_manager_->FetchPage(internalPage->ValueAt(0)));
    buffer_pool_manager_->UnpinPage(childPage->GetPageId(), false);
    if(childPage->IsLeafPage()){
      DestroyAllLeaf(childPage->GetPageId());
    }
    else{ //  依次删除下一层
      DestroyInternalPage(childPage->GetPageId());
    }
    buffer_pool_manager_->DeletePage(pageId); // 删除节点
    if(index < parent->GetSize() - 1){  // 如果还没有删除到最后一个孩子
      DestroyInternalPage(parent->ValueAt(index+1));  // 删除下一个内部节点
    }
  }
}

/*
 * Helper function to decide whether current b+tree is empty
 */
bool BPlusTree::IsEmpty() const {
  return this->root_page_id_ == INVALID_PAGE_ID;
}

/*****************************************************************************
 * SEARCH
 *****************************************************************************/
/*
 * Return the only value that associated with input key
 * This method is used for point query
 * @return : true means key exists
 */
bool BPlusTree::GetValue(const GenericKey *key, std::vector<RowId> &result, Transaction *transaction) {
  if(this->IsEmpty()) return false;
  auto * page = this->FindLeafPage(key, this->root_page_id_, false);
  if(page == NULL) throw runtime_error("Do not fetch when GetValue");
  RowId value;
  auto *leaf_page = reinterpret_cast<LeafPage *>(page->GetData());
  // leaf_page->SetPageType(IndexPageType::LEAF_PAGE);
  if(leaf_page->Lookup(key, value, this->processor_)){  // 这个数据页中有该键值
    result.push_back(value);
    buffer_pool_manager_->UnpinPage(page->GetPageId(), false);
    return true;
  }
  // 处理完之后取消固定数据页
  buffer_pool_manager_->UnpinPage(page->GetPageId(), false);
  return false;
}

/*****************************************************************************
 * INSERTION
 *****************************************************************************/
/*
 * Insert constant key & value pair into b+ tree
 * if current tree is empty, start new tree, update root page id and insert
 * entry, otherwise insert into leaf page.
 * @return: since we only support unique key, if user try to insert duplicate
 * keys return false, otherwise return true.
 */
bool BPlusTree::Insert(GenericKey *key, const RowId &value, Transaction *transaction) {
  if(this->IsEmpty()){
    this->StartNewTree(key, value);
    return true;
  }
  // 找到要插入的那一叶子页
  LeafPage * page = reinterpret_cast<LeafPage *>(this->FindLeafPage(key, this->root_page_id_, false));
  // page->SetPageType(IndexPageType::LEAF_PAGE);
  RowId new_value;
  if(page->Lookup(key, new_value, this->processor_)){  // 这个数据页中有该键值
    buffer_pool_manager_->UnpinPage(page->GetPageId(), false); // 释放
    return false;
  }
  page->Insert(key, value, this->processor_); // 插入该值
  // 处理叶节点的分裂
  if (page->GetSize() > page->GetMaxSize()) {
    LeafPage *newLeaf = this->Split(page, transaction);  // 获取分裂后的新节点
    this->InsertIntoParent(page, newLeaf->KeyAt(0), newLeaf, transaction); // 把新节点插入父节点
  }
  buffer_pool_manager_->UnpinPage(page->GetPageId(), true); // 解锁，更新脏页
  return true;
}

/*
 * Insert constant key & value pair into an empty tree
 * User needs to first ask for new page from buffer pool manager(NOTICE: throw
 * an "out of memory" exception if returned value is nullptr), then update b+
 * tree's root page id and insert entry directly into leaf page.
 */
void BPlusTree::StartNewTree(GenericKey *key, const RowId &value) {
  this->UpdateRootPageId(1);  // 更新b+树根节点页码
  // index_id_++;  // 建立了一棵新的树，建立一个新的索引
  Page *page = this->buffer_pool_manager_->FetchPage(root_page_id_);
  // 取出根节点
  if(page == NULL)  throw runtime_error("out of memory"); // 所有内存页都被锁了
  auto *leaf_node = reinterpret_cast<LeafPage *>(page->GetData());
  // 新树的根节点是叶子，进行初始化（key大小，节点种类）
  leaf_node->Init(page->GetPageId(), INVALID_PAGE_ID, processor_.GetKeySize(), this->leaf_max_size_);
//  if(this->leaf_max_size_ == UNDEFINED_SIZE){  // 经过计算赋初值
//    // 选择较小的最大值作为叶子页数的最大值初值，内部节点键值对数量比叶子节点键值对数量大一
//    this->leaf_max_size_ = leaf_node->GetMaxSize() > (INTERNAL_PAGE_SIZE - 1) ? (INTERNAL_PAGE_SIZE - 1) : leaf_node->GetMaxSize();
//    this->internal_max_size_ = leaf_max_size_ + 1;
//  }
  leaf_node->Insert(key, value, this->processor_);  // 将数据插入
  buffer_pool_manager_->UnpinPage(root_page_id_, true); // 解除锁定并把数据写入内存
}

/*
 * Insert constant key & value pair into leaf page
 * User needs to first find the right leaf page as insertion target, then look
 * through leaf page to see whether insert key exist or not. If exist, return
 * immediately, otherwise insert entry. Remember to deal with split if necessary.
 * @return: since we only support unique key, if user try to insert duplicate
 * keys return false, otherwise return true.
 */

bool BPlusTree::InsertIntoLeaf(GenericKey *key, const RowId &value, Transaction *transaction) {
  return this->Insert(key, value, transaction);
}

/*
 * Split input page and return newly created page.
 * Using template N to represent either internal page or leaf page.
 * User needs to first ask for new page from buffer pool manager(NOTICE: throw
 * an "out of memory" exception if returned value is nullptr), then move half
 * of key & value pairs from input page to newly created page
 */
BPlusTreeInternalPage *BPlusTree::Split(InternalPage *node, Transaction *transaction) {
  page_id_t page_Id;
  InternalPage * newLeaf = reinterpret_cast<InternalPage *>(this->buffer_pool_manager_->NewPage(page_Id));
  if(newLeaf == NULL){  // 建立新页失败
    throw runtime_error("out of memory");
  }
  newLeaf->Init(page_Id, node->GetParentPageId(), node->GetKeySize(), node->GetMaxSize()); // 初始化
  node->MoveHalfTo(newLeaf, this->buffer_pool_manager_);  // 各一半
  return newLeaf;
}

// 将一个叶子节点分成两半
BPlusTreeLeafPage *BPlusTree::Split(LeafPage *node, Transaction *transaction) {
  page_id_t page_Id;
  LeafPage * newLeaf = reinterpret_cast<LeafPage *>(this->buffer_pool_manager_->NewPage(page_Id));
  if(newLeaf == NULL){  // 建立新页失败
    throw runtime_error("out of memory");
  }
  newLeaf->Init(page_Id, node->GetParentPageId(), processor_.GetKeySize(), node->GetMaxSize()); // 初始化
  node->MoveHalfTo(newLeaf);  // 各一半
  newLeaf->SetNextPageId(node->GetNextPageId());
  node->SetNextPageId(newLeaf->GetPageId());  // 处理链表
  return newLeaf;
}

/*
 * Insert key & value pair into internal page after split
 * @param   old_node      input page from split() method
 * @param   key
 * @param   new_node      returned page from split() method
 * User needs to first find the parent page of old_node, parent node must be
 * adjusted to take info of new_node into account. Remember to deal with split
 * recursively if necessary.
 */
// 内部节点插入一个新的节点
void BPlusTree::InsertIntoParent(BPlusTreePage *old_node, GenericKey *key, BPlusTreePage *new_node,
                                 Transaction *transaction) {
  if(old_node->GetParentPageId() == INVALID_PAGE_ID){ // 传入的节点是根节点
    page_id_t root_Id;  // 建立一个新的根节点
    InternalPage * newRoot = reinterpret_cast<InternalPage *>(this->buffer_pool_manager_->NewPage(root_Id)); // 新建
    if(newRoot == NULL){
      throw runtime_error("out of mem");  // 分配失败
    }
    newRoot->Init(root_Id, INVALID_PAGE_ID, old_node->GetKeySize(), internal_max_size_); // 初始化
    root_page_id_ = newRoot->GetPageId(); // 更新 rootPageId
    this->UpdateRootPageId(0);  // 更新存在 index 中的 rootId
    old_node->SetParentPageId(root_Id); // 更新指向根节点的指针
    new_node->SetParentPageId(root_Id);
    newRoot->PopulateNewRoot(old_node->GetPageId(), key, new_node->GetPageId()); // 将两个node插入root
    buffer_pool_manager_->UnpinPage(root_Id, true); // 更新＋释放
    buffer_pool_manager_->UnpinPage(old_node->GetPageId(), true);
    buffer_pool_manager_->UnpinPage(new_node->GetPageId(), true);
    return;
  }
  // 找到需要插入的父亲
  InternalPage * internalPage = reinterpret_cast<InternalPage *>(this->buffer_pool_manager_->FetchPage(old_node->GetParentPageId()));
//  internalPage->SetPageType(IndexPageType::INTERNAL_PAGE);
  int index = internalPage->ValueIndex(old_node->GetPageId()); // 之前的节点在父亲的位置
  if(index == 0){
    LeafPage* old_chile = reinterpret_cast<LeafPage *>(this->FindLeafPage(key, old_node->GetPageId(), true));
    GenericKey* new_key = old_chile->KeyAt(0);  // 更新时需要将之前为空的值记录上
    buffer_pool_manager_->UnpinPage(old_chile->GetPageId(), false);
    internalPage->SetKeyAt(0, new_key);
  }
  internalPage->InsertNodeAfter(old_node->GetPageId(), key, new_node->GetPageId()); // 将 new_node 加入父亲
  new_node->SetParentPageId(internalPage->GetPageId()); // 更新父亲页
  if (internalPage->GetSize() > internalPage->GetMaxSize()){  // 当前节点需要分裂，递归调用
    auto* newNode = this->Split(internalPage, transaction);
    // 父节点插入的是新节点的最左叶子
    GenericKey *keyNull;  // 打酱油的
    auto chPage = reinterpret_cast<LeafPage *>(this->FindLeafPage(keyNull, newNode->GetPageId(), true));
    buffer_pool_manager_->UnpinPage(chPage->GetPageId(), false);
    this->InsertIntoParent(internalPage, chPage->KeyAt(0), newNode);
    buffer_pool_manager_->UnpinPage(newNode->GetPageId(), true);  // 更新＋解锁
  }
  buffer_pool_manager_->UnpinPage(new_node->GetPageId(), true);
  buffer_pool_manager_->UnpinPage(old_node->GetPageId(), true);  // 更新＋解锁
  buffer_pool_manager_->UnpinPage(internalPage->GetPageId(), true);
}

/*****************************************************************************
 * REMOVE
 *****************************************************************************/
/*
 * Delete key & value pair associated with input key
 * If current tree is empty, return immediately.
 * If not, User needs to first find the right leaf page as deletion target, then
 * delete entry from leaf page. Remember to deal with redistribute or merge if
 * necessary.
 */
// 从b+树中删除 key，并从右边进行维护
void BPlusTree::Remove(const GenericKey *key, Transaction *transaction) {
  vector<RowId> result;
  if(!this->GetValue(key, result, transaction)) return ;  // 没有待删除的 key，直接返回
  LeafPage * leafPage = reinterpret_cast<LeafPage *>(FindLeafPage(key, root_page_id_, false)); // 找到待删除的页
  leafPage->SetPageType(IndexPageType::LEAF_PAGE);
  int index = leafPage->RemoveAndDeleteRecord(key, this->processor_); // 删除
  if (leafPage->GetSize() < leafPage->GetMaxSize() / 2){  // 维护b+树
    CoalesceOrRedistribute(leafPage, transaction);
  }
  buffer_pool_manager_->UnpinPage(leafPage->GetPageId(), true);
}

/*
 * User needs to first find the sibling of input page. If sibling's size + input
 * page's size > page's max size, then redistribute. Otherwise, merge.
 * Using template N to represent either internal page or leaf page.
 * @return: true means target leaf page should be deleted, false means no
 * deletion happens
 */
// 删除之后的合并或重分配的维护
template <typename N>
bool BPlusTree::CoalesceOrRedistribute(N *&node, Transaction *transaction) {
  if(node->IsRootPage()){
    return this->AdjustRoot(node);
  }
  if(node->GetSize() >= node->GetMinSize()) // 因为内部节点和叶子节点的键值对本来就不同，所以不用再分类讨论
    return false; // 上述情况删除后没有影响，无需合并
  page_id_t parent_page = node->GetParentPageId();
  InternalPage * parentNode = reinterpret_cast<InternalPage *>(this->buffer_pool_manager_->FetchPage(parent_page)->GetData()); // 获取父亲节点
  if (parentNode == nullptr){
    throw runtime_error("all page are pinned during CoalesceOrRedistribute");
  }
  // parentNode->SetPageType(IndexPageType::INTERNAL_PAGE);
  // 获取当前节点在父节点中的下标位置
  int index = parentNode->ValueIndex(node->GetPageId());
  int sibling_Id;
  if(index == 0){
    sibling_Id = parentNode->ValueAt(index + 1); // 此时只能找右边的兄弟
  }
  else{
    sibling_Id = parentNode->ValueAt(index - 1); // 左兄弟
  }
  this->buffer_pool_manager_->UnpinPage(parent_page, true);
  auto * sibling_Page = reinterpret_cast<N *>(this->buffer_pool_manager_->FetchPage(sibling_Id)->GetData());  // 找到兄弟页
  if (sibling_Page == nullptr){
    throw runtime_error("all page are pinned while CoalesceOrRedistribute");
  }
  if(sibling_Page->GetSize() + node->GetSize() > node->GetMaxSize()){ // 需要重新分配的情况
    this->Redistribute(sibling_Page, node, index);
    return false;
  } // 进行合并
  if(index == 0) {
    this->Coalesce(node, sibling_Page, parentNode, index, transaction);
    return false;   // 此时node没有被删除
  }
  else this->Coalesce(sibling_Page, node, parentNode, index, transaction);
  return true;
}

/*
 * Move all the key & value pairs from one page to its sibling page, and notify
 * buffer pool manager to delete this page. Parent page must be adjusted to
 * take info of deletion into account. Remember to deal with coalesce or
 * redistribute recursively if necessary.
 * Using template N to represent either internal page or leaf page.
 * @param   neighbor_node      sibling page of input "node"
 * @param   node               input from method coalesceOrRedistribute()
 * @param   parent             parent page of input "node"
 * @return  true means parent node should be deleted, false means no deletion happened
 */
// 两个节点融合，删除右边那一页，不用管index，传入已经不同了
bool BPlusTree::Coalesce(LeafPage *&neighbor_node, LeafPage *&node, InternalPage *&parent, int index,
                         Transaction *transaction) {
  node->MoveAllTo(neighbor_node);
  neighbor_node->SetNextPageId(node->GetNextPageId());  // 更新链表
  buffer_pool_manager_->UnpinPage(node->GetPageId(), true); // 删除前先解锁
  buffer_pool_manager_->DeletePage(node->GetPageId());  // 删除右边页
  int reIndex = index == 0 ? 1 : index; // 需要删除点的下标
  parent->Remove(reIndex);  // 从父亲节点中删除右边的节点
  buffer_pool_manager_->UnpinPage(neighbor_node->GetPageId(), true);
  buffer_pool_manager_->UnpinPage(parent->GetPageId(), true); // 更新
  return this->CoalesceOrRedistribute(parent, transaction); // 递归维护 parent 节点
}

bool BPlusTree::Coalesce(InternalPage *&neighbor_node, InternalPage *&node, InternalPage *&parent, int index,
                         Transaction *transaction) {
//  LOG(INFO) << "Coalesce Internal " << index << endl;
  GenericKey * key;
  if(index == 0) {
    LeafPage *leafPage = reinterpret_cast<LeafPage *>(FindLeafPage(key, node->GetPageId(), true));
    key = leafPage->KeyAt(0);
    buffer_pool_manager_->UnpinPage(leafPage->GetPageId(), false);
  }
  else key = parent->KeyAt(index);
  node->MoveAllTo(neighbor_node, key, buffer_pool_manager_);
  buffer_pool_manager_->UnpinPage(node->GetPageId(), true); // 删除前先解锁
  buffer_pool_manager_->DeletePage(node->GetPageId());  // 删除右边页
  int reIndex = index == 0 ? 1 : index; // 需要删除点的下标
  parent->Remove(reIndex);  // 从父亲节点中删除右边的节点
  buffer_pool_manager_->UnpinPage(neighbor_node->GetPageId(), true);
  return this->CoalesceOrRedistribute(parent, transaction); // 递归维护 parent 节点
  return false;
}

/*
 * Redistribute key & value pairs from one page to its sibling page. If index ==
 * 0, move sibling page's first key & value pair into end of input "node",
 * otherwise move sibling page's last key & value pair into head of input
 * "node".
 * Using template N to represent either internal page or leaf page.
 * @param   neighbor_node      sibling page of input "node"
 * @param   node               input from method coalesceOrRedistribute()
 */
// 当删除后需要从兄弟借节点时
void BPlusTree::Redistribute(LeafPage *neighbor_node, LeafPage *node, int index) {
  // 获取父亲节点，在更新子节点后也更新父节点
  InternalPage * parent = reinterpret_cast<InternalPage *>(buffer_pool_manager_->FetchPage(node->GetParentPageId())->GetData());
  if(parent == NULL){
    throw runtime_error("all page are pinned during Redistribute");
  }
  parent->SetPageType(IndexPageType::INTERNAL_PAGE);
  if(index == 0){
    parent->SetKeyAt(1, neighbor_node->KeyAt(1));  // 更新第一个键值
    neighbor_node->MoveFirstToEndOf(node); // 把第一个节点移动到node的末尾
    parent->SetValueAt(1, neighbor_node->GetPageId());  // 更新第二个指针
  }else{
    parent->SetKeyAt(index, neighbor_node->KeyAt(neighbor_node->GetSize() - 1));
    neighbor_node->MoveLastToFrontOf(node); // 把最后一个节点移动到node的头
    parent->SetValueAt(index, node->GetPageId()); // 更新父亲节点中node的头
  }
  buffer_pool_manager_->UnpinPage(parent->GetPageId(), true); // 释放父亲节点
  buffer_pool_manager_->UnpinPage(neighbor_node->GetPageId(), true);
  buffer_pool_manager_->UnpinPage(node->GetPageId(), true); // 释放并更新内存
}

void BPlusTree::Redistribute(InternalPage *neighbor_node, InternalPage *node, int index) {
  // 获取父亲节点，在更新子节点后也更新父节点
//  LOG(INFO) << "Redistribute Internal " << index << endl;
  InternalPage * parent = reinterpret_cast<InternalPage *>(buffer_pool_manager_->FetchPage(node->GetParentPageId())->GetData());
  if(parent == NULL){
    throw runtime_error("all page are pinned during Redistribute");
  }
  if(index == 0){
    GenericKey* fir_key = parent->KeyAt(1);
    parent->SetKeyAt(1, neighbor_node->KeyAt(1));  // 更新第一个键值
    neighbor_node->MoveFirstToEndOf(node, fir_key, buffer_pool_manager_); // 把第一个节点移动到node的末尾
    parent->SetValueAt(1, neighbor_node->GetPageId());  // 更新第二个指针
  }else{
    parent->SetKeyAt(index, neighbor_node->KeyAt(neighbor_node->GetSize() - 1));
    neighbor_node->MoveLastToFrontOf(node, parent->KeyAt(index), buffer_pool_manager_); // 把最后一个节点移动到node的头
    parent->SetValueAt(index, node->GetPageId()); // 更新父亲节点中node的头
  }
  buffer_pool_manager_->UnpinPage(parent->GetPageId(), true); // 释放父亲节点
  buffer_pool_manager_->UnpinPage(neighbor_node->GetPageId(), true);
  buffer_pool_manager_->UnpinPage(node->GetPageId(), true); // 释放并更新内存
}

/*
 * Update root page if necessary
 * NOTE: size of root page can be less than min size and this method is only
 * called within coalesceOrRedistribute() method
 * case 1: when you delete the last element in root page, but root page still
 * has one last child
 * case 2: when you delete the last element in whole b+ tree
 * @return : true means root page should be deleted, false means no deletion
 * happened
 */
bool BPlusTree::AdjustRoot(BPlusTreePage *old_root_node) {
  if(old_root_node->IsLeafPage()) {
    if (old_root_node->GetSize() == 0) {  // 删除这个节点
      root_page_id_ = INVALID_PAGE_ID;
      UpdateRootPageId(0);
      return true;
    }
    else return false;  // 不用调整
  }
  int child_size = 0;
  auto * page = reinterpret_cast<InternalPage *>(old_root_node); // 类型转换
//  page->Init(old_root_node->GetPageId(), old_root_node->GetParentPageId(), processor_.GetKeySize());
  // 获取根节点所有子节点的键值对和
  auto * child1 = reinterpret_cast<BPlusTreePage *>(buffer_pool_manager_->FetchPage(page->ValueAt(0))->GetData());
  child_size += child1->GetSize();      // 如果根节点只有一个孩子，则这个孩子就是新的根节点
  if(old_root_node->GetSize() <= 2) {
    if(old_root_node->GetSize() == 1){
      root_page_id_ = page->ValueAt(0);
      this->UpdateRootPageId(0);  // 只有一个孩子，则这个孩子直接成为新的根
      child1->SetParentPageId(INVALID_PAGE_ID);
      buffer_pool_manager_->UnpinPage(root_page_id_, true);
      buffer_pool_manager_->DeletePage(old_root_node->GetPageId()); // 删除以前的节点
      return true;
    }
    if (old_root_node->GetSize() == 2) {  // 如果根节点有两个孩子，需要判断是否进行合并
      auto *child2 = reinterpret_cast<BPlusTreePage *>(buffer_pool_manager_->FetchPage(page->ValueAt(1))->GetData());
      child_size += child2->GetSize();
      if (child_size < old_root_node->GetMaxSize()) {  // 需要进行融合
        if(child2->IsLeafPage()){
          LeafPage *child2_leaf = reinterpret_cast<LeafPage *>(child2);
          LeafPage *child1_leaf = reinterpret_cast<LeafPage *>(child1);
          child2->SetPageType(IndexPageType::LEAF_PAGE);
          child1->SetPageType(IndexPageType::LEAF_PAGE);
          child2_leaf->MoveAllTo(child1_leaf);
        }
        else{
          InternalPage *child2_leaf = reinterpret_cast<InternalPage *>(child2);
//          child2_leaf->Init(child2->GetPageId(), child2->GetParentPageId(), processor_.GetKeySize());
          InternalPage *child1_leaf = reinterpret_cast<InternalPage *>(child1);
//          child1_leaf->Init(child1->GetPageId(), child1->GetParentPageId(), processor_.GetKeySize());
          // middle_key 储存在 root 中第二个键值对里
          child2_leaf->MoveAllTo(child1_leaf, page->KeyAt(1), buffer_pool_manager_);
        }
        buffer_pool_manager_->DeletePage(child2->GetPageId());  // 删除第二页
        root_page_id_ = page->ValueAt(0);
        this->UpdateRootPageId(0);  // 融合后只剩下 child1
        child1->SetParentPageId(INVALID_PAGE_ID);
        buffer_pool_manager_->UnpinPage(root_page_id_, true);
        buffer_pool_manager_->DeletePage(old_root_node->GetPageId()); // 删除以前的节点
        return true;
      }
    }
  }
  return false;
}

/*****************************************************************************
 * INDEX ITERATOR
 *****************************************************************************/
/*
 * Input parameter is void, find the left most leaf page first, then construct
 * index iterator
 * @return : index iterator
 */
IndexIterator BPlusTree::Begin() {
  // 找的值是任意值，主要是得到最左边的叶子，向左一直找
  LeafPage * leftLeaf = reinterpret_cast<LeafPage *>(this->FindLeafPage(NULL, root_page_id_, true)->GetData());
  leftLeaf->SetPageType(IndexPageType::LEAF_PAGE);
  buffer_pool_manager_->UnpinPage(leftLeaf->GetPageId(), false);
  return IndexIterator(leftLeaf->GetPageId(), buffer_pool_manager_, 0);  // 返回迭代器开头
}

/*
 * Input parameter is low-key, find the leaf page that contains the input key
 * first, then construct index iterator
 * @return : index iterator
 */
IndexIterator BPlusTree::Begin(const GenericKey *key) {
  // 找的值是固定值
  LeafPage * leftLeaf = reinterpret_cast<LeafPage *>(this->FindLeafPage(key, root_page_id_, false)->GetData());
  leftLeaf->SetPageType(IndexPageType::LEAF_PAGE);
  int index = leftLeaf->KeyIndex(key, processor_); // 找到对应的下标
  buffer_pool_manager_->UnpinPage(leftLeaf->GetPageId(), false);
  return IndexIterator(leftLeaf->GetPageId(), buffer_pool_manager_, index);  // 返回迭代器起点
}

/*
 * Input parameter is void, construct an index iterator representing the end
 * of the key/value pair in the leaf node
 * @return : index iterator
 */
IndexIterator BPlusTree::End() {
  LeafPage *newLeaf, *leftLeaf = reinterpret_cast<LeafPage *>(this->FindLeafPage(NULL, root_page_id_, true)->GetData());
  leftLeaf->SetPageType(IndexPageType::LEAF_PAGE);
  while(leftLeaf->GetNextPageId() != INVALID_PAGE_ID) { // 找到最后一个叶子
    newLeaf = reinterpret_cast<LeafPage *>(buffer_pool_manager_->FetchPage(leftLeaf->GetNextPageId())->GetData());
    newLeaf->SetPageType(IndexPageType::LEAF_PAGE);
    buffer_pool_manager_->UnpinPage(leftLeaf->GetPageId(), false);
    leftLeaf = newLeaf;
  } // 返回一个迭代器
  return IndexIterator(leftLeaf->GetPageId(), buffer_pool_manager_, leftLeaf->GetSize() - 1);
}

/*****************************************************************************
 * UTILITIES AND DEBUG
 *****************************************************************************/
/*
 * Find leaf page containing particular key, if leftMost flag == true, find
 * the left most leaf page
 * Note: the leaf page is pinned, you need to unpin it after use.
 */
Page *BPlusTree::FindLeafPage(const GenericKey *key, page_id_t page_id, bool leftMost) {
  if (page_id == INVALID_PAGE_ID) {  // 当前是空树
    throw std::runtime_error("B+TREE_TYPE::FindLeafPage : root_page_id is invalid");
  }
  Page* page = this->buffer_pool_manager_->FetchPage(page_id); // 获取传入 page_id 对应的页
  if (page == nullptr){ // 获取根节点所对应的页面
    throw runtime_error("all page are pinned while FindLeafPage");
  }
  auto* node = reinterpret_cast<BPlusTreePage*>(page->GetData());
  node->SetPageId(page->GetPageId()); // 打了个补丁，其实可以不用
  buffer_pool_manager_->UnpinPage(page_id, false);
  while(!node->IsLeafPage()){ // 寻找叶子节点
    auto* internalNode = reinterpret_cast<InternalPage *>(node);
//    internalNode->Init(node->GetPageId(), node->GetParentPageId(), processor_.GetKeySize());// 不是子节点，是内部节点
    page_id_t child_page_Id = leftMost ? internalNode->ValueAt(0) : internalNode->Lookup(key, this->processor_); // 获取下一页
    Page* nextPage = buffer_pool_manager_->FetchPage(child_page_Id);
    if (nextPage == nullptr){
      throw runtime_error("all page are pinned while FindLeafPage");
    }
    auto* nextNode = reinterpret_cast<BPlusTreePage*>(nextPage->GetData());
    node = nextNode;
    page = nextPage;
    buffer_pool_manager_->UnpinPage(node->GetPageId(), false);
  }
  return page; // 返回找到的页面，值存在这个页码内/可以插入该页面，这个页是被锁着的
}

/*
 * Update/Insert root page id in header page(where page_id = 0, header_page is
 * defined under include/page/header_page.h)
 * Call this method everytime root page id is changed.
 * @parameter: insert_record      default value is false. When set to true,
 * insert a record <index_name, current_page_id> into header page instead of
 * updating it.
 * 如何获取 name 啊
 */
void BPlusTree::UpdateRootPageId(int insert_record) {
  auto *page = buffer_pool_manager_->FetchPage(TREE_INDEX_META);  // 0 是 headerPage 中的 META_PAGE_ID
  if (page == nullptr){
    throw runtime_error("all page are pinned while UpdateRootPageId");
  }
  auto *index_root_page = reinterpret_cast<IndexRootsPage *>(page->GetData());
//  root_page_id_ = page->GetPageId();
  /**
   * 很奇怪，甚至没有引入 headerPage
   * 我的理解是把第 1 页当作 index 页，
   * 然后把对应的 rootPageId 和 index 都存进去
   * 很重要，是连接 3 4 的关键
   */
  if (insert_record == 1){  // set to true
    // 第一次，在根页插入 <index_name, current_page_id>
    //// 设置根节点！！！
    auto *Root = reinterpret_cast<LeafPage *>(buffer_pool_manager_->NewPage(root_page_id_));
    index_root_page->Insert(index_id_, root_page_id_);
  } else {  // 更新 root
    // update root_page_id in index_root_page
    index_root_page->Update(index_id_, root_page_id_);  // 改变存入的根节点
  }
  buffer_pool_manager_->UnpinPage(TREE_INDEX_META, true);
  buffer_pool_manager_->UnpinPage(root_page_id_, true); // 将新的根页放进去
}

/**
 * This method is used for debug only, You don't need to modify
 * 以图的形式输出整棵 b+树
 */

void BPlusTree::ToGraph(BPlusTreePage *page, BufferPoolManager *bpm, std::ofstream &out) const {
  std::string leaf_prefix("LEAF_");
  std::string internal_prefix("INT_");
  if (page->IsLeafPage()) {
    auto *leaf = reinterpret_cast<LeafPage *>(page);
//    leaf->SetPageType(IndexPageType::LEAF_PAGE);
    // Print node name
    out << leaf_prefix << leaf->GetPageId();
    // Print node properties
    out << "[shape=plain color=green ";
    // Print data of the node
    out << "label=<<TABLE BORDER=\"0\" CELLBORDER=\"1\" CELLSPACING=\"0\" CELLPADDING=\"4\">\n";
    // Print data
    out << "<TR><TD COLSPAN=\"" << leaf->GetSize() << "\">P=" << leaf->GetPageId()
        << ",Parent=" << leaf->GetParentPageId() << "</TD></TR>\n";
    out << "<TR><TD COLSPAN=\"" << leaf->GetSize() << "\">"
        << "max_size=" << leaf->GetMaxSize() << ",min_size=" << leaf->GetMinSize() << ",size=" << leaf->GetSize()
        << "</TD></TR>\n";
    out << "<TR>";
    for (int i = 0; i < leaf->GetSize(); i++) {
      out << "<TD>" << leaf->KeyAt(i) << "</TD>\n";
    }
    out << "</TR>";
    // Print table end
    out << "</TABLE>>];\n";
    // Print Leaf node link if there is a next page
    if (leaf->GetNextPageId() != INVALID_PAGE_ID) {
      out << leaf_prefix << leaf->GetPageId() << " -> " << leaf_prefix << leaf->GetNextPageId() << ";\n";
      out << "{rank=same " << leaf_prefix << leaf->GetPageId() << " " << leaf_prefix << leaf->GetNextPageId() << "};\n";
    }

    // Print parent links if there is a parent
    if (leaf->GetParentPageId() != INVALID_PAGE_ID) {
      out << internal_prefix << leaf->GetParentPageId() << ":p" << leaf->GetPageId() << " -> " << leaf_prefix
          << leaf->GetPageId() << ";\n";
    }
  } else {
    auto *inner = reinterpret_cast<InternalPage *>(page);
//    inner->Init(page->GetPageId(), page->GetParentPageId(), processor_.GetKeySize());
    // Print node name
    out << internal_prefix << inner->GetPageId();
    // Print node properties
    out << "[shape=plain color=pink ";  // why not?
    // Print data of the node
    out << "label=<<TABLE BORDER=\"0\" CELLBORDER=\"1\" CELLSPACING=\"0\" CELLPADDING=\"4\">\n";
    // Print data
    out << "<TR><TD COLSPAN=\"" << inner->GetSize() << "\">P=" << inner->GetPageId()
        << ",Parent=" << inner->GetParentPageId() << "</TD></TR>\n";
    out << "<TR><TD COLSPAN=\"" << inner->GetSize() << "\">"
        << "max_size=" << inner->GetMaxSize() << ",min_size=" << inner->GetMinSize() << ",size=" << inner->GetSize()
        << "</TD></TR>\n";
    out << "<TR>";
    for (int i = 0; i < inner->GetSize(); i++) {
      out << "<TD PORT=\"p" << inner->ValueAt(i) << "\">";
      if (i > 0) {
        out << inner->KeyAt(i);
      } else {
        out << " ";
      }
      out << "</TD>\n";
    }
    out << "</TR>";
    // Print table end
    out << "</TABLE>>];\n";
    // Print Parent link
    if (inner->GetParentPageId() != INVALID_PAGE_ID) {
      out << internal_prefix << inner->GetParentPageId() << ":p" << inner->GetPageId() << " -> " << internal_prefix
          << inner->GetPageId() << ";\n";
    }
    // Print leaves
    for (int i = 0; i < inner->GetSize(); i++) {
      auto child_page = reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(inner->ValueAt(i))->GetData());
      ToGraph(child_page, bpm, out);
      if (i > 0) {
        auto sibling_page = reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(inner->ValueAt(i - 1))->GetData());
        if (!sibling_page->IsLeafPage() && !child_page->IsLeafPage()) {
          out << "{rank=same " << internal_prefix << sibling_page->GetPageId() << " " << internal_prefix
              << child_page->GetPageId() << "};\n";
        }
        bpm->UnpinPage(sibling_page->GetPageId(), false);
      }
    }
  }
  bpm->UnpinPage(page->GetPageId(), false);
}

void BPlusTree::PrintAll(page_id_t root, std::ofstream &out){
  auto page = reinterpret_cast<BPlusTreePage *>(buffer_pool_manager_->FetchPage(root));
  buffer_pool_manager_->UnpinPage(root, false);
  this->ToGraph(page, buffer_pool_manager_, out);
//  BPlusTreePage *child;
//  while(!page->IsLeafPage()){
//    page_id_t pageId;
//    for(int i = 0; i < page->GetSize(); i++){
//      child = reinterpret_cast<BPlusTreePage *>(buffer_pool_manager_->FetchPage(reinterpret_cast<InternalPage *>(page)->ValueAt(pageId)));
//      this->PrintAll(child->GetPageId(), out);
//      buffer_pool_manager_->UnpinPage(child->GetPageId(), false);
//    }
//  }
}

/**
 * This function is for debug only, you don't need to modify
 */
 // 以 string 的形式输出整棵 b+树 的信息
void BPlusTree::ToString(BPlusTreePage *page, BufferPoolManager *bpm) const {
  if (page->IsLeafPage()) { // 输出叶子页的信息
    auto *leaf = reinterpret_cast<LeafPage *>(page);
    std::cout << "Leaf Page: " << leaf->GetPageId() << " parent: " << leaf->GetParentPageId()
              << " next: " << leaf->GetNextPageId() << std::endl;
    for (int i = 0; i < leaf->GetSize(); i++) {
      std::cout << leaf->KeyAt(i) << ",";
    }
    std::cout << std::endl;
    std::cout << std::endl;
  } else {  // 输出内部节点页的信息
    auto *internal = reinterpret_cast<InternalPage *>(page);
//    internal->Init(page->GetPageId(), page->GetParentPageId(), processor_.GetKeySize());
    std::cout << "Internal Page: " << internal->GetPageId() << " parent: " << internal->GetParentPageId() << std::endl;
    for (int i = 0; i < internal->GetSize(); i++) {
      std::cout << internal->KeyAt(i) << ": " << internal->ValueAt(i) << ",";
    }
    std::cout << std::endl;
    std::cout << std::endl;
    for (int i = 0; i < internal->GetSize(); i++) {
      ToString(reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(internal->ValueAt(i))->GetData()), bpm);
      bpm->UnpinPage(internal->ValueAt(i), false);
    }
  }
}

// 检查使用的所有b+树节点页，在使用结束后是否都释放了
bool BPlusTree::Check() {
  bool all_unpinned = buffer_pool_manager_->CheckAllUnpinned();
  if (!all_unpinned) {
    LOG(ERROR) << "problem in page unpin" << endl;
  }
  return all_unpinned;
}

/***********************************
* hash
***********************************/

/** * * * * * * * * * * *
 * 构建与析构
 ** * * * * * * * * * * */
int HashPage::findIndex(GenericKey *key, KeyManager &comparator){
  for(int i = 0; i < GetSize(); i++){
    if(!comparator.CompareKeys(key, KeyAt(i, comparator.GetKeySize()))){
      return i; // 返回下标
    }
  }
  return -1;  // 没找到
}

void HashTable::Destroy(){
//  this->buckets.clear();
}

// 初始化哈希表
HashTable::HashTable(index_id_t index_, BufferPoolManager *buffer_pool_manager, const KeyManager &comparator, int hashSize, int max)
    : index_id(index_), processor_(comparator), buffer_pool_manager_(buffer_pool_manager) {
  this->curSize = 0;
  this->maxsize = max;
  long int hash = hashSize ? (hashSize/ 0.75) : max;  // 如果规定就使用规定值，没有的话就借助 max
  tableSize = ceil(hash); // 一般装载因子是0.75
  tableSize = FindMaxPrime(tableSize);
  auto *page = reinterpret_cast<HashPage *>(buffer_pool_manager->NewPage(root_page_));
  page->SetSize(0); // 将哈希表储存进入一个页
  for(int i = 0; i < maxsize; i++){
    page->SetValueAt(i, 0, sizeof(page_id_t));  // 初始化防止取值溢出
  }
  buffer_pool_manager->UnpinPage(root_page_, true);
  IndexRootsPage * rootsPage = reinterpret_cast<IndexRootsPage *>(buffer_pool_manager->FetchPage(HashTablePage));
  rootsPage->Insert(index_, root_page_);  // 插入对应的表
  buffer_pool_manager->UnpinPage(HashTablePage, true);
}

// 获取哈希桶中现在的键值数量
int HashTable::getSize() {
  return this->curSize;
}

// 当前是否有申请页
bool HashTable::IsEmpty(){
  auto* page = reinterpret_cast<HashTable*>(buffer_pool_manager_->FetchPage(root_page_));
  buffer_pool_manager_->UnpinPage(root_page_, false);
  return (!page->tableSize);
}

// 获取对应 key 的哈希值
int HashTable::GetId(GenericKey *key){
  char * data = (char *)malloc(sizeof (char) * (processor_.GetKeySize() + 1));
  memcpy(data, key, processor_.GetKeySize());  // 将 key 存入 data 中
  int page = atoi(data) % tableSize;
  // 将 char* 转换为 int，并使得计算结果尽量分散减少冲突
  free(data); // 释放空间
  if(page > maxsize){
    page = page % maxsize;
  }
  return page;  // 返回哈希值
}

// 申请一个新的 hash 桶，不进行其他操作
page_id_t HashTable::NewHash(page_id_t &pageId, int index){ // 申请一个空桶
  if(this->curSize >= this->maxsize) throw runtime_error("there isn't any space");
  auto * page = reinterpret_cast<HashPage *>(buffer_pool_manager_->NewPage(pageId)->GetData());
  page->SetPageId(pageId);
  page->SetRootPage(root_page_);
  this->curSize++;  // 新增了一个空间
  page->SetSize(0);
  page->SetFlag(false);
  buffer_pool_manager_->UnpinPage(pageId, true);  // 释放并写回
  HashPage* root = reinterpret_cast<HashPage *>(buffer_pool_manager_->FetchPage(root_page_));
  root->SetValueAt(index, page->GetPageId(), sizeof(page_id_t));
  root->Increase(1);
  buffer_pool_manager_->UnpinPage(root_page_, true);
}

// 该插入原则能够让后放入的数据先找到
bool HashTable::Insert(GenericKey *key){
  vector<page_id_t> id;
  page_id_t pageId;
  int index = this->GetId(key);  // 获取一个新的页，页码就是根据key计算的值
  if(IsEmpty()){
    NewHash(pageId, index);
    HashPage * newHash = reinterpret_cast<HashPage *>(buffer_pool_manager_->FetchPage(pageId));
    newHash->SetKeyAt(0, key, processor_.GetKeySize());
    newHash->Increase(1);
    buffer_pool_manager_->UnpinPage(pageId, true);
    return true;
  }
  if(GetValue(key, id)){
    return false; // 已经储存了这个值
  }
  pageId = id[id.size() - 1]; // 取出刚刚找到的 pageId
  if(pageId == 0){
    NewHash(pageId, index);
    HashPage * newHash = reinterpret_cast<HashPage *>(buffer_pool_manager_->FetchPage(pageId));
    newHash->SetKeyAt(0, key, processor_.GetKeySize());
    newHash->Increase(1);
    buffer_pool_manager_->UnpinPage(pageId, true);
    return true;
  }
  auto * pItem = reinterpret_cast<HashPage *>(buffer_pool_manager_->FetchPage(pageId)->GetData());
  if(pItem->GetSize() >= maxsize){ // 如果该箱子装满了(+1后大于)
    pItem->SetFlag(true); // 冲突标记
    buffer_pool_manager_->UnpinPage(pageId, true); // 先将申请的页释放
    pageId = FindConflict(index);
    if(pageId == -1){
      throw runtime_error("all hash buckets are full, the maxsize is wrong");
    }
    else{
      // 获取新的页
      pItem = reinterpret_cast<HashPage *>(buffer_pool_manager_->FetchPage(pageId)->GetData());
    }
  }
  pItem->SetKeyAt(pItem->GetSize(), key, processor_.GetKeySize());
  pItem->Increase(1);
  buffer_pool_manager_->UnpinPage(pItem->GetPageId(), true);
//  buckets[pageId] = pItem;
  return true;
}

// 返回一个不冲突的桶
page_id_t HashTable::FindConflict(int index){
  int change;
  int cur = 0, mark = 1;
  change = (int)(index + mark * pow(2, cur)) % tableSize;
  HashPage * hashPage;
  HashPage * root = reinterpret_cast<HashPage *>(buffer_pool_manager_->FetchPage(root_page_));
  buffer_pool_manager_->UnpinPage(root_page_, false);
  page_id_t pageId;
  while(change != index){  // 没有找完一圈
    pageId = root->ValueAt(index);
    if(!pageId){
      NewHash(pageId, change);
      return pageId;
    }
    hashPage = reinterpret_cast<HashPage *>(buffer_pool_manager_->FetchPage(pageId)->GetData());
    buffer_pool_manager_->UnpinPage(pageId, false);
    if(hashPage->GetSize() < maxsize){
      return pageId;
    }
    else {
      cur++;  // 新找的桶都满了
      mark = -mark;
    }
  }
  return -1;  // 所有桶都满了
}

// 删除对应的 ksy
bool HashTable::Remove(GenericKey *key){
  vector<page_id_t> id;
  if(!GetValue(key, id))  return false; // 没有该值
  HashPage * bucky = reinterpret_cast<HashPage *>(buffer_pool_manager_->FetchPage(id[id.size()-2])->GetData());
  // 从内存中取出删除数据所在页
  int i = id[id.size()-1];
  for(i ; i < bucky->GetSize(); i++){
    // 统一向前面移动一位
    bucky->SetKeyAt(i, bucky->KeyAt(i + 1, processor_.GetKeySize()), processor_.GetKeySize());
  }
  bucky->Increase(-1);
//  buckets[id[id.size()-1]] = bucky; // 重新储存
  buffer_pool_manager_->UnpinPage(id[id.size()-2], true); // 更新磁盘
}

// 寻找是否有该 key 值，有返回 true
bool HashTable::GetValue(GenericKey *key, std::vector<page_id_t> &result){
  if(IsEmpty()) return false;
  bool flag = false;
  int id = GetId(key);
  HashPage *root = reinterpret_cast<HashPage *>(buffer_pool_manager_->FetchPage(root_page_));
  page_id_t pageId = root->ValueAt(id);
  result.push_back(pageId); // 返回页码
  buffer_pool_manager_->UnpinPage(root_page_, false);
  if(!pageId) return false; // 甚至没有申请这一页
  HashPage * Buck = reinterpret_cast<HashPage *>(buffer_pool_manager_->FetchPage(pageId)->GetData());
  buffer_pool_manager_->UnpinPage(pageId, false);
  int i, size = Buck->GetSize(), time = 1, mark = 1;  // time 记录冲突次数
  while(size == maxsize || !flag || Buck->GetFlag()) {
    size = Buck->GetSize();
    for (i = 0; i < size; i++) {
      flag = true;  // 已经开始找第一个
      if (processor_.CompareKeys(key, Buck->KeyAt(i, processor_.GetKeySize())) == 0) {
        result.push_back(i);  // 返回在该页的位置
        buffer_pool_manager_->UnpinPage(Buck->GetPageId(), false);
        return true;  // 找到了相同值
      }
    }
    if(size == maxsize){
      id = (int)(id + pow(2, time) * mark) % tableSize;
      mark = -mark; // 变符号
      time++;
      pageId = root->ValueAt(id);
      if(pageId == 0){
        NewHash(pageId, id);
      }
      buffer_pool_manager_->UnpinPage(Buck->GetPageId(), false);
      Buck = reinterpret_cast<HashPage *>(buffer_pool_manager_->FetchPage(pageId));
    }
  }
  buffer_pool_manager_->UnpinPage(Buck->GetPageId(), false);
  return false;  // 没有储存过对应的 key
}

/** * * * * *
 * 寻找最大质数
 * */
int FindMaxPrime(int hash){
  if(hash % 2 == 0) hash++; // 最大质数只会是奇数
  if(!IsPrime(hash) && hash > 3)  return FindMaxPrime(hash - 2);  // 如果不是质数则递归寻找
  return hash;
}

bool IsPrime(int hash){
  int i = 3, max = sqrt(hash);  // 因为 hash 不为偶数，所以从 3 开始
  for(i; i <= max; i+=2){
    if(hash % i == 0) return false;
  }
  return true;
}

/**
* hash check
*/

// 检查使用的所有b+树节点页，在使用结束后是否都释放了
bool HashTable::Check() {
  bool all_unpinned = buffer_pool_manager_->CheckAllUnpinned();
  if (!all_unpinned) {
    LOG(ERROR) << "problem in page unpin" << endl;
  }
  return all_unpinned;
}