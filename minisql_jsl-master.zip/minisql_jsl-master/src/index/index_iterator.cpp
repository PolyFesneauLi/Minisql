#include "index/index_iterator.h"

#include "index/basic_comparator.h"
#include "index/generic_key.h"

IndexIterator::IndexIterator() = default;
// 初始化
IndexIterator::IndexIterator(page_id_t page_id, BufferPoolManager *bpm, int index)
    : current_page_id(page_id), item_index(index), buffer_pool_manager(bpm) {
  this->page = reinterpret_cast<LeafPage *>(buffer_pool_manager->FetchPage(current_page_id)->GetData());
  buffer_pool_manager->UnpinPage(page->GetPageId(), false);
}

IndexIterator::~IndexIterator() {
  if (current_page_id != INVALID_PAGE_ID) // 只释放了最后一个
    buffer_pool_manager->UnpinPage(current_page_id, false);
}

std::pair<GenericKey *, RowId> IndexIterator::operator*() {
  if(current_page_id == INVALID_PAGE_ID || (item_index == page->GetSize() && page->GetNextPageId() == INVALID_PAGE_ID)){
    ASSERT(false, "越界问题");
  }
  // ASSERT(true, "Success.");
  return page->GetItem(item_index); // 返回键值对
}

IndexIterator &IndexIterator::operator++() {
  item_index++;
  if(item_index == page->GetSize() && page->GetNextPageId() != INVALID_PAGE_ID){  // 如果已经取完该页，那么转向新的一页
    LeafPage *newLeaf = reinterpret_cast<LeafPage *>(buffer_pool_manager->FetchPage(page->GetNextPageId())->GetData());
    buffer_pool_manager->UnpinPage(page->GetPageId(), true);
    page = newLeaf; // 更新变量
    item_index = 0;
    current_page_id = page->GetPageId();
  }
  return *this; // 返回更新后的迭代器
}

bool IndexIterator::operator==(const IndexIterator &itr) const {
  return current_page_id == itr.current_page_id && item_index == itr.item_index;
}

bool IndexIterator::operator!=(const IndexIterator &itr) const {
  return !(*this == itr);
}