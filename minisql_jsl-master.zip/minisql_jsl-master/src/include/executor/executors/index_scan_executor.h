#pragma once

#include <algorithm>
#include <vector>

#include "executor/execute_context.h"
#include "executor/executors/abstract_executor.h"
#include "executor/plans/index_scan_plan.h"
#include "planner/expressions/column_value_expression.h"
#include "planner/expressions/comparison_expression.h"

/**
 * The IndexScanExecutor executor can over a table.
 */
class IndexScanExecutor : public AbstractExecutor {
 public:
  /**
   * Construct a new SeqScanExecutor instance.
   * @param exec_ctx The executor context
   * @param plan The sequential scan plan to be executed
   */
  IndexScanExecutor(ExecuteContext *exec_ctx, const IndexScanPlanNode *plan);

  /** Initialize the sequential scan */
  void Init() override;

  //// 求交集的函数
  void SetTogether(vector<vector<RowId>> Set){
    vector<RowId> value1;
    vector<RowId> intersection;
    bool flag = false;
    for(vector<RowId>value2 : Set){
      if(!flag){
        value1 = value2;
        flag = true;
      }
      else{
        set_intersection(value1.begin(),value1.end(),value2.begin(),value2.end(),std::back_inserter(intersection));
        value1 = intersection;
      }
    }
    row_Id = value1;
  }

  /**
   * Yield the next row from the sequential scan.
   * @param[out] row The next row produced by the scan
   * @param[out] rid The next row RID produced by the scan
   * @return `true` if a row was produced, `false` if there are no more rows
   */
  bool Next(Row *row, RowId *rid) override;

  /** @return The output schema for the sequential scan */
  const Schema *GetOutputSchema() const override { return plan_->OutputSchema(); }

 private:

  /** The sequential scan plan node to be executed */
  const IndexScanPlanNode *plan_;
  vector<RowId> row_Id; // RowId 集合
  int index = 0;
};