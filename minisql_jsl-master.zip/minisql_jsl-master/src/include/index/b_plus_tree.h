#ifndef MINISQL_B_PLUS_TREE_H
#define MINISQL_B_PLUS_TREE_H
#define HASH_DEFAULT_SIZE 179
#define HASH_HEAD (sizeof(int)+sizeof(page_id_t))
#define HASH_MAX_SIZE ((PAGE_SIZE - HASH_HEAD) / (sizeof(page_id_t)+sizeof (int)) - 1)
#define TREE_INDEX_META 1
#define HashTablePage 1
#include <queue>
#include <string>
#include <vector>

#include "index/index_iterator.h"
#include "page/b_plus_tree_internal_page.h"
#include "page/b_plus_tree_leaf_page.h"
#include "page/b_plus_tree_page.h"
#include "transaction/transaction.h"

/**
 * Main class providing the API for the Interactive B+ Tree.
 *
 * Implementation of simple b+ tree data structure where internal pages direct
 * the search and leaf pages contain actual data.
 * (1) We only support unique key
 * (2) support insert & remove
 * (3) The structure should shrink and grow dynamically
 * (4) Implement index iterator for range scan
 */
class BPlusTree {
  using InternalPage = BPlusTreeInternalPage;
  using LeafPage = BPlusTreeLeafPage;

 public:
  explicit BPlusTree(index_id_t index_id, BufferPoolManager *buffer_pool_manager, const KeyManager &comparator,
                     int leaf_max_size = UNDEFINED_SIZE, int internal_max_size = INTERNAL_PAGE_SIZE);
  // 如果没有赋初值需要对最大值进行合适的初始化（叶子节点通过root初始化时获得）

  // Returns true if this B+ tree has no keys and values.
  bool IsEmpty() const;

  // Insert a key-value pair into this B+ tree.
  bool Insert(GenericKey *key, const RowId &value, Transaction *transaction = nullptr);

  // Remove a key and its value from this B+ tree.
  void Remove(const GenericKey *key, Transaction *transaction = nullptr);

  // return the value associated with a given key
  bool GetValue(const GenericKey *key, std::vector<RowId> &result, Transaction *transaction = nullptr);

  IndexIterator Begin();

  IndexIterator Begin(const GenericKey *key);

  IndexIterator End();

  // expose for test purpose
  Page *FindLeafPage(const GenericKey *key, page_id_t page_id = INVALID_PAGE_ID, bool leftMost = false);

  // used to check whether all pages are unpinned
  bool Check();

  // destroy the b plus tree
  void Destroy();
  // 增添的函数
  void DestroyAllLeaf(page_id_t pageId);
  void DestroyInternalPage(page_id_t pageId);

  void PrintTree(std::ofstream &out) {
    if (IsEmpty()) {
      return;
    }
    out << "digraph G {" << std::endl;
    Page *root_page = buffer_pool_manager_->FetchPage(root_page_id_);
    buffer_pool_manager_->UnpinPage(root_page_id_, false);
    auto *node = reinterpret_cast<BPlusTreePage *>(root_page);
    ToGraph(node, buffer_pool_manager_, out);
    out << "}" << std::endl;
  }
  //add BlusTree::setRootPageId
  void setRootPageId(page_id_t rootId) { this->root_page_id_ = rootId; }

  page_id_t GetrootId(){return root_page_id_;}

  void PrintAll(page_id_t root, std::ofstream &out);

 private:
  void StartNewTree(GenericKey *key, const RowId &value);

  bool InsertIntoLeaf(GenericKey *key, const RowId &value, Transaction *transaction = nullptr);

  void InsertIntoParent(BPlusTreePage *old_node, GenericKey *key, BPlusTreePage *new_node,
                        Transaction *transaction = nullptr);

  LeafPage *Split(LeafPage *node, Transaction *transaction);

  InternalPage *Split(InternalPage *node, Transaction *transaction);

  template <typename N>
  bool CoalesceOrRedistribute(N *&node, Transaction *transaction = nullptr);

  bool Coalesce(InternalPage *&neighbor_node, InternalPage *&node, InternalPage *&parent, int index,
                Transaction *transaction = nullptr);

  bool Coalesce(LeafPage *&neighbor_node, LeafPage *&node, InternalPage *&parent, int index,
                Transaction *transaction = nullptr);

  void Redistribute(LeafPage *neighbor_node, LeafPage *node, int index);

  void Redistribute(InternalPage *neighbor_node, InternalPage *node, int index);

  bool AdjustRoot(BPlusTreePage *node);

  void UpdateRootPageId(int insert_record = 0);

  /* Debug Routines for FREE!! */
  void ToGraph(BPlusTreePage *page, BufferPoolManager *bpm, std::ofstream &out) const;

  void ToString(BPlusTreePage *page, BufferPoolManager *bpm) const;

  // member variable
  index_id_t index_id_; // 对应的索引下标
  page_id_t root_page_id_{INVALID_PAGE_ID}; // 根节点的 id, 需要特殊维护
  BufferPoolManager *buffer_pool_manager_;  // 缓冲区管理
  KeyManager processor_;  // 键值对管理
  int leaf_max_size_;     // 叶子节点的键值对最大值
  int internal_max_size_; // 内部节点的键值对最大值
};

/**********************************************************
 *  加上hash
 ** *****************************************************/

// hashtable 是传入数据量的 1.5-2 倍，且一般为质数

// 通过链表形式来实现，一个结构体是一个框
class HashPage {
 private:
  char data_[PAGE_SIZE - HASH_HEAD];  // 储存键值
  page_id_t pageId; // 当前的哈希桶的页码(根据 key 计算)
  int size;   // 当前储存在桶中的数目
  page_id_t rootPage; // 管理该页的table
  bool conflict;
 public:
  HashPage(page_id_t page, int num = 0, bool flag = false): pageId(page), size(num), conflict(false){}
  void SetFlag(bool  flag){
    conflict = flag;
  }
  bool GetFlag(){
    return conflict;
  }
  page_id_t GetPageId(){
    return pageId;
  }
  void SetPageId(page_id_t page){
    pageId = page;
  }
  void SetRootPage(page_id_t root){
    rootPage = root;
  }
  page_id_t GetRootPage(){
    return rootPage;
  }
  int GetSize(){
    return size;
  }
  void SetSize(int num){
    size = num;
  }
  void Increase(int delta){
    size += delta;
  }
  GenericKey * KeyAt(int size, int keySize){ // 这里需要把键值的大小传进来
    return reinterpret_cast<GenericKey *>(data_ + size * keySize);
  }
  void SetKeyAt(int size, GenericKey *key, int keySize) {
    memcpy(data_ + size * keySize, key, keySize);
    // 把 key 复制到对应的位置，将key顺序储存到了data_里面
  }
  void SetValueAt(int size, page_id_t id, int keySize) {
    *reinterpret_cast<page_id_t *>(data_ + size * keySize) = id;
  }
  page_id_t ValueAt(int index) const {
    return *reinterpret_cast<const page_id_t *>(data_ + index * sizeof(page_id_t));
  }
  int findIndex(GenericKey *key, KeyManager &comparator);
};

class HashTable {
 private:
  int tableSize;  // 桶的个数
  int curSize;
  int maxsize;  // 最大值（如果超过最大值则移动到距离为1的桶较小的桶中）
  index_id_t index_id;  // table 中储存的页
  BufferPoolManager *buffer_pool_manager_;  // 缓冲区管理
  KeyManager processor_;  // 键值对管理
  page_id_t  root_page_;  // table 所在的节点
//  vector<HashPage *> buckets; // pageId 唯一确定整个桶(里面存)

 public:
  HashTable(index_id_t index_, BufferPoolManager *buffer_pool_manager, const KeyManager &comparator, int hashSize = 0, int max = HASH_MAX_SIZE);
  bool IsEmpty();
  ~HashTable(){}
  int getSize();
  page_id_t NewHash(page_id_t &pageId, int index);
  bool Insert(GenericKey *key);
  bool Remove(GenericKey *key);
  bool GetValue(GenericKey *key, std::vector<page_id_t> &result);
  int GetId(GenericKey *key); // 获取对应的index
  page_id_t FindConflict(int index);
  page_id_t getRootId(){return this->root_page_;}
  bool Check();
  void Destroy();
};

int FindMaxPrime(int hash);
bool IsPrime(int hash);


#endif  // MINISQL_B_PLUS_TREE_H
