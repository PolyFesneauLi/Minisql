#ifndef MINISQL_CLOCK_REPLACER_H
#define MINISQL_CLOCK_REPLACER_H

#include <algorithm>
#include <list>
#include <map>
#include <mutex>
#include <queue>
#include <unordered_set>
#include <vector>

#include "buffer/replacer.h"
#include "common/config.h"

using namespace std;

/**
 * CLOCKReplacer implements the clock replacement.
 */
class CLOCKReplacer : public Replacer {
   public:
    /**
     * Create a new CLOCKReplacer.
     * @param num_pages the maximum number of pages the CLOCKReplacer will be required to store
     */
    explicit CLOCKReplacer(size_t num_pages);

    /**
     * Destroys the CLOCKReplacer.
     */
    ~CLOCKReplacer() override;

    bool Victim(frame_id_t* frame_id) override;

    void Pin(frame_id_t frame_id) override;

    void Unpin(frame_id_t frame_id) override;

    size_t Size() override;

   private:
    size_t capacity;
    list<pair<frame_id_t, bool>>::iterator curPos;                           // 记录当前在环形链表的位置, 用 curPos 把 list 当环形链表处理
    list<pair<frame_id_t, bool>> clockList;                                  // replacer中可以被替换的数据页, bool 记录 ref_bit
    unordered_map<frame_id_t, list<pair<frame_id_t, bool>>::iterator> hash;  // 用于记录 list 里对应frame_id的页面的位置
};

#endif  // MINISQL_CLOCK_REPLACER_H