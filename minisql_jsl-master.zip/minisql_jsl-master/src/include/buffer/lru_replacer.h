#ifndef MINISQL_LRU_REPLACER_H
#define MINISQL_LRU_REPLACER_H

#include <list>
#include <mutex>
#include <unordered_map>
#include <vector>

#include "buffer/replacer.h"
#include "common/config.h"

using namespace std;

/**
 * LRUReplacer implements the Least Recently Used replacement policy.
 */
class LRUReplacer : public Replacer {
   public:
    /**
     * Create a new LRUReplacer.
     * @param num_pages the maximum number of pages the LRUReplacer will be required to store
     */
    explicit LRUReplacer(size_t num_pages);

    /**
     * Destroys the LRUReplacer.
     */
    ~LRUReplacer() override;

    bool Victim(frame_id_t* frame_id) override;

    void Pin(frame_id_t frame_id) override;

    void Unpin(frame_id_t frame_id) override;

    size_t Size() override;

   private:
    // add your own private member variables here
    // 采用HashMap加双向链表实现
    unsigned int capacity;                                       // 容量
    list<frame_id_t> lruList;                                    // 用双向链表保存页面(可替换)
    unordered_map<frame_id_t, list<frame_id_t>::iterator> hash;  // 用于记录list里对应frame_id的页面的位置
};

#endif  // MINISQL_LRU_REPLACER_H
