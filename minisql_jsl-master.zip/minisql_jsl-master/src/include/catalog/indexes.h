#ifndef MINISQL_INDEXES_H
#define MINISQL_INDEXES_H

#include <memory>

#include "catalog/table.h"
#include "common/macros.h"
#include "common/rowid.h"
#include "index/b_plus_tree_index.h"
#include "index/generic_key.h"
#include "record/schema.h"

class IndexMetadata {
  friend class IndexInfo;

 public:
  static IndexMetadata *Create(const index_id_t index_id, const std::string &index_name, const table_id_t table_id,
                               const std::vector<uint32_t> &key_map);

  uint32_t SerializeTo(char *buf) const;

  uint32_t GetSerializedSize() const;

  static uint32_t DeserializeFrom(char *buf, IndexMetadata *&index_meta);

  inline std::string GetIndexName() const { return index_name_; }

  inline table_id_t GetTableId() const { return table_id_; }

  uint32_t GetIndexColumnCount() const { return key_map_.size(); }

  inline const std::vector<uint32_t> &GetKeyMapping() const { return key_map_; }

  inline index_id_t GetIndexId() const { return index_id_; }
  //add indexmetadata->getRootPageId
  page_id_t getRootPageId() { return this->root_page_id_; }

 private:
  IndexMetadata() = delete;

  explicit IndexMetadata(const index_id_t index_id, const std::string &index_name, const table_id_t table_id,
                         const std::vector<uint32_t> &key_map);

 private:
  static constexpr uint32_t INDEX_METADATA_MAGIC_NUM = 344528;  // need to initialize
  index_id_t index_id_;
  std::string index_name_;
  page_id_t root_page_id_; // add content IndexMetadata->root_page_id
  table_id_t table_id_;
  std::vector<uint32_t> key_map_; /** The mapping of index key to tuple key */
};

/**
 * The IndexInfo class maintains metadata about a index.
 */
class IndexInfo {
 public:
  static IndexInfo *Create() { return new IndexInfo(); }

  ~IndexInfo() {
    delete meta_data_;
    delete index_;
    delete key_schema_;
  }

/**
 * TODO: Student Implement
 */
  void Init(IndexMetadata *meta_data, TableInfo *table_info, BufferPoolManager *buffer_pool_manager) {
    // Step1: init index metadata and table info
    this->meta_data_ = meta_data;
    this->table_info = table_info;
    // Step2: mapping index key to key schema
    key_schema_ = Schema::ShallowCopySchema(table_info->GetSchema(), meta_data->key_map_);
    // Step3: call CreateIndex to create the index
    index_= new BPlusTreeIndex(meta_data->index_id_, key_schema_, meta_data->GetSerializedSize(), buffer_pool_manager);
    //ASSERT(false, "Not Implemented yet.");
  }

  inline Index *GetIndex() 
  { 
    return index_; 
  }

  std::string GetIndexName() { return meta_data_->GetIndexName(); }

  IndexSchema *GetIndexKeySchema() { return key_schema_; }

  
  void setRootPageId(){
      //add indexinfo->setRootpageid

//      index_->setRootPageId(this->meta_data_->getRootPageId());
    //// 上面会把根变成0，统一在树解决这个问题吧
  }

 private:
  explicit IndexInfo() : meta_data_{nullptr}, index_{nullptr}, key_schema_{nullptr} {}

  Index *CreateIndex(BufferPoolManager *buffer_pool_manager, const string &index_type);

 public:  //change to public
  IndexMetadata *meta_data_;
  Index *index_;
  IndexSchema *key_schema_;
  //add private table_info
  TableInfo *table_info;
};

#endif  // MINISQL_INDEXES_H
