#include "storage/table_heap.h"
// 最初的做法: 沿着TablePage构成的链表依次查找，直到找到第一个能够容纳该记录的TablePage（First Fit 策略）
// 实现bonus2之后, 通过一个集合维护所有未满的页，每次查找从该集合中取
bool TableHeap::InsertTuple(Row& row, Transaction* txn) {
    // TablePage* curPage = reinterpret_cast<TablePage*>(buffer_pool_manager_->FetchPage(first_page_id_));  // 根据 first_page_id_ 申请一页
    page_id_t cur_page_id = *free_page_set_.begin();
    TablePage* curPage = reinterpret_cast<TablePage*>(buffer_pool_manager_->FetchPage(cur_page_id));  // 根据 cur_page_id_ 申请一页
    TablePage* nextPage;

    if (!curPage)  // 没有page了
        return false;

    // 如果插入失败就移到下一个page, 直到找到有足够空间的page为止
    while (curPage->InsertTuple(row, schema_, txn, lock_manager_, log_manager_) == false) {
        free_page_set_.erase(curPage->GetPageId());  // 说明当前 cur_page_id_ 指向的page满了，那就从 free_page_set 里删掉它
        page_id_t nextID = curPage->GetNextPageId();
        if (nextID != INVALID_PAGE_ID) {                                                      // 如果还存在下一个page
            buffer_pool_manager_->UnpinPage(curPage->GetPageId(), false);                     // 取消固定curPage, 没有更改所以不需要写硬盘
            curPage = reinterpret_cast<TablePage*>(buffer_pool_manager_->FetchPage(nextID));  // 在Fetch和New的时候会pin
            free_page_set_.insert(curPage->GetPageId());                                      // 先插入，假定它是未满的
        } else {
            nextPage = reinterpret_cast<TablePage*>(buffer_pool_manager_->NewPage(nextID));
            if (nextPage == nullptr) {                                         // new失败了
                buffer_pool_manager_->UnpinPage(curPage->GetPageId(), false);  // 取消固定curPage, 没有更改所以不需要写硬盘
                return false;
            }
            // 给权限
            nextPage->WLatch();
            curPage->WLatch();

            curPage->SetNextPageId(nextID);                                   // curPage 指向 nextPage
            nextPage->Init(nextID, curPage->GetPageId(), log_manager_, txn);  // 初始化 nextPage

            // 收回权限
            curPage->WUnlatch();
            nextPage->WUnlatch();

            buffer_pool_manager_->UnpinPage(curPage->GetPageId(), true);  // 取消固定curPage, nextID changed
            curPage = nextPage;

            free_page_set_.insert(curPage->GetPageId());  // 将新的页插入
        }
    }
    buffer_pool_manager_->UnpinPage(curPage->GetPageId(), true);  // 取消固定curPage, data_ changed
    return true;
}

bool TableHeap::MarkDelete(const RowId& rid, Transaction* txn) {
    // Find the page which contains the tuple.
    auto page = reinterpret_cast<TablePage*>(buffer_pool_manager_->FetchPage(rid.GetPageId()));
    // If the page could not be found, then abort the transaction.
    if (page == nullptr) {
        return false;
    }
    // Otherwise, mark the tuple as deleted.
    page->WLatch();
    page->MarkDelete(rid, txn, lock_manager_, log_manager_);
    page->WUnlatch();
    buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
    return true;
}
// row 是新的 row, rid 是要改的 row 的 rid; 最后需要更改rid指向的row的内容，并且更改row的rowid
bool TableHeap::UpdateTuple(Row& row, RowId& rid, Transaction* txn) {
    Row* oldRow = new Row(rid);  // 为了满足接口
    TablePage* page = reinterpret_cast<TablePage*>(buffer_pool_manager_->FetchPage(rid.GetPageId()));
    if (page == nullptr)
        return false;
    // 比较是否装得下新的row
    uint32_t OldTupleSize = page->GetTupleSize(rid.GetSlotNum());
    uint32_t remainingSize = page->GetFreeSpaceRemaining();
    uint32_t newTupleSize = row.GetSerializedSize(schema_);
    if (newTupleSize <= remainingSize + OldTupleSize) {  // TablePage 能够容纳下更新后的数据
        page->WLatch();
        // 更新成功
        if (page->UpdateTuple(row, oldRow, schema_, txn, lock_manager_, log_manager_)) {  // 第二个传入参数为oldRow的地址
            buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);                // 记得解锁
            row.SetRowId(rid);
            page->WUnlatch();
            return true;
        } else {
            buffer_pool_manager_->UnpinPage(page->GetTablePageId(), false);
            page->WUnlatch();
            return false;
        }
    } else {                             // TablePage 不能够容纳下更新后的数据
        MarkDelete(rid, txn);            // 标记
        ApplyDelete(rid, txn);           // 删除
        return (InsertTuple(row, txn));  // 插入新的 row, insertTuple() 会改变 row 的 rid
    }
}

// Step1: Find the page which contains the tuple.
// Step2: Delete the tuple from the page.
void TableHeap::ApplyDelete(const RowId& rid, Transaction* txn) {
    TablePage* page = reinterpret_cast<TablePage*>(buffer_pool_manager_->FetchPage(rid.GetPageId()));
    if (!page)
        return;

    page->WLatch();
    page->ApplyDelete(rid, txn, log_manager_);
    page->WUnlatch();
    buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
    if (!free_page_set_.count(page->GetPageId())) {  // 将删除之后的页插入
        free_page_set_.insert(page->GetPageId());
    }
}

void TableHeap::RollbackDelete(const RowId& rid, Transaction* txn) {
    // Find the page which contains the tuple.
    auto page = reinterpret_cast<TablePage*>(buffer_pool_manager_->FetchPage(rid.GetPageId()));
    assert(page != nullptr);
    // Rollback to delete.
    page->WLatch();
    page->RollbackDelete(rid, txn, log_manager_);
    page->WUnlatch();
    buffer_pool_manager_->UnpinPage(page->GetTablePageId(), true);
}

bool TableHeap::GetTuple(Row* row, Transaction* txn) {
    TablePage* page = reinterpret_cast<TablePage*>(buffer_pool_manager_->FetchPage(row->GetRowId().GetPageId()));
    if (page == nullptr)
        return false;

    page->RLatch();  // 开启读权限
    bool flag = page->GetTuple(row, schema_, txn, lock_manager_);
    page->RUnlatch();

    buffer_pool_manager_->UnpinPage(row->GetRowId().GetPageId(), false);
    return flag;
}

void TableHeap::DeleteTable(page_id_t page_id) {
    if (page_id != INVALID_PAGE_ID) {
        auto temp_table_page = reinterpret_cast<TablePage*>(buffer_pool_manager_->FetchPage(page_id));  // 删除table_heap
        if (temp_table_page->GetNextPageId() != INVALID_PAGE_ID)
            DeleteTable(temp_table_page->GetNextPageId());
        buffer_pool_manager_->UnpinPage(page_id, false);
        buffer_pool_manager_->DeletePage(page_id);
    } else {
        DeleteTable(first_page_id_);
    }
}

TableIterator TableHeap::Begin(Transaction* txn) {
    TablePage* page = reinterpret_cast<TablePage*>(buffer_pool_manager_->FetchPage(first_page_id_));
    RowId rid;

    page->GetFirstTupleRid(&rid);
    buffer_pool_manager_->UnpinPage(first_page_id_, false);

    return TableIterator(this, rid, txn);
}

TableIterator TableHeap::End() {
    return TableIterator(this, RowId(INVALID_PAGE_ID, 0), nullptr);
}
