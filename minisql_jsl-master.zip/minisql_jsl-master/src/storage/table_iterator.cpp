#include "storage/table_iterator.h"

#include "common/macros.h"
#include "storage/table_heap.h"

TableIterator::TableIterator() {
}

TableIterator::TableIterator(TableHeap* table_heap, RowId rid, Transaction* txn)
    : table_heap_(table_heap), rid_(rid), txn_(txn) {
    row_ = new Row(rid);
    if (rid.GetPageId() != INVALID_PAGE_ID) {
        table_heap_->GetTuple(row_, txn);  // 读到row_里面
    }
}

TableIterator::TableIterator(const TableIterator& other)
    : table_heap_(other.table_heap_), rid_(other.rid_), txn_(other.txn_) {
    row_ = new Row(other.rid_);
    if (rid_.GetPageId() != INVALID_PAGE_ID) {
        table_heap_->GetTuple(row_, txn_);  // 读到row_里面
    }
}

TableIterator::~TableIterator() {
    delete row_;
}

bool TableIterator::operator==(const TableIterator& itr) const {
    // return table_heap_ == itr.table_heap_ && rid_ == itr.rid_ && txn_ == itr.txn_;
    return rid_ == itr.rid_;
}

bool TableIterator::operator!=(const TableIterator& itr) const {
    // return table_heap_ != itr.table_heap_ || !(rid_ == itr.rid_) || txn_ != itr.txn_;
    return !(rid_ == itr.rid_);
}

const Row& TableIterator::operator*() {
    return *row_;
}

Row* TableIterator::operator->() {
    return this->row_;
}

TableIterator& TableIterator::operator=(const TableIterator& itr) noexcept {
    table_heap_ = itr.table_heap_;
    rid_ = itr.rid_;
    txn_ = itr.txn_;
    row_ = new Row(itr.rid_);
    if (rid_.GetPageId() != INVALID_PAGE_ID) {
        table_heap_->GetTuple(row_, txn_);  // 读到row_里面
    }
}

// ++iter
TableIterator& TableIterator::operator++() {
    BufferPoolManager* buffer_pool_manager_ = table_heap_->buffer_pool_manager_;
    auto page = reinterpret_cast<TablePage*>(buffer_pool_manager_->FetchPage(row_->GetRowId().GetPageId()));
    page->RLatch();
    ASSERT(page != nullptr, "page is null");
    RowId& new_rid = rid_;
    if (!page->GetNextTupleRid(row_->GetRowId(), &new_rid))  // 没有返回下一个说明不在这页了
    {
        while (page->GetNextPageId() != INVALID_PAGE_ID) {
            page->RUnlatch();
            buffer_pool_manager_->UnpinPage(page->GetPageId(), false);
            page = reinterpret_cast<TablePage*>(buffer_pool_manager_->FetchPage(page->GetNextPageId()));
            page->RLatch();
            if (page->GetFirstTupleRid(&new_rid))
                break;
        }
    }
    delete this->row_;
    this->row_ = new Row(new_rid);
    if (new_rid.GetPageId() != INVALID_PAGE_ID)
        this->table_heap_->buffer_pool_manager_->UnpinPage(new_rid.GetPageId(), false);
    if (table_heap_->End() != *this)
        table_heap_->GetTuple(row_, txn_);  // 需要把row的feild内容也读入到迭代器里
    page->RUnlatch();
    return *this;
    // if (table_heap_->End() != *this)
    //     table_heap_->GetTuple(row_, txn_);
    // buffer_pool_manager_->UnpinPage(row_->GetRowId().GetPageId(), false);
    // return *this;
}

// iter++
TableIterator TableIterator::operator++(int) {
    TableIterator ret(*this);
    ++(*this);
    return ret;
}
