#include "storage/disk_manager.h"

#include <sys/stat.h>
#include <filesystem>
#include <stdexcept>

#include "glog/logging.h"
#include "page/bitmap_page.h"

DiskManager::DiskManager(const std::string& db_file)
    : file_name_(db_file) {
    std::scoped_lock<std::recursive_mutex> lock(db_io_latch_);
    db_io_.open(db_file, std::ios::binary | std::ios::in | std::ios::out);
    // directory or file does not exist
    if (!db_io_.is_open()) {
        db_io_.clear();
        // create a new file
        std::filesystem::path p = db_file;
        if (p.has_parent_path())
            std::filesystem::create_directories(p.parent_path());
        db_io_.open(db_file, std::ios::binary | std::ios::trunc | std::ios::out);
        db_io_.close();
        // reopen with original mode
        db_io_.open(db_file, std::ios::binary | std::ios::in | std::ios::out);
        if (!db_io_.is_open()) {
            throw std::exception();
        }
    }
    ReadPhysicalPage(META_PAGE_ID, meta_data_);
}

void DiskManager::Close() {
    std::scoped_lock<std::recursive_mutex> lock(db_io_latch_);
    WritePhysicalPage(META_PAGE_ID, meta_data_);
    if (!closed) {
        db_io_.close();
        closed = true;
    }
}

void DiskManager::ReadPage(page_id_t logical_page_id, char* page_data) {
    ASSERT(logical_page_id >= 0, "Invalid page id.");
    ReadPhysicalPage(MapPageId(logical_page_id), page_data);
}

void DiskManager::WritePage(page_id_t logical_page_id, const char* page_data) {
    ASSERT(logical_page_id >= 0, "Invalid page id.");
    WritePhysicalPage(MapPageId(logical_page_id), page_data);
}

/**
 * TODO: Student Implement
 */
page_id_t DiskManager::AllocatePage() {
    // 获取文件的元数据信息
    DiskFileMetaPage* diskFileMetaPage = reinterpret_cast<DiskFileMetaPage*>(meta_data_);
    unsigned int i, j;
    char temp[PAGE_SIZE];  // 用于写入磁盘的位图页
    memset(temp, 0, PAGE_SIZE);
    // 判断文件的数据页是否已经达到最大页面数，如果是则返回无效页面 ID
    if (diskFileMetaPage->GetAllocatedPages() >= MAX_VALID_PAGE_ID)
        return INVALID_PAGE_ID;
    else {
        // 从前向后找到第一个未满的分区
        for (i = 0; i < diskFileMetaPage->GetExtentNums(); ++i) {
            if (diskFileMetaPage->extent_used_page_[i] < DiskManager::BITMAP_SIZE)
                break;
        }
        // 计算最多能存在的分区数量，由MAX_VALID_PAGE_ID推导而来, num_allocated_pages_, num_extents_大小为4, 所以减8, extent_used_page_ 存储 uint32_t 所以除4
        size_t maxExtent = (PAGE_SIZE - 8) / 4;
        // 如果所有页面都已满
        if (i == diskFileMetaPage->GetExtentNums()) {
            if (i != maxExtent) {  // 还可以继续加分区, 则需要新创建一个新的分区, 并将第一个页面标记为已分配
                // 新建一个分区
                ++diskFileMetaPage->num_allocated_pages_;
                ++diskFileMetaPage->num_extents_;
                diskFileMetaPage->extent_used_page_[i] = 1;
                // 初始化一个新的 bitmap 页，并将第一个页面标记为已分配
                BitmapPage<PAGE_SIZE>* bitmap = reinterpret_cast<BitmapPage<PAGE_SIZE>*>(temp);
                unsigned int page_id;
                bitmap->AllocatePage(page_id);
                // 将新的 bitmap 页面写入磁盘文件，并返回新分配页面的页面 ID
                int pos = 1 + i * (DiskManager::BITMAP_SIZE + 1);
                WritePhysicalPage(pos, temp);  // 磁盘元数据+（每个位图页存下的数据页数量+自身）* i
                return diskFileMetaPage->num_allocated_pages_ - 1;
            } else
                return INVALID_PAGE_ID;
        } else {
            // 将磁盘中的该分区取出, 转化为bitmap之后更改, 然后填回去
            int pos = 1 + i * (DiskManager::BITMAP_SIZE + 1);
            ReadPhysicalPage(pos, temp);
            BitmapPage<PAGE_SIZE>* bitmap = reinterpret_cast<BitmapPage<PAGE_SIZE>*>(temp);
            // 在 bitmap 中搜索第一个空闲页面，并将其标记为已分配
            for (j = 0; j < bitmap->GetMaxSupportedSize(); ++j) {
                if (bitmap->IsPageFree(j))
                    break;
            }
            // 更新文件元数据信息，将新页面标记为已分配，并将 bitmap 页面写回磁盘文件
            bitmap->AllocatePage(j);
            WritePhysicalPage(pos, temp);
            ++diskFileMetaPage->num_allocated_pages_;
            ++diskFileMetaPage->extent_used_page_[i];
            // 返回新分配页面的页面 ID
            return diskFileMetaPage->num_allocated_pages_ - 1;
        }
    }
}

/**
 * TODO: Student Implement
 */
void DiskManager::DeAllocatePage(page_id_t logical_page_id) {
    if (logical_page_id >= MAX_VALID_PAGE_ID)
        return;
    if (IsPageFree(logical_page_id))
        return;
    else {
        // 获取文件的元数据信息
        char temp[PAGE_SIZE];
        DiskFileMetaPage* diskFileMetaPage = reinterpret_cast<DiskFileMetaPage*>(meta_data_);
        // int pos = 1 + (logical_page_id / DiskManager::BITMAP_SIZE) * (DiskManager::BITMAP_SIZE + 1);
        int pos = MapPageId(logical_page_id);
        ReadPhysicalPage(pos, temp);
        BitmapPage<PAGE_SIZE>* bitmap = reinterpret_cast<BitmapPage<PAGE_SIZE>*>(temp);
        unsigned int idx = logical_page_id % DiskManager::BITMAP_SIZE;  // 找到logical_page_id在对应的位图页的序号
        bitmap->DeAllocatePage(idx);
        --diskFileMetaPage->num_allocated_pages_;
        --diskFileMetaPage->extent_used_page_[logical_page_id / DiskManager::BITMAP_SIZE];
        WritePhysicalPage(pos, temp);
        return;
    }
}

/**
 * TODO: Student Implement
 */
bool DiskManager::IsPageFree(page_id_t logical_page_id) {  // logical_page_id以bit为单位
    if (logical_page_id >= MAX_VALID_PAGE_ID)
        return false;
    char temp[PAGE_SIZE];
    // 找到物理位置(以bit为单位)
    int pos = 1 + (logical_page_id / DiskManager::BITMAP_SIZE) * (DiskManager::BITMAP_SIZE + 1);
    // int pos = MapPageId(logical_page_id);
    ReadPhysicalPage(pos, temp);
    BitmapPage<PAGE_SIZE>* bitmap = reinterpret_cast<BitmapPage<PAGE_SIZE>*>(temp);
    if (bitmap->IsPageFree(logical_page_id % BITMAP_SIZE))
        return true;
    else
        return false;
}

/**
 * TODO: Student Implement
 */
page_id_t DiskManager::MapPageId(page_id_t logical_page_id) {
    return 2 + (logical_page_id / DiskManager::BITMAP_SIZE) * (DiskManager::BITMAP_SIZE + 1) + logical_page_id % DiskManager::BITMAP_SIZE;
}

int DiskManager::GetFileSize(const std::string& file_name) {
    struct stat stat_buf;
    int rc = stat(file_name.c_str(), &stat_buf);
    return rc == 0 ? stat_buf.st_size : -1;
}

void DiskManager::ReadPhysicalPage(page_id_t physical_page_id, char* page_data) {
    int offset = physical_page_id * PAGE_SIZE;
    // check if read beyond file length
    if (offset >= GetFileSize(file_name_)) {
#ifdef ENABLE_BPM_DEBUG
        LOG(INFO) << "Read less than a page" << std::endl;
#endif
        memset(page_data, 0, PAGE_SIZE);
    } else {
        // set read cursor to offset
        db_io_.seekp(offset);
        db_io_.read(page_data, PAGE_SIZE);
        // if file ends before reading PAGE_SIZE
        int read_count = db_io_.gcount();
        if (read_count < PAGE_SIZE) {
#ifdef ENABLE_BPM_DEBUG
            LOG(INFO) << "Read less than a page" << std::endl;
#endif
            memset(page_data + read_count, 0, PAGE_SIZE - read_count);
        }
    }
}

void DiskManager::WritePhysicalPage(page_id_t physical_page_id, const char* page_data) {
    size_t offset = static_cast<size_t>(physical_page_id) * PAGE_SIZE;
    // set write cursor to offset
    db_io_.seekp(offset);
    db_io_.write(page_data, PAGE_SIZE);
    // check for I/O error
    if (db_io_.bad()) {
        LOG(ERROR) << "I/O error while writing";
        return;
    }
    // needs to flush to keep disk file in sync
    db_io_.flush();
}