#include "buffer/lru_replacer.h"

LRUReplacer::LRUReplacer(size_t num_pages)
    : capacity(num_pages) {}

LRUReplacer::~LRUReplacer() = default;

bool LRUReplacer::Victim(frame_id_t* frame_id) {
    if (lruList.empty())  // 空, 即所有页面都被锁了
        return false;

    frame_id_t ret = lruList.back();
    lruList.pop_back();
    hash.erase(ret);
    *frame_id = ret;
    return true;
}

// 将数据页固定使之不能被Replacer替换, Pin函数应当在一个数据页被Buffer Pool Manager固定时被调用；
void LRUReplacer::Pin(frame_id_t frame_id) {
    if (hash.count(frame_id)) {
        lruList.erase(hash[frame_id]);
        hash.erase(frame_id);
    }
}

// Unpin函数应当在一个数据页的引用计数变为0时被Buffer Pool Manager调用，使页帧对应的数据页能够在必要时被替换；
void LRUReplacer::Unpin(frame_id_t frame_id) {
    if (hash.count(frame_id))
        return;
    // 在满了的时候去除最早使用的然后加入新的
    if (hash.size() == capacity) {
        frame_id_t* delID;
        Victim(delID);
    }
    lruList.push_front(frame_id);
    hash[frame_id] = lruList.begin();
}

size_t LRUReplacer::Size() {
    return hash.size();
}