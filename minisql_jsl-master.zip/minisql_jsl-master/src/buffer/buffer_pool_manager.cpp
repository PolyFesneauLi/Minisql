#include "buffer/buffer_pool_manager.h"

#include "glog/logging.h"
#include "page/bitmap_page.h"

static const char EMPTY_PAGE_DATA[PAGE_SIZE] = {0};

BufferPoolManager::BufferPoolManager(size_t pool_size, DiskManager* disk_manager)
    : pool_size_(pool_size), disk_manager_(disk_manager) {
    pages_ = new Page[pool_size_];
    replacer_ = new LRUReplacer(pool_size_);
    for (size_t i = 0; i < pool_size_; i++) {
        free_list_.emplace_back(i);
    }
}

BufferPoolManager::~BufferPoolManager() {
    for (auto page : page_table_) {
        FlushPage(page.first);
    }
    delete[] pages_;
    delete replacer_;
}

/**
 * TODO: Student Implement
 */

// 1.     Search the page table for the requested page (P).
// 1.1    If P exists, pin it and return it immediately.
// 1.2    If P does not exist, find a replacement page (R) from either the free list or the replacer.
//        Note that pages are always found from the free list first.
// 2.     If R is dirty, write it back to the disk.
// 3.     Delete R from the page table and insert P.
// 4.     Update P's metadata, read in the page content from disk, and then return a pointer to P.
Page* BufferPoolManager::FetchPage(page_id_t page_id) {
    // 1. 先搜 page_table
    int frameID = -1;
    if (page_table_.count(page_id))
        frameID = page_table_[page_id];
    // 1.1 如果存在
    if (frameID != -1) {
        replacer_->Pin(frameID);       // 将当前页锁住
        ++pages_[frameID].pin_count_;  // 请求该页的线程加一
        return (pages_ + frameID);
    } else {                        // 1.2 如果不存在
        if (!free_list_.empty()) {  // 1.2.1 free list还有
            frameID = free_list_.front();
            free_list_.pop_front();
        } else {  // 1.2.2 找 replacer
            if (!replacer_->Victim(&frameID))
                return nullptr;
            if (pages_[frameID].is_dirty_) {
                // 2 如果是脏页
                disk_manager_->WritePage(page_id, pages_[frameID].data_);
                pages_[frameID].is_dirty_ = false;
            }
        }
        // 3. 从 page_table 删除R, 并加入 P
        page_table_.erase(pages_[frameID].page_id_);
        page_table_[page_id] = frameID;
        // 4. 更新P的元数据，从磁盘读取页面内容，然后返回指向P的指针。
        pages_[frameID].ResetMemory();
        pages_[frameID].page_id_ = page_id;
        pages_[frameID].is_dirty_ = false;

        replacer_->Pin(frameID);
        ++pages_[frameID].pin_count_;

        disk_manager_->ReadPage(pages_[frameID].page_id_, pages_[frameID].data_);  // load

        return (pages_ + frameID);
    }
}

/**
 * TODO: Student Implement
 */

// 0.   Make sure you call AllocatePage!
// 1.   If all the pages in the buffer pool are pinned, return nullptr.
// 2.   Pick a victim page P from either the free list or the replacer. Always pick from the free list first.
// 3.   Update P's metadata, zero out memory and add P to the page table.
// 4.   Set the page ID output parameter. Return a pointer to P.
Page* BufferPoolManager::NewPage(page_id_t& page_id) {
    // PS: AllocatePage 不能放在最开始，不然即使是失败 pageID 也会增加
    // auto newPageID = AllocatePage();
    // if (newPageID == INVALID_PAGE_ID)  // 无空页
    // {
    //     return nullptr;
    // }
    bool flagAllPin = true;
    int frameID = -1;
    // 1. 如果缓冲池中的所有页面都已固定，则返回nullptr
    for (unsigned int i = 0; i < pool_size_; ++i)
        if (pages_[i].GetPinCount() <= 0) {
            flagAllPin = false;
            break;
        }
    if (flagAllPin)
        return nullptr;
    // 2.1 从 free list 找 P
    if (!free_list_.empty()) {
        frameID = free_list_.front();
        free_list_.pop_front();
    } else {
        if (!replacer_->Victim(&frameID))  // 2.2 从 replacer找P
            return nullptr;
        if (pages_[frameID].IsDirty())
            disk_manager_->WritePage(pages_[frameID].page_id_, pages_[frameID].data_);
    }

    // 0. AllocatePage
    auto newPageID = AllocatePage();
    if (newPageID == INVALID_PAGE_ID)  // 无空页
    {
        return nullptr;
    }

    // 3. 更新P的元数据，清空内存并将P添加到页面表中
    pages_[frameID].ResetMemory();
    pages_[frameID].is_dirty_ = false;

    page_table_.erase(pages_[frameID].page_id_);
    pages_[frameID].page_id_ = newPageID;  // 先从页面表移除再改page_id
    page_table_[newPageID] = frameID;

    replacer_->Pin(frameID);
    ++pages_[frameID].pin_count_;

    // 4 返回
    page_id = newPageID;
    return (pages_ + frameID);
}

/**
 * TODO: Student Implement
 */

// 0.   Make sure you call DeallocatePage!
// 1.   Search the page table for the requested page (P).
// 1.1   If P does not exist, return true.
// 2.   If P exists, but has a non-zero pin-count, return false. Someone is using the page.
// 3.   Otherwise, P can be deleted. Remove P from the page table, reset its metadata and return it to the free list.
bool BufferPoolManager::DeletePage(page_id_t page_id) {
    // 1. 先搜 page_table
    int frameID = -1;
    if (page_table_.count(page_id))
        frameID = page_table_[page_id];

    // 1.1 不存在
    if (frameID == -1)
        return true;
    else {  // 2. 存在
        if (pages_[frameID].pin_count_ > 0) {
            return false;  // 有线程在使用
        } else {           // 3. 当前页可以删除
            // 3.0 判断是否是脏页
            if (pages_[frameID].is_dirty_)
                disk_manager_->WritePage(pages_[frameID].page_id_, pages_[frameID].data_);
            // 3.1 删除其映射关系
            page_table_.erase(page_id);
            // 3.2 重置其数据域
            pages_[frameID].ResetMemory();
            pages_[frameID].is_dirty_ = false;
            // 3.3 将对应页的下标加入空闲列表
            free_list_.push_back(frameID);

            // 0 从磁盘中删除该页
            DeallocatePage(page_id);
            return true;
        }
    }
}

/**
 * TODO: Student Implement
 */
// 取消固定一个数据页
bool BufferPoolManager::UnpinPage(page_id_t page_id, bool is_dirty) {
    int frameID = -1;
    if (page_table_.count(page_id))
        frameID = page_table_[page_id];

    if (frameID != -1) {
        pages_[frameID].is_dirty_ = is_dirty;
        if (pages_[frameID].pin_count_ == 0)
            return false;
        else {
            if (--pages_[frameID].pin_count_ == 0)  // 如果还有线程占用他那么不能放到 freelist 里
                replacer_->Unpin(frameID);
        }
        if (is_dirty) {
            disk_manager_->WritePage(pages_[frameID].page_id_, pages_[frameID].data_);
            this->pages_[frameID].is_dirty_ = false;  // 改完之后需要标注为 not is_dirty_
        }
    }
    return true;
}

/**
 * TODO: Student Implement
 */
// 将数据页转储到磁盘中
bool BufferPoolManager::FlushPage(page_id_t page_id) {
    int frameID = -1;
    if (page_table_.count(page_id))
        frameID = page_table_[page_id];
    if (frameID != -1) {
        disk_manager_->WritePage(pages_[frameID].page_id_, pages_[frameID].data_);
        pages_[frameID].is_dirty_ = false;
        return true;
    }
    return false;
}

page_id_t BufferPoolManager::AllocatePage() {
    int next_page_id = disk_manager_->AllocatePage();
    return next_page_id;
}

void BufferPoolManager::DeallocatePage(__attribute__((unused)) page_id_t page_id) {
    disk_manager_->DeAllocatePage(page_id);
}

bool BufferPoolManager::IsPageFree(page_id_t page_id) {
    return disk_manager_->IsPageFree(page_id);
}

// Only used for debug
bool BufferPoolManager::CheckAllUnpinned() {
    bool res = true;
    for (size_t i = 0; i < pool_size_; i++) {
        if (pages_[i].pin_count_ != 0) {
            res = false;
            LOG(ERROR) << "page " << pages_[i].page_id_ << " pin count:" << pages_[i].pin_count_ << endl;
        }
    }
    return res;
}