#include "buffer/clock_replacer.h"

CLOCKReplacer::CLOCKReplacer(size_t num_pages)
    : capacity(num_pages) {
}
CLOCKReplacer::~CLOCKReplacer() = default;

bool CLOCKReplacer::Victim(frame_id_t* frame_id) {
    if (clockList.empty())  // 空, 即所有页面都被锁了
        return false;

    while (curPos->second == true) {
        curPos->second = false;
        ++curPos;
        if (curPos == clockList.end())
            curPos = clockList.begin();
    }
    auto delPos = curPos++;
    if (curPos == clockList.end())
        curPos = clockList.begin();
    frame_id_t ret = delPos->first;
    clockList.erase(delPos);
    hash.erase(ret);
    *frame_id = ret;
    return true;
}

void CLOCKReplacer::Pin(frame_id_t frame_id) {
    if (hash.count(frame_id)) {
        clockList.erase(hash[frame_id]);
        hash.erase(frame_id);
    }
}

void CLOCKReplacer::Unpin(frame_id_t frame_id) {
    if (hash.count(frame_id))
        return;
    // 在满了的时候把第一个 ref_bit 为0的替换成新的
    if (hash.size() == capacity) {
        while (curPos->second == 1) {
            curPos->second = 0;
            ++curPos;
            if (curPos == clockList.end())
                curPos = clockList.begin();
        }
        hash.erase(curPos->first);
        curPos->first = frame_id;
        curPos->second = 1;
        hash[frame_id] = curPos;
    } else {
        clockList.push_back({frame_id, 1});
        hash[frame_id] = clockList.end();
        --hash[frame_id];
        curPos = hash[frame_id];  // 让curPos指向刚插入的节点
    }
}

size_t CLOCKReplacer::Size() {
    return hash.size();
}