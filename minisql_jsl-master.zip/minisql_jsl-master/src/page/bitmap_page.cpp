#include "page/bitmap_page.h"

#include "glog/logging.h"

/**
 * TODO: Student Implement
 */
// 解释：位图页内部实现均采用位操作, 比如将第1234个位置1, 字节序：1234 >> 3 = 154;
// 位序: 0x80 >> (1234 & 0x07) = 2, 那么 1234 放在 M 的下标 154 字节处，把该字节的 2 号位置为 1 (大端序)
template <size_t PageSize>
bool BitmapPage<PageSize>::AllocatePage(uint32_t& page_offset) {  // page_offset是用来返回的，不是用来使用的参数
    // Bitmap content空间不够，MAX_CHARS是Bitmap content空间，为PageSize减去64位Bitmap Page Meta, 其包括page_allocated_和next_free_page_
    if (page_allocated_ >= GetMaxSupportedSize()) {
        next_free_page_ = GetMaxSupportedSize() - 1;  // 说明全满了，将指针移向最后
        return false;
    } else {
        // 通过page_offset返回所分配的空闲页位于该段中的下标（从0开始）
        page_offset = next_free_page_;
        ++page_allocated_;
        unsigned int offset = page_offset % 8;
        // 将对应位变为1
        bytes[page_offset / 8] |= 1 << (7 - offset);
        // update next_free_page_
        if (page_allocated_ >= GetMaxSupportedSize()) {
            next_free_page_ = GetMaxSupportedSize() - 1;  // 说明全满了，将指针移向最后
            // 当前已经不存在未分配的页
            return true;
        } else {
            for (unsigned int i = next_free_page_ / 8; i < MAX_CHARS; ++i) {
                bool flag1 = false;  // 记录在当前字节是否存在未分配的页
                unsigned char temp = 1 << 7;
                for (int j = 0; j < 8; j++) {
                    if ((bytes[i] & temp) == 0) {
                        // 表明当前位的值为 0，即存在一个未分配的页
                        flag1 = true;
                        next_free_page_ = i * 8 + j;
                        break;
                    } else {
                        temp >>= 1;
                    }
                }
                if (flag1) {
                    break;
                }
            }
        }
        return true;
    }
}

/**
 * TODO: Student Implement
 */
template <size_t PageSize>
bool BitmapPage<PageSize>::DeAllocatePage(uint32_t page_offset) {
    if (page_offset >= GetMaxSupportedSize())
        return false;
    if (IsPageFree(page_offset))
        return false;
    unsigned int offset = page_offset % 8;
    unsigned char temp = 1 << (7 - offset);
    // 将对应位变为0
    bytes[page_offset / 8] &= (~temp);
    // 保证next_free_page_保存第一个空闲页
    if (page_offset < next_free_page_) {
        next_free_page_ = page_offset;
    }
    --page_allocated_;
    return true;
}

/**
 * TODO: Student Implement
 */
template <size_t PageSize>
bool BitmapPage<PageSize>::IsPageFree(uint32_t page_offset) const {
    if (page_offset >= GetMaxSupportedSize())
        return false;
    else {
        // 获取偏移量
        unsigned int offset = page_offset % 8;
        // 将高offset号位赋值为1
        unsigned char temp = 1 << (7 - offset);
        if (bytes[page_offset / 8] & temp) {
            // 表明当前位的值是 1，对应的数据页已经被分配
            return false;
        } else {
            return true;
        }
    }
}

template <size_t PageSize>
bool BitmapPage<PageSize>::IsPageFreeLow(uint32_t byte_index, uint8_t bit_index) const {
    return false;
}

template class BitmapPage<64>;

template class BitmapPage<128>;

template class BitmapPage<256>;

template class BitmapPage<512>;

template class BitmapPage<1024>;

template class BitmapPage<2048>;

template class BitmapPage<4096>;