#include "page/b_plus_tree_internal_page.h"

#include "index/generic_key.h"

#define pairs_off (data_)
#define pair_size (GetKeySize() + sizeof(page_id_t))
#define key_off 0
#define val_off GetKeySize()

/**
 * 不涉及任何Unpin的操作，统一在b+tree.cpp申请释放（除了修改父节点），所有的更新都仅仅是本层和下层，不涉及向上更新
 */
/*****************************************************************************
 * HELPER METHODS AND UTILITIES
 *****************************************************************************/
/*
 * Init method after creating a new internal page
 * Including set page type, set current size, set page id, set parent id and set
 * max page size
 */
void InternalPage::Init(page_id_t page_id, page_id_t parent_id, int key_size, int max_size) {
  this->SetPageType(IndexPageType::INTERNAL_PAGE); // 初始化新的节点时先默是内部节点
  this->SetKeySize(key_size);
  this->SetSize(0);
  this->SetPageId(page_id);
  this->SetParentPageId(parent_id);
  this->SetMaxSize(max_size);
}
/*
 * Helper method to get/set the key associated with input "index"(a.k.a
 * array offset)
 */
GenericKey *InternalPage::KeyAt(int index) {
  return reinterpret_cast<GenericKey *>(pairs_off + index * pair_size + key_off);
}

void InternalPage::SetKeyAt(int index, GenericKey *key) {
  memcpy(pairs_off + index * pair_size + key_off, key, GetKeySize());
  // 把 key 复制到对应的位置，将key顺序储存到了data_里面
}

page_id_t InternalPage::ValueAt(int index) const {
  return *reinterpret_cast<const page_id_t *>(pairs_off + index * pair_size + val_off);
}

void InternalPage::SetValueAt(int index, page_id_t value) {
  *reinterpret_cast<page_id_t *>(pairs_off + index * pair_size + val_off) = value;
}

// 寻找 page_id 对应的下标
int InternalPage::ValueIndex(const page_id_t &value) const {
  for (int i = 0; i < GetSize(); ++i) {
    if (ValueAt(i) == value)
      return i;
  }
  return -1;
}

// 返回对应下标的键值对
pair<GenericKey *, page_id_t> *InternalPage::PairPtrAt(int index) {
  pair<GenericKey *, page_id_t> key;
  key.first = KeyAt(index);
  key.second = ValueAt(index);
  return &key;
}

// 将 src 复制 pair_num 个键值对到 dest 原值的后面
void InternalPage::PairCopy(void *dest, void *src, int pair_num) {
  memcpy(dest, src, pair_num * pair_size);
}
/*****************************************************************************
 * LOOKUP
 *****************************************************************************/
/*
 * Find and return the child pointer(page_id) which points to the child page
 * that contains input "key"
 * Start the search from the second key(the first key should always be invalid)
 * 用了二分查找，返回插入的位置
 */
page_id_t InternalPage::Lookup(const GenericKey *key, const KeyManager &KM) {
  int max = this->GetSize() - 1, low = 1, center = 0; // 从第二个节点开始查找
  while(low <= max){
    center = (low + max) / 2; // 二分法加速查找
    if(KM.CompareKeys(key, this->KeyAt(center)) < 0){  // 小于当前中间值
      if(center == 1 || KM.CompareKeys(key, this->KeyAt(center - 1)) >= 0){  // 大于前一个值
        return this->ValueAt(center - 1);
      }
      else max = center - 1;
    }
    else{ // 大于当前键值
      if(center == max || KM.CompareKeys(key, this->KeyAt(center + 1)) < 0){ // 小于后一个键值
        return this->ValueAt(center);
      }
      else low = center + 1;
    }
  }
  return ValueAt(center);
}

/*****************************************************************************
 * INSERTION
 *****************************************************************************/
/*
 * Populate new root page with old_value + new_key & new_value
 * When the insertion cause overflow from leaf page all the way upto the root
 * page, you should create a new root page and populate its elements.
 * NOTE: This method is only called within InsertIntoParent()(b_plus_tree.cpp)
 */
void InternalPage::PopulateNewRoot(const page_id_t &old_value, GenericKey *new_key, const page_id_t &new_value) {
  this->SetValueAt(0, old_value);
//  this->SetKeyAt(0, NULL);  // 第一个键值被浪费了
  this->SetKeyAt(1, new_key); // 第一个不储存，所以不用旧的值
  this->SetValueAt(1, new_value);
  this->SetSize(2); // 新建的内部节点中有两个key
}

/*
 * Insert new_key & new_value pair right after the pair with its value ==
 * old_value
 * 直接插到old_value的正右边，所以后面的其他值需要依次向后移动
 * @return:  new size after insertion
 */
int InternalPage::InsertNodeAfter(const page_id_t &old_value, GenericKey *new_key, const page_id_t &new_value) {
  int index = this->ValueIndex(old_value) + 1;  // 找到对应的旧下标+1
  this->IncreaseSize(1);
  for(int i = this->GetSize() - 1; i >= index; i--){// 把index+1后面的节点统一往后存一个
    this->SetKeyAt(i + 1, this->KeyAt(i));
    this->SetValueAt(i + 1, this->ValueAt(i));
  }
  this->SetKeyAt(index, new_key); // 插入新节点
  this->SetValueAt(index, new_value);
  return this->GetSize();
}

/*****************************************************************************
 * SPLIT
 *****************************************************************************/
/*
 * Remove half of key & value pairs from this page to "recipient" page
 * buffer_pool_manager 是干嘛的？传给CopyNFrom()用于Fetch数据页
 */
void InternalPage::MoveHalfTo(InternalPage *recipient, BufferPoolManager *buffer_pool_manager) {
  int num_rest = GetSize() - GetSize() / 2;
//    /**
//     * 下面的变量仅用于检查函数
//     */
//    page_id_t pageId1 = this->ValueAt(this->GetSize() - 1);
//    page_id_t pageId2 = this->ValueAt(this->GetSize() - num_rest);
//    /**
//     * 检查
//     */
  int start = GetSize() - num_rest;
  recipient->CopyNFrom(data_ + pair_size * start, num_rest, buffer_pool_manager);
  // data_ + start 是传入上一个节点要转移对象的头指针
  this->IncreaseSize(-1 * num_rest);
//  page_id_t pageId3 = recipient->ValueAt(0);
//  page_id_t pageId4 = recipient->ValueAt(recipient->GetSize() - 1);
}

/* Copy entries into me, starting from {items} and copy {size} entries.
 * Since it is an internal page, for all entries (pages) moved, their parents page now changes to me.
 * So I need to 'adopt' them by changing their parent page id, which needs to be persisted with BufferPoolManger
 */
void InternalPage::CopyNFrom(void *src, int size, BufferPoolManager *buffer_pool_manager) {
  this->PairCopy(this->data_ + this->GetSize() * pair_size, src, size); // 将 src 复制到 this 中
  // this->SetKeyAt(0, NULL);  // 第一个键值无效
  for(int i = 0; i < size; i++){ // 修改相应的子节点的父节点
    auto *child_page = buffer_pool_manager->FetchPage(ValueAt(this->GetSize() + i));
    auto *BNode = reinterpret_cast<BPlusTreePage *>(child_page->GetData()); // 获取子页id
    BNode->SetParentPageId(this->GetPageId());  // 将子页的父亲改成this
    buffer_pool_manager->UnpinPage(child_page->GetPageId(), true);  // 把子页写回
  }
  this->IncreaseSize(size);
}

/*****************************************************************************
 * REMOVE
 *****************************************************************************/
/*
 * Remove the key & value pair in internal page according to input index(a.k.a
 * array offset)
 * NOTE: store key&value pair continuously after deletion
 */
void InternalPage::Remove(int index) {
  int size = this->GetSize();   // 目前键值对的大小
  this->IncreaseSize(-1);
  for(int i = index + 1; i < size; i++){ // 从后往前移动
    this->SetKeyAt(i - 1, this->KeyAt(i));
    this->SetValueAt(i - 1, this->ValueAt(i));
  }
}

/*
 * Remove the only key & value pair in internal page and return the value
 * NOTE: only call this method within AdjustRoot()(in b_plus_tree.cpp)
 * 删除唯一的键值对，返回从前的页码
 */
page_id_t InternalPage::RemoveAndReturnOnlyChild() {
  this->SetSize(0);
  return this->ValueAt(0);
}

/*****************************************************************************
 * MERGE
 *****************************************************************************/
/*
 * Remove all key & value pairs from this page to "recipient" page.
 * The middle_key is the separation key you should get from the parent. You need
 * to make sure the middle key is added to the recipient to maintain the invariant.
 * You also need to use BufferPoolManager to persist changes to the parent page id for those
 * pages that are moved to the recipient
 * recipient 页需要在后续操作里 Unpin
 */
void InternalPage::MoveAllTo(InternalPage *recipient, GenericKey *middle_key, BufferPoolManager *buffer_pool_manager) {
  int size = this->GetSize();
  this->SetKeyAt(0, middle_key);
  for(int i = 0; i < size; i++){
    recipient->SetKeyAt(recipient->GetSize() + i, this->KeyAt(i));
    recipient->SetValueAt(recipient->GetSize() + i, this->ValueAt(i));
    // 修改子节点的父节点引用关系
    auto *child = buffer_pool_manager->FetchPage(this->ValueAt(i));  // 查找page
    if (child == nullptr){
      throw runtime_error("all pages pinned during B_PLUS_TREE_INTERNAL_PAGE_TYPE::MoveAllTo");
    }
    auto *newNode = reinterpret_cast<BPlusTreePage*>(child->GetData());
    newNode->SetParentPageId(recipient->GetPageId()); // 更换原本的父亲
    // 修改后释放子节点页面
    buffer_pool_manager->UnpinPage(this->ValueAt(i), true);
  }
  recipient->IncreaseSize(size);
  this->SetSize(0); // 当前页大小为 0
}

/*****************************************************************************
 * REDISTRIBUTE
 *****************************************************************************/
/*
 * Remove the first key & value pair from this page to tail of "recipient" page.
 * The middle_key is the separation key you should get from the parent. You need
 * to make sure the middle key is added to the recipient to maintain the invariant.
 * You also need to use BufferPoolManager to persist changes to the parent page id for those
 * pages that are moved to the recipient
 */
void InternalPage::MoveFirstToEndOf(InternalPage *recipient, GenericKey *middle_key,
                                    BufferPoolManager *buffer_pool_manager) {
  recipient->CopyLastFrom(middle_key, this->ValueAt(0), buffer_pool_manager);
  recipient->SetKeyAt(recipient->GetSize(), middle_key);
  recipient->SetValueAt(recipient->GetSize(), this->ValueAt(0));
  for(int i = 1; i < this->GetSize(); i++){ // 当前的key和页码都向前移动1
    this->SetKeyAt(i - 1, this->KeyAt(i));
    this->SetValueAt(i - 1, this->ValueAt(i));
  }
  // this->SetKeyAt(0, NULL);
  this->IncreaseSize(-1);
}

/* Append an entry at the end.
 * Since it is an internal page, the moved entry(page)'s parent needs to be updated.
 * So I need to 'adopt' it by changing its parent page id, which needs to be persisted with BufferPoolManger
 */
void InternalPage::CopyLastFrom(GenericKey *key, const page_id_t value, BufferPoolManager *buffer_pool_manager) {
  int index = this->GetSize();  // 将数据储存到最右边
  this->SetKeyAt(index, key);
  this->SetValueAt(index, value);
  this->IncreaseSize(1);
  // 修改父节点
  auto *page = reinterpret_cast<BPlusTreePage*>(buffer_pool_manager->FetchPage(ValueAt(index))->GetData());
  if(page == NULL){
    throw runtime_error("the page is Unpin when CopyLastFrom.");
  }
  page->SetParentPageId(GetPageId());
  buffer_pool_manager->UnpinPage(page->GetPageId(), true);
}

/*
 * Remove the last key & value pair from this page to head of "recipient" page.
 * You need to handle the original dummy key properly, e.g. updating recipient’s array to position the middle_key at the
 * right place.
 * You also need to use BufferPoolManager to persist changes to the parent page id for those pages that are
 * moved to the recipient
 */
void InternalPage::MoveLastToFrontOf(InternalPage *recipient, GenericKey *middle_key,
                                     BufferPoolManager *buffer_pool_manager) {
  this->IncreaseSize(-1);
  int index = this->GetSize() - 1;
  recipient->SetKeyAt(0, middle_key); // 加上省略的节点
  recipient->CopyFirstFrom(this->ValueAt(index), buffer_pool_manager);
}

/* Append an entry at the beginning.
 * Since it is an internal page, the moved entry(page)'s parent needs to be updated.
 * So I need to 'adopt' it by changing its parent page id, which needs to be persisted with BufferPoolManger
 */
void InternalPage::CopyFirstFrom(const page_id_t value, BufferPoolManager *buffer_pool_manager) {
  for(int i = this->GetSize() - 1; i >=0; i--){ // 统一向右移动
    this->SetKeyAt(i + 1, this->KeyAt(i));
    this->SetValueAt(i + 1, this->ValueAt(i));
  }
  this->SetValueAt(0, value); // 不设置key[0]
  this->IncreaseSize(1);
  // 修改父节点
  auto *page = reinterpret_cast<BPlusTreePage*>(buffer_pool_manager->FetchPage(ValueAt(0))->GetData());
  if(page == NULL){
    throw runtime_error("the page is Unpin when CopyLastFrom.");
  }
  page->SetParentPageId(GetPageId());
  buffer_pool_manager->UnpinPage(page->GetPageId(), true); // 释放
}