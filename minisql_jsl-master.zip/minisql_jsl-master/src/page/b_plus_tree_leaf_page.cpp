#include "page/b_plus_tree_leaf_page.h"

#include <algorithm>

#include "index/generic_key.h"

#define pairs_off (data_)
#define pair_size (GetKeySize() + sizeof(RowId))
#define key_off 0
#define val_off GetKeySize()
/*****************************************************************************
 * HELPER METHODS AND UTILITIES
 *****************************************************************************/

/**
 * Student Implement
 */
/**
 * Init method after creating a new leaf page
 * Including set page type, set current size to zero, set page id/parent id, set
 * next page id and set max size
 * 未初始化next_page_id
 */
void LeafPage::Init(page_id_t page_id, page_id_t parent_id, int key_size, int max_size) {
  // 初始化 header 部分
  this->SetPageType(IndexPageType::LEAF_PAGE);
  this->SetPageId(page_id);
  this->SetParentPageId(parent_id);
  this->SetKeySize(key_size);
  this->SetMaxSize(max_size);
  this->SetSize(0);
  this->next_page_id_ = INVALID_PAGE_ID;  // 将下一页先置空
  if(max_size == 0){
    int size = LEAF_PAGE_SIZE;
    this->SetMaxSize(size);
  }
}

/**
 * Helper methods to set/get next page id
 */
page_id_t LeafPage::GetNextPageId() const {
  return next_page_id_;
}

void LeafPage::SetNextPageId(page_id_t next_page_id) {
  next_page_id_ = next_page_id;
  if (next_page_id == 0) {
    LOG(INFO) << "Fatal error";
  }
}

/**
 * Student Implement
 */
/**
 * Helper method to find the first index i so that pairs_[i].first >= key
 * NOTE: This method is only used when generating index iterator
 * 二分查找
 */
int LeafPage::KeyIndex(const GenericKey *key, const KeyManager &KM) {
  int max = this->GetSize() - 1, center, low = 0;
  while(low <= max){
    center = (low + max) / 2;
    if(KM.CompareKeys(key, this->KeyAt(center)) > 0){
      if(center == this->GetSize() - 1 || KM.CompareKeys(key, this->KeyAt(center + 1)) <= 0) {
        return center + 1;  // 大于当前下标，小于下一个下标
      }
      low = center + 1;
    }
    else{ // 没有更小的下标或者符合第一个大于满足要求的下标
      if(center == 0 || (KM.CompareKeys(key, this->KeyAt(center - 1)) > 0)){
        return center;
      }
      max = center - 1;
    }
  }
  return this->GetSize(); // 没有找到，插到末尾
}

/*
 * Helper method to find and return the key associated with input "index"(a.k.a
 * array offset)
 */
GenericKey *LeafPage::KeyAt(int index) {
  return reinterpret_cast<GenericKey *>(pairs_off + index * pair_size + key_off);
}

void LeafPage::SetKeyAt(int index, GenericKey *key) {
  memcpy(pairs_off + index * pair_size + key_off, key, GetKeySize());
}

RowId LeafPage::ValueAt(int index) const {
  return *reinterpret_cast<const RowId *>(pairs_off + index * pair_size + val_off);
}

void LeafPage::SetValueAt(int index, RowId value) {
  *reinterpret_cast<RowId *>(pairs_off + index * pair_size + val_off) = value;
}

void *LeafPage::PairPtrAt(int index) {
  return KeyAt(index);
}
// 把后面复制到前面
void LeafPage::PairCopy(void *dest, void *src, int pair_num) {
  memcpy(dest, src, pair_num * pair_size);
}

/*
 * Helper method to find and return the key & value pair associated with input
 * "index"(a.k.a. array offset)
 */
std::pair<GenericKey *, RowId> LeafPage::GetItem(int index) {
    // replace with your own code
  GenericKey *key = this->KeyAt(index);
  return make_pair(key, this->ValueAt(index));
}

/*****************************************************************************
 * INSERTION
 *****************************************************************************/
/*
 * Insert key & value pair into leaf page ordered by key
 * @return page size after insertion
 */
int LeafPage::Insert(GenericKey *key, const RowId &value, const KeyManager &KM) {
  int index = this->KeyIndex(key, KM); // 找插入的下标
  for(int i = this->GetSize() - 1; i >= index; i--){ // 把从改下标开始的值统一往后移动
    this->SetKeyAt(i + 1, this->KeyAt(i));
    this->SetValueAt(i + 1, this->ValueAt(i));
  }
  this->SetValueAt(index, value);
  this->SetKeyAt(index, key);
  this->IncreaseSize(1);  // 插入后大小增加
  return this->GetSize();
}

/*****************************************************************************
 * SPLIT
 *****************************************************************************/
/*
 * Remove half of key & value pairs from this page to "recipient" page
 */
void LeafPage::MoveHalfTo(LeafPage *recipient) {
  int size_rm = this->GetSize() / 2;
//  /**
//   * 下面的变量仅用于检查函数
//   */
//  GenericKey* look1 = this->KeyAt(this->GetSize() - 1);
//  GenericKey* look3 = this->KeyAt(this->GetSize() - size_rm - 1);
//  /**
//   * 检查
//   */
  recipient->CopyNFrom(this->data_ + pair_size * (this->GetSize() - size_rm), size_rm);
  this->IncreaseSize(-size_rm); // 目前节点的大小减小
//  std::vector<Column *> columns3 = {
//      new Column("int", TypeId::kTypeInt, 0, false, false),
//  };
//  Schema *table_schema3 = new Schema(columns3);
//  KeyManager Look(table_schema3, 16);
//  int i1 = Look.CompareKeys(recipient->KeyAt(recipient->GetSize() - 1), look1);
//  int i3 = Look.CompareKeys(this->KeyAt(this->GetSize() - 1), look3);
//  if(i1 != 0 || i3 != 0) throw runtime_error("复制失败");
}

/*
 * Copy starting from items, and copy {size} number of elements into me.
 */
void LeafPage::CopyNFrom(void *src, int size) {
  this->PairCopy(this->data_ + pair_size * this->GetSize(), src, size); // 在原本的data_的后面加
  this->IncreaseSize(size); // 插入之后大小增加
  // 没有子页需要更新
}

/*****************************************************************************
 * LOOKUP
 *****************************************************************************/
/*
 * For the given key, check to see whether it exists in the leaf page. If it
 * does, then store its corresponding value in input "value" and return true.
 * If the key does not exist, then return false
 */
bool LeafPage::Lookup(const GenericKey *key, RowId &value, const KeyManager &KM) {
  int index = this->KeyIndex(key, KM);
  if(index == GetSize()){ // 当返回值为最大时
    return false;
  }// 返回为能够插入的地址，在附近进行搜索
  if(!KM.CompareKeys(key, this->KeyAt(index))){
    value = this->ValueAt(index);
    return true;
  }
  return false;   // 刚好与返回值相等
}

/*****************************************************************************
 * REMOVE
 *****************************************************************************/
/*
 * First look through leaf page to see whether delete key exist or not. If
 * existed, perform deletion, otherwise return immediately.
 * NOTE: store key&value pair continuously after deletion
 * @return  page size after deletion
 */
int LeafPage::RemoveAndDeleteRecord(const GenericKey *key, const KeyManager &KM) {
  RowId value;
  if(this->Lookup(key, value, KM)){ // 该值是否存在
    int index = KeyIndex(key, KM);      // 找到该值对应的下标
    for(int i = index; i < this->GetSize(); i++){ // 统一向前移动
      this->SetValueAt(i, this->ValueAt(i + 1));
      this->SetKeyAt(i, this->KeyAt(i + 1));
    }
    this->IncreaseSize(-1); // 大小减一
    return this->GetSize();
  }
  return -1;  // 要删除的数不存在
}

/*****************************************************************************
 * MERGE
 *****************************************************************************/
/*
 * Remove all key & value pairs from this page to "recipient" page. Don't forget
 * to update the next_page id in the sibling page
 */
// 从当前页移动到参数目标页
void LeafPage::MoveAllTo(LeafPage *recipient) {
  this->PairCopy(recipient->data_ + recipient->GetSize() * pair_size, this->data_, this->GetSize());
  recipient->IncreaseSize(this->GetSize());
  this->SetSize(0);
  recipient->SetNextPageId(this->GetNextPageId());
  // 这里不把原本指向 this 的 next_page 指向 reecipient，之后是右并左不需要
}

/*****************************************************************************
 * REDISTRIBUTE
 *****************************************************************************/
/*
 * Remove the first key & value pair from this page to "recipient" page.
 *
 */
void LeafPage::MoveFirstToEndOf(LeafPage *recipient) {
  int size = this->GetSize();
  recipient->CopyLastFrom(this->KeyAt(0), this->ValueAt(0)); // 插入到末尾
  for(int i = 0; i < size; i++){  // 往前移动 1
    this->SetKeyAt(i, this->KeyAt(i + 1));
    this->SetValueAt(i, this->ValueAt(i + 1));
  }
  this->IncreaseSize(-1);
}

/*
 * Copy the item into the end of my item list. (Append item to my array)
 */
void LeafPage::CopyLastFrom(GenericKey *key, const RowId value) {
  int index = this->GetSize();  // 目标地址
  this->IncreaseSize(1);  // 大小增加 1
  this->SetKeyAt(index, key);
  this->SetValueAt(index, value);
}

/*
 * Remove the last key & value pair from this page to "recipient" page.
 */
void LeafPage::MoveLastToFrontOf(LeafPage *recipient) {
  this->IncreaseSize(-1); // 大小减少
  recipient->CopyFirstFrom(this->KeyAt(this->GetSize()), this->ValueAt(this->GetSize()));
}

/*
 * Insert item at the front of my items. Move items accordingly.
 *
 */
void LeafPage::CopyFirstFrom(GenericKey *key, const RowId value) {
  int size = this->GetSize();
  for(int i = size - 1; i >= 0; i--){  // 统一向后移动一位
    this->SetValueAt(i + 1, this->ValueAt(i));
    this->SetKeyAt(i + 1, this->KeyAt(i));
  }
  this->SetKeyAt(0, key); //  插入键值对
  this->SetValueAt(0, value);
  this->IncreaseSize(1);  // 修改大小
}